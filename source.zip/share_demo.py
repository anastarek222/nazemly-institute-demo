#!/usr/bin/env python3
"""Share a fresh, isolated Nazemly demo via a temporary Cloudflare HTTPS URL.
Never connects to normal hr.sqlite3 or the existing local demo.sqlite3.
"""
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import socket
import sqlite3
import string
import subprocess
import sys
import tempfile
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
CLOUDFLARED = shutil.which("cloudflared") or str(Path.home() / ".local/bin/cloudflared")

def random_password():
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(18))

def choose_port():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]

def health(url):
    with urllib.request.urlopen(url + "/api/health", timeout=1.5) as response:
        return json.load(response)

def stop(proc):
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()

def main():
    if not Path(CLOUDFLARED).is_file():
        raise RuntimeError(
            "cloudflared مش متثبت. راجع README.md أو نزله من موقع Cloudflare الرسمي."
        )
    sys.path.insert(0, str(ROOT / "app"))
    from common import password_hash
    with tempfile.TemporaryDirectory(prefix="nazemly-share-") as temp:
        db_file = Path(temp) / "share.sqlite3"
        port = choose_port()
        local_url = "http://127.0.0.1:" + str(port)
        env = dict(os.environ, HR_DB_PATH=str(db_file), HR_DEMO_MODE="1",
                   HR_SEED_EXAMPLES="1", HR_SHARE_MODE="1",
                   PYTHONDONTWRITEBYTECODE="1")
        server = None
        tunnel = None
        try:
            server = subprocess.Popen(
                [sys.executable, "-B", str(ROOT / "app" / "server.py"),
                 "--port", str(port)],
                cwd=str(ROOT), env=env, stdout=subprocess.DEVNULL
            )
            for attempt in range(120):
                if server.poll() is not None:
                    raise RuntimeError("تعذر تشغيل السيرفر المحلي.")
                try:
                    result = health(local_url)
                    if result.get("app") == "nazemly" and result.get("demo"):
                        break
                except Exception:
                    pass
                time.sleep(0.1)
            else:
                raise RuntimeError("السيرفر المحلي لم يبدأ.")

            admin_password = random_password()
            employee_password = random_password()
            with sqlite3.connect(str(db_file), timeout=15) as conn:
                conn.execute("UPDATE users SET password_hash=? WHERE role='manager'",
                             (password_hash(admin_password),))
                conn.execute("UPDATE users SET password_hash=? WHERE role='employee'",
                             (password_hash(employee_password),))
                conn.execute("DELETE FROM sessions")
                employees = conn.execute(
                    "SELECT username FROM users WHERE role='employee' ORDER BY employee_id"
                ).fetchall()
            assert len(employees) == 4, "Expected four isolated demonstration accounts"
            print("\n🔒 نسخة مشاركة مؤقتة — بيانات وهمية فقط", flush=True)
            print("مفيش أي اتصال بقاعدة التشغيل أو قاعدة العرض المحلية.", flush=True)
            print("اسم المدير: admin", flush=True)
            print("كلمة مرور المدير: " + admin_password, flush=True)
            print("حسابات الموظفين: " + ", ".join(x[0] for x in employees), flush=True)
            print("كلمة مرور الموظفين: " + employee_password, flush=True)
            print("ابدأ المشاركة بإرسال الرابط وكلمة مرور الموظف فقط لو حابب.", flush=True)
            if "--check" in sys.argv:
                print("CHECK PASS: fresh isolated demo, 4 employees, rotated passwords")
                return

            tunnel = subprocess.Popen(
                [CLOUDFLARED, "tunnel", "--url", local_url],
                cwd=str(ROOT), stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, universal_newlines=True, bufsize=1,
            )
            print("جاري إنشاء رابط Cloudflare HTTPS مؤقت...", flush=True)
            url_pattern = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")
            url = None
            deadline = time.monotonic() + 90
            import select
            while time.monotonic() < deadline:
                if tunnel.poll() is not None:
                    raise RuntimeError("Cloudflare tunnel اتوقف قبل ما يطلع رابط.")
                ready, _, _ = select.select([tunnel.stdout], [], [], 1)
                if not ready:
                    continue
                line = tunnel.stdout.readline()
                match = url_pattern.search(line)
                if match:
                    url = match.group(0)
                    break
            if not url:
                raise RuntimeError("Cloudflare ما رجعش رابط خلال وقت المحاولة.")
            print("\n✅ رابط العرض: " + url, flush=True)
            print("هينتهي لما تقفل النافذة أو تنام/تقفل الماك.", flush=True)
            print("اضغط Ctrl+C لإيقاف المشاركة ومسح قاعدة المشاركة المؤقتة.", flush=True)
            tunnel.wait()
        finally:
            stop(tunnel)
            stop(server)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nتم إيقاف المشاركة.")
    except Exception as error:
        print("فشل تشغيل المشاركة: " + str(error), file=sys.stderr)
        sys.exit(1)
