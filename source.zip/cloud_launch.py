#!/usr/bin/env python3
"""Launch the isolated Nazemly demo as a cloud-hosted web service.

This file is intended for hosting only. Local Windows/Mac launchers remain untouched.
"""
import os
import sys
from pathlib import Path

root = Path(__file__).resolve().parent


def main():
    admin = os.environ.get('NAZEMLY_ADMIN_PASSWORD', '')
    employee = os.environ.get('NAZEMLY_EMPLOYEE_PASSWORD', '')
    if len(admin) < 14 or len(employee) < 14 or admin == employee:
        raise SystemExit(
            'Setup required: set distinct NAZEMLY_ADMIN_PASSWORD and '
            'NAZEMLY_EMPLOYEE_PASSWORD (at least 14 characters each) '
            'in the hosting service environment.'
        )
    try:
        port = int(os.environ.get('PORT', '8080'))
    except ValueError:
        raise SystemExit('PORT must be numeric')
    if not 1 <= port <= 65535:
        raise SystemExit('PORT must be 1..65535')
    data_dir = Path('/data') if Path('/data').is_dir() else (root / 'app' / 'data')
    data_dir.mkdir(parents=True, exist_ok=True)
    db = data_dir / 'cloud-demo.sqlite3'
    os.environ['HR_DB_PATH'] = str(db)
    os.environ['HR_DEMO_MODE'] = '1'
    os.environ['HR_SEED_EXAMPLES'] = '1'
    os.environ['NAZEMLY_CLOUD_DEMO'] = '1'
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    sys.path.insert(0, str(root / 'app'))
    import server
    server.init()
    if os.environ.get('HR_DEMO_MODE') == '1':
        from common import cairo_today, now
        import demo_seed, json
        from storage import DB_PATH, db as database
        import hr_features as features
        with database() as connection:
            demo_seed.seed(connection, cairo_today())
        snapshot = DB_PATH.parent / 'demo-initial.json'
        if not snapshot.exists():
            with database() as connection:
                snapshot.write_text(json.dumps(features.export_backup(connection, now()), ensure_ascii=False), encoding='utf-8')
    print('Nazemly cloud demo is ready on port', port, flush=True)
    server.ThreadingHTTPServer(('0.0.0.0', port), server.Handler).serve_forever()


if __name__ == '__main__':
    main()
