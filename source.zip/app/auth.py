"""Authentication and first-run safety for the local Nazemly web app."""
import hashlib
import os
import secrets
import time

from common import password_ok, text

SESSION_COOKIE = (
    "nazemly_demo_session" if os.environ.get("HR_DEMO_MODE") == "1"
    else "hr_session"
)
DEFAULT_ADMIN_PASSWORD = "Admin@12345"
FAILED_LOGINS = {}


def must_change_admin_password(user):
    """Only a new normal installation requires a first-login password change."""
    return (
        user["role"] == "manager"
        and os.environ.get("HR_DEMO_MODE") != "1"
        and os.environ.get("HR_SEED_EXAMPLES") != "1"
        and password_ok(DEFAULT_ADMIN_PASSWORD, user["password_hash"])
    )


def session(connection, cookie_header):
    token = next(
        (part.strip().split("=", 1)[1]
         for part in cookie_header.split(";")
         if part.strip().startswith(SESSION_COOKIE + "=")),
        "",
    )
    if not token:
        return None
    return connection.execute(
        "SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id "
        "LEFT JOIN employees e ON e.id=u.employee_id "
        "WHERE s.token_hash=? AND s.expires_at>? AND u.enabled=1 "
        "AND (u.role=? OR e.active=1)",
        (hashlib.sha256(token.encode()).hexdigest(), time.time(), "manager"),
    ).fetchone()


def login(connection, body, client_ip):
    username = text(body.get("username"))
    password = text(body.get("password"), 200)
    # A failed attempt on one account does not lock other users out
    # behind a shared Cloudflare tunnel IP.
    key = (client_ip, username.casefold())
    stamp = time.time()
    attempts = [t for t in FAILED_LOGINS.get(key, []) if stamp - t < 300]
    FAILED_LOGINS[key] = attempts
    if len(attempts) >= 10:
        return {"error": "محاولات كثيرة؛ جرّب بعد خمس دقائق"}, 429, None
    user = connection.execute(
        "SELECT u.* FROM users u LEFT JOIN employees e ON e.id=u.employee_id "
        "WHERE username=? AND u.enabled=1 AND (u.role=? OR e.active=1)",
        (username, "manager"),
    ).fetchone()
    if not user or not password_ok(password, user["password_hash"]):
        FAILED_LOGINS[key].append(stamp)
        return {"error": "اسم المستخدم أو كلمة المرور غير صحيحة"}, 401, None
    FAILED_LOGINS.pop(key, None)
    token = secrets.token_urlsafe(32)
    connection.execute("DELETE FROM sessions WHERE expires_at<?", (stamp,))
    connection.execute(
        "INSERT INTO sessions VALUES(?,?,?)",
        (hashlib.sha256(token.encode()).hexdigest(), user["id"], stamp + 28800),
    )
    cookie = (
        SESSION_COOKIE + "=" + token +
        "; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800" + ("; Secure" if os.environ.get("NAZEMLY_CLOUD_DEMO") == "1" else "")
    )
    return {"ok": True}, 200, cookie


def logout(connection, cookie_header):
    token = next(
        (part.strip().split("=", 1)[1]
         for part in cookie_header.split(";")
         if part.strip().startswith(SESSION_COOKIE + "=")),
        "",
    )
    if token:
        connection.execute(
            "DELETE FROM sessions WHERE token_hash=?",
            (hashlib.sha256(token.encode()).hexdigest(),),
        )
    return SESSION_COOKIE + "=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0" + ("; Secure" if os.environ.get("NAZEMLY_CLOUD_DEMO") == "1" else "")
