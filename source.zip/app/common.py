"""Shared validation and arithmetic. Amounts are stored as integer piasters."""
import datetime as dt
import hashlib
import hmac
import json
import re
import secrets
from decimal import Decimal, ROUND_HALF_UP
from zoneinfo import ZoneInfo

def payroll_divisor(connection):
    row = connection.execute("SELECT value FROM settings WHERE key = 'payroll_divisor'").fetchone()
    return json.loads(row[0])

def cairo_today():
    return dt.datetime.now(ZoneInfo('Africa/Cairo')).date()

def now():
    return dt.datetime.utcnow().isoformat(timespec='seconds') + 'Z'

def money(n):
    return int((Decimal(str(n)) * 100).quantize(Decimal('1'), rounding=ROUND_HALF_UP))

def text(v, maximum=100, required=True):
    if not isinstance(v, str) or len(v.strip()) > maximum or (required and (not v.strip())):
        raise ValueError('راجع الحقول المطلوبة وطول النص')
    return v.strip()

def integer(v, low, high):
    if isinstance(v, bool):
        raise ValueError('قيمة رقمية غير صحيحة')
    n = int(v)
    if str(n) != str(v) or not low <= n <= high:
        raise ValueError('القيمة خارج النطاق المسموح')
    return n

def salary_value(v):
    n = Decimal(str(v))
    if not n.is_finite() or n < 0 or n > 10000000:
        raise ValueError('المرتب غير صحيح')
    return money(n)

def month_value(v):
    if not re.fullmatch('\\d{4}-\\d{2}', str(v)):
        raise ValueError('الشهر غير صحيح')
    dt.datetime.strptime(v, '%Y-%m')
    return v

def day_value(v):
    if not re.fullmatch('\\d{4}-\\d{2}-\\d{2}', str(v)):
        raise ValueError('التاريخ غير صحيح')
    dt.date.fromisoformat(v)
    return v

def clock(v):
    if not isinstance(v, str) or not re.fullmatch('\\d{2}:\\d{2}', v):
        raise ValueError('الوقت غير صحيح')
    t = dt.datetime.strptime(v, '%H:%M')
    return t.hour * 60 + t.minute

def penalty(late):
    return 0 if late <= 30 else 1 if late < 45 else 2 if late < 60 else 4

def password_hash(password, salt=None):
    salt = salt or secrets.token_hex(16)
    return salt + ':' + hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 160000).hex()

def password_ok(p, encoded):
    salt = encoded.split(':')[0]
    return hmac.compare_digest(password_hash(p, salt), encoded)

def audit(connection, user, action, entity):
    connection.execute('INSERT INTO audit(user_id,action,entity,created_at) VALUES(?,?,?,?)', (user['id'], action, str(entity), now()))

def active_employee(connection, eid):
    row = connection.execute('SELECT * FROM employees WHERE id=? AND active=1', (eid,)).fetchone()
    if not row:
        raise ValueError('الموظف غير موجود أو حسابه غير نشط')
    return row

def editable_month(connection, eid, month):
    if connection.execute("SELECT 1 FROM payroll WHERE employee_id=? AND month=? AND status='approved'", (eid, month)).fetchone():
        raise ValueError('كشف الشهر معتمد؛ لا يمكن تعديل بياناته')

def refresh_drafts(connection, eid, month=None):
    employee = connection.execute('SELECT salary_cents FROM employees WHERE id=?', (eid,)).fetchone()
    rows = connection.execute("SELECT * FROM payroll WHERE employee_id=? AND status='draft'" + (' AND month=?' if month else ''), (eid, month) if month else (eid,)).fetchall()
    for row in rows:
        quarters = connection.execute('SELECT COALESCE(SUM(penalty_quarters),0) FROM attendance WHERE employee_id=? AND substr(day,1,7)=?', (eid, row['month'])).fetchone()[0]
        base = employee['salary_cents']
        deduction = min(base, int((Decimal(base) * quarters / (4 * payroll_divisor(connection))).quantize(Decimal('1'), rounding=ROUND_HALF_UP)))
        connection.execute('UPDATE payroll SET base_cents=?,deduction_cents=?,net_cents=?,penalty_quarters=?,divisor=? WHERE id=?', (base, deduction, base + row['bonus_cents'] - deduction, quarters, payroll_divisor(connection), row['id']))
