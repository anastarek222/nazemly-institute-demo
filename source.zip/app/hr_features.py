from common import text, integer, active_employee, audit, now, day_value, salary_value, cairo_today, password_hash, password_ok, clock, editable_month, refresh_drafts
from storage import DB_PATH, SCHEMA as BASE_SCHEMA
'Accounts, leave requests, tasks, notifications and JSON backup and staff management.'
import sales
import attendance
import os
import datetime as dt, json, re, sqlite3, time
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP
from zoneinfo import ZoneInfo
DEFAULTS = {'company_name': 'نظملي',
 'work_start': '09:00',
 'work_end': '17:00',
 'grace_minutes': 30,
 'quarter_until': 45,
 'half_until': 60,
 'absence_days': 3,
 'payroll_divisor': 30,
 'weight_quality': 40,
 'weight_productivity': 40,
 'weight_teamwork': 20,
 'departments': ['المبيعات', 'الموارد البشرية', 'التشغيل', 'الحسابات']}
SCHEMA = """
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,
    value TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS leave_requests(id INTEGER PRIMARY KEY,
    employee_id INTEGER NOT NULL REFERENCES employees(id),
    start_day TEXT NOT NULL,
    end_day TEXT NOT NULL,
    reason TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending',
    'approved',
    'rejected',
    'cancelled')),
    decision_note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    decided_at TEXT);

CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY,
    employee_id INTEGER NOT NULL REFERENCES employees(id),
    title TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    due_day TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'todo' CHECK(status IN ('todo',
    'doing',
    'done')),
    created_by INTEGER NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY,
    employee_id INTEGER REFERENCES employees(id),
    message TEXT NOT NULL,
    created_at TEXT NOT NULL,
    read_at TEXT);

CREATE UNIQUE INDEX IF NOT EXISTS users_employee_unique ON users(employee_id) WHERE employee_id IS NOT NULL;
"""
TABLES = ['employees',
 'users',
 'attendance',
 'reviews',
 'payroll',
 'audit',
 'settings',
 'leave_requests',
 'tasks',
 'notifications',
 'daily_targets',
 'sales']

def init(connection):
    connection.executescript(SCHEMA)
    sales.init(connection)
    migrations = {'users': {'enabled': 'INTEGER NOT NULL DEFAULT 1',
                            'onboarding_seen_at': 'TEXT'},
     'reviews': {'weight_quality': 'INTEGER NOT NULL DEFAULT 40',
                 'weight_productivity': 'INTEGER NOT NULL DEFAULT 40',
                 'weight_teamwork': 'INTEGER NOT NULL DEFAULT 20'},
     'payroll': {'divisor': 'INTEGER NOT NULL DEFAULT 30'},
     'attendance': {'source': "TEXT NOT NULL DEFAULT 'manual'",
                    'started_at_utc': 'TEXT',
                    'ended_at_utc': 'TEXT'}}
    for (table, cols) in migrations.items():
        existing = {r[1] for r in connection.execute('PRAGMA table_info(' + table + ')')}
        for (name, typ) in cols.items():
            if name not in existing:
                connection.execute('ALTER TABLE ' + table + ' ADD COLUMN ' + name + ' ' + typ)
    for (k, v) in DEFAULTS.items():
        connection.execute('INSERT OR IGNORE INTO settings VALUES(?,?)', (k, json.dumps(v, ensure_ascii=False)))
    connection.execute("UPDATE settings SET value=? WHERE key='company_name' AND value=?", (json.dumps('نظملي', ensure_ascii=False), json.dumps('نَظْم', ensure_ascii=False)))
    attendance.migrate(connection, settings(connection))
    connection.execute('PRAGMA user_version=4')

def settings(connection):
    return {r['key']: json.loads(r['value']) for r in connection.execute('SELECT * FROM settings')}

def policy(connection, late):
    s = settings(connection)
    return 0 if late <= s['grace_minutes'] else 1 if late < s['quarter_until'] else 2 if late < s['half_until'] else 4

def divisor(connection):
    return settings(connection)['payroll_divisor']

def score(r):
    return round(sum((r[k] * r['weight_' + k] for k in ('quality', 'productivity', 'teamwork'))) / 100, 1)

def notify(connection, eid, message, stamp):
    connection.execute('INSERT INTO notifications(employee_id,message,created_at) VALUES(?,?,?)', (eid, message, stamp))

def extra_state(connection, user, month):
    manager = user['role'] == 'manager'
    eid = user['employee_id']
    params = () if manager else (eid,)
    where = '' if manager else ' WHERE employee_id=?'
    leaves = [dict(r) for r in connection.execute('SELECT * FROM leave_requests' + where + ' ORDER BY created_at DESC LIMIT 200', params)]
    tasks = [dict(r) for r in connection.execute('SELECT * FROM tasks' + where + ' ORDER BY due_day,id DESC LIMIT 300', params)]
    notifications = [dict(r) for r in connection.execute('SELECT * FROM notifications WHERE ' + ('employee_id IS NULL' if manager else 'employee_id=?') + ' ORDER BY id DESC LIMIT 100', params)]
    accounts = [dict(r) for r in connection.execute('SELECT id,username,role,employee_id,enabled FROM users ORDER BY id')] if manager else []
    end = dt.date.fromisoformat(month + '-01')
    months = []
    for _ in range(6):
        months.append(end.strftime('%Y-%m'))
        end = (end.replace(day=1) - dt.timedelta(days=1)).replace(day=1)
    scope = '' if manager else ' AND employee_id=?'
    history = []
    for m in reversed(months):
        args = (m,) if manager else (m, eid)
        rows = [dict(r) for r in connection.execute('SELECT * FROM reviews WHERE month=?' + scope, args)]
        a = connection.execute("SELECT COUNT(*) AS records,COALESCE(SUM(status='present'),0) AS present FROM attendance WHERE substr(day,1,7)=?" + scope, args).fetchone()
        history.append({'month': m, 'score': round(sum((score(r) for r in rows)) / len(rows), 1) if rows else None, 'present': a['present'], 'records': a['records']})
    today = dt.datetime.now(ZoneInfo('Africa/Cairo')).date().isoformat()
    today_row = connection.execute('SELECT * FROM attendance WHERE employee_id=? AND day=?', (eid, today)).fetchone() if not manager else None
    safe_settings = settings(connection)
    return {
        'today_attendance': attendance.timing(today_row) if today_row else None,
        'settings': safe_settings,
        'accounts': accounts,
        'leaves': leaves,
        'tasks': tasks,
        'notifications': notifications,
        'history': history,
        'today': dt.datetime.now(ZoneInfo('Africa/Cairo')).date().isoformat(),
    }

def export_backup(connection, stamp):
    return {'format': 'nazm-hr-backup', 'mode': 'demo' if os.environ.get('HR_DEMO_MODE') == '1' else 'normal', 'version': 4, 'created_at': stamp, 'tables': {t: [dict(r) for r in connection.execute('SELECT * FROM ' + t)] for t in TABLES}}

def route(connection, user, path, body):
    stamp = now()
    manager = user['role'] == 'manager'
    eid = user['employee_id']
    manager_routes = {'/api/accounts/save', '/api/accounts/state', '/api/accounts/reset', '/api/settings', '/api/leaves/decide', '/api/tasks/save', '/api/backup/restore'}
    routes = manager_routes | {'/api/password', '/api/onboarding/ack', '/api/attendance/self', '/api/leaves/request', '/api/leaves/cancel', '/api/tasks/status', '/api/notifications/read'}
    if path not in routes:
        return None
    if path in manager_routes and (not manager):
        return ({'error': 'هذه العملية للمدير فقط'}, 403)
    if path == '/api/onboarding/ack':
        if manager:
            raise ValueError('الترحيب مخصص للموظفين')
        connection.execute('UPDATE users SET onboarding_seen_at=COALESCE(onboarding_seen_at,?) WHERE id=?', (stamp, user['id']))
    elif path == '/api/accounts/save':
        target = integer(body.get('employee_id'), 1, 1000000)
        active_employee(connection, target)
        username = text(body.get('username'), 40)
        if not re.fullmatch('[A-Za-z0-9_.-]{3,40}', username):
            raise ValueError('اسم المستخدم: 3–40 حرفًا إنجليزيًا أو رقمًا أو . أو _ أو -')
        password = text(body.get('password'), 200)
        if len(password) < 8:
            raise ValueError('كلمة المرور لا تقل عن 8 أحرف')
        if connection.execute('SELECT 1 FROM users WHERE employee_id=?', (target,)).fetchone():
            raise ValueError('للموظف حساب بالفعل؛ استخدم إعادة تعيين كلمة المرور')
        connection.execute("INSERT INTO users(username,password_hash,role,employee_id) VALUES(?,?,'employee',?)", (username, password_hash(password), target))
        audit(connection, user, 'إنشاء حساب موظف', target)
    elif path in ('/api/accounts/state', '/api/accounts/reset'):
        uid = integer(body.get('id'), 1, 1000000)
        account = connection.execute("SELECT * FROM users WHERE id=? AND role='employee'", (uid,)).fetchone()
        if not account:
            raise ValueError('حساب الموظف غير موجود')
        if path.endswith('state'):
            enabled = integer(body.get('enabled'), 0, 1)
            connection.execute('UPDATE users SET enabled=? WHERE id=?', (enabled, uid))
            audit(connection, user, 'تغيير حالة حساب', uid)
        else:
            password = text(body.get('password'), 200)
            if len(password) < 8:
                raise ValueError('كلمة المرور لا تقل عن 8 أحرف')
            connection.execute('UPDATE users SET password_hash=? WHERE id=?', (password_hash(password), uid))
            audit(connection, user, 'إعادة تعيين كلمة مرور', uid)
        connection.execute('DELETE FROM sessions WHERE user_id=?', (uid,))
    elif path == '/api/password':
        if not password_ok(text(body.get('current_password'), 200), user['password_hash']):
            raise ValueError('كلمة المرور الحالية غير صحيحة')
        password = text(body.get('new_password'), 200)
        if len(password) < 8:
            raise ValueError('كلمة المرور الجديدة لا تقل عن 8 أحرف')
        connection.execute('UPDATE users SET password_hash=? WHERE id=?', (password_hash(password), user['id']))
        connection.execute('DELETE FROM sessions WHERE user_id=?', (user['id'],))
        audit(connection, user, 'تغيير كلمة المرور', user['id'])
        return ({'ok': True, 'logout': True}, 200)
    elif path == '/api/attendance/self':
        if manager:
            raise ValueError('تسجيل الحضور الذاتي متاح لحساب الموظف')
        active_employee(connection, eid)
        local = dt.datetime.now(ZoneInfo('Africa/Cairo'))
        date = local.date().isoformat()
        tm = local.strftime('%H:%M')
        editable_month(connection, eid, date[:7])
        s = settings(connection)
        row = connection.execute('SELECT * FROM attendance WHERE employee_id=? AND day=?', (eid, date)).fetchone()
        if body.get('kind') == 'in':
            if row:
                raise ValueError('يوجد سجل بالفعل لهذا اليوم')
            late = max(0, clock(tm) - clock(s['work_start']))
            connection.execute("INSERT INTO attendance(employee_id,day,status,scheduled,check_in,late_minutes,penalty_quarters,note) VALUES(?,?,'present',?,?,?,?,'تسجيل ذاتي بتوقيت الخادم')", (eid, date, s['work_start'], tm, late, policy(connection, late)))
            connection.execute("UPDATE attendance SET source='self',started_at_utc=?,scheduled_end=? WHERE employee_id=? AND day=?", (stamp, s['work_end'], eid, date))
        elif body.get('kind') == 'out':
            if not row or row['status'] != 'present':
                raise ValueError('سجّل الحضور أولًا')
            if row['check_out']:
                raise ValueError('تم تسجيل الانصراف بالفعل')
            if clock(tm) < clock(row['check_in']):
                raise ValueError('وقت الانصراف غير صحيح')
            connection.execute('UPDATE attendance SET check_out=?,revision=revision+1 WHERE id=?', (tm, row['id']))
            connection.execute('UPDATE attendance SET ended_at_utc=? WHERE id=?', (stamp, row['id']))
        else:
            raise ValueError('نوع التسجيل غير صحيح')
        refresh_drafts(connection, eid, date[:7])
        audit(connection, user, 'حضور ذاتي' if body['kind'] == 'in' else 'انصراف ذاتي', date)
    elif path == '/api/leaves/request':
        if manager:
            raise ValueError('طلب الإجازة من حساب الموظف')
        active_employee(connection, eid)
        start = day_value(body.get('start_day'))
        end = day_value(body.get('end_day'))
        length = (dt.date.fromisoformat(end) - dt.date.fromisoformat(start)).days + 1
        if not 1 <= length <= 31 or start < cairo_today().isoformat():
            raise ValueError('اختر فترة من اليوم أو بعده، بحد أقصى 31 يومًا')
        if connection.execute("SELECT 1 FROM leave_requests WHERE employee_id=? AND status IN ('pending','approved') AND start_day<=? AND end_day>=?", (eid, end, start)).fetchone():
            raise ValueError('الفترة تتداخل مع طلب موجود')
        reason = text(body.get('reason'), 500)
        connection.execute('INSERT INTO leave_requests(employee_id,start_day,end_day,reason,created_at) VALUES(?,?,?,?,?)', (eid, start, end, reason, stamp))
        notify(connection, None, 'طلب إجازة جديد: ' + active_employee(connection, eid)['name'], stamp)
        audit(connection, user, 'طلب إجازة', eid)
    elif path == '/api/leaves/cancel':
        rid = integer(body.get('id'), 1, 1000000)
        row = connection.execute('SELECT * FROM leave_requests WHERE id=?', (rid,)).fetchone()
        if not row or (not manager and row['employee_id'] != eid):
            return ({'error': 'الطلب غير موجود'}, 404)
        if row['status'] != 'pending':
            raise ValueError('يمكن إلغاء الطلبات المعلقة فقط')
        connection.execute("UPDATE leave_requests SET status='cancelled',decided_at=? WHERE id=?", (stamp, rid))
        audit(connection, user, 'إلغاء طلب إجازة', rid)
    elif path == '/api/leaves/decide':
        rid = integer(body.get('id'), 1, 1000000)
        row = connection.execute('SELECT * FROM leave_requests WHERE id=?', (rid,)).fetchone()
        if not row or row['status'] != 'pending':
            raise ValueError('الطلب غير موجود أو تم البت فيه')
        active_employee(connection, row['employee_id'])
        status = body.get('status')
        note = text(body.get('decision_note', ''), 500, False)
        if status not in ('approved', 'rejected'):
            raise ValueError('قرار غير صحيح')
        if status == 'rejected' and (not note):
            raise ValueError('اكتب سبب الرفض')
        if status == 'approved':
            start = dt.date.fromisoformat(row['start_day'])
            end = dt.date.fromisoformat(row['end_day'])
            days = [(start + dt.timedelta(days=i)).isoformat() for i in range((end - start).days + 1)]
            for date in days:
                editable_month(connection, row['employee_id'], date[:7])
                exists = connection.execute("SELECT 1 FROM attendance WHERE employee_id=? AND day=? AND status!='leave'", (row['employee_id'], date)).fetchone()
                if exists:
                    raise ValueError('الإجازة تتعارض مع سجل حضور أو غياب في ' + date)
            for date in days:
                connection.execute("INSERT INTO attendance(employee_id,day,status,note) VALUES(?,?,'leave',?) ON CONFLICT(employee_id,day) DO NOTHING", (row['employee_id'], date, 'إجازة معتمدة #' + str(rid)))
                connection.execute("UPDATE attendance SET source='approved_leave',scheduled_end=? WHERE employee_id=? AND day=?", (settings(connection)['work_end'], row['employee_id'], date))
                refresh_drafts(connection, row['employee_id'], date[:7])
        connection.execute('UPDATE leave_requests SET status=?,decision_note=?,decided_at=? WHERE id=?', (status, note, stamp, rid))
        notify(connection, row['employee_id'], 'تم ' + ('قبول' if status == 'approved' else 'رفض') + ' طلب الإجازة من ' + row['start_day'] + ' إلى ' + row['end_day'] + (' — ' + note if note else ''), stamp)
        audit(connection, user, 'قرار إجازة', rid)
    elif path == '/api/tasks/save':
        target = integer(body.get('employee_id'), 1, 1000000)
        active_employee(connection, target)
        title = text(body.get('title'), 150)
        description = text(body.get('description', ''), 1000, False)
        due = day_value(body.get('due_day'))
        tid = body.get('id')
        if tid:
            tid = integer(tid, 1, 1000000)
            if not connection.execute('SELECT 1 FROM tasks WHERE id=?', (tid,)).fetchone():
                raise ValueError('المهمة غير موجودة')
            connection.execute('UPDATE tasks SET employee_id=?,title=?,description=?,due_day=?,updated_at=? WHERE id=?', (target, title, description, due, stamp, tid))
        else:
            tid = connection.execute('INSERT INTO tasks(employee_id,title,description,due_day,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?)', (target, title, description, due, user['id'], stamp, stamp)).lastrowid
        notify(connection, target, 'مهمة: ' + title + ' — موعد التسليم ' + due, stamp)
        audit(connection, user, 'حفظ مهمة', tid)
    elif path == '/api/tasks/status':
        tid = integer(body.get('id'), 1, 1000000)
        row = connection.execute('SELECT * FROM tasks WHERE id=?', (tid,)).fetchone()
        if not row or (not manager and row['employee_id'] != eid):
            return ({'error': 'المهمة غير موجودة'}, 404)
        status = body.get('status')
        if status not in ('todo', 'doing', 'done'):
            raise ValueError('حالة المهمة غير صحيحة')
        connection.execute('UPDATE tasks SET status=?,updated_at=? WHERE id=?', (status, stamp, tid))
        if not manager:
            notify(connection, None, 'تحديث مهمة ' + row['title'] + ' — ' + {'todo': 'لم تبدأ', 'doing': 'قيد التنفيذ', 'done': 'مكتملة'}[status], stamp)
        audit(connection, user, 'تحديث حالة مهمة', tid)
    elif path == '/api/notifications/read':
        connection.execute('UPDATE notifications SET read_at=? WHERE ' + ('employee_id IS NULL' if manager else 'employee_id=?'), (stamp,) if manager else (stamp, eid))
    elif path == '/api/settings':
        s = {}
        s['company_name'] = text(body.get('company_name'), 80)
        for k in ('work_start', 'work_end'):
            s[k] = text(body.get(k))
            clock(s[k])
        if clock(s['work_end']) <= clock(s['work_start']):
            raise ValueError('نهاية العمل يجب أن تكون بعد بدايته')
        for (k, low, high) in [('grace_minutes', 0, 120), ('quarter_until', 1, 180), ('half_until', 2, 240), ('absence_days', 0, 5), ('payroll_divisor', 1, 31), ('weight_quality', 0, 100), ('weight_productivity', 0, 100), ('weight_teamwork', 0, 100)]:
            s[k] = integer(body.get(k), low, high)
        if not s['grace_minutes'] < s['quarter_until'] < s['half_until']:
            raise ValueError('حدود التأخير يجب أن تكون تصاعدية')
        if sum((s[k] for k in ('weight_quality', 'weight_productivity', 'weight_teamwork'))) != 100:
            raise ValueError('مجموع أوزان التقييم يجب أن يساوي 100')
        deps = body.get('departments')
        if not isinstance(deps, list) or not 1 <= len(deps) <= 30:
            raise ValueError('أضف قسمًا واحدًا على الأقل وبحد أقصى 30')
        s['departments'] = list(dict.fromkeys((text(v, 60) for v in deps)))
        for (k, v) in s.items():
            connection.execute('UPDATE settings SET value=? WHERE key=?', (json.dumps(v, ensure_ascii=False), k))
        for row in connection.execute('SELECT id FROM employees').fetchall():
            refresh_drafts(connection, row['id'])
        audit(connection, user, 'تعديل إعدادات الشركة', 'settings')
    elif path == '/api/backup/restore':
        if not password_ok(text(body.get('password'), 200), user['password_hash']):
            raise ValueError('كلمة مرور المدير غير صحيحة')
        backup = body.get('backup')
        if not isinstance(backup, dict) or backup.get('format') != 'nazm-hr-backup' or backup.get('version') not in (3, 4):
            raise ValueError('ملف النسخة غير صالح أو إصدار غير مدعوم')
        current_mode = 'demo' if os.environ.get('HR_DEMO_MODE') == '1' else 'normal'
        if backup.get('mode', current_mode) != current_mode:
            raise ValueError('ملف النسخة يخص وضع تشغيل مختلف؛ افتح نسخة العرض أو النسخة العادية المناسبة')
        backup = json.loads(json.dumps(backup))
        if backup['version'] == 3:
            old_settings = {row['key']: json.loads(row['value']) for row in backup['tables']['settings']}
            for row in backup['tables']['attendance']:
                row.setdefault('scheduled_end', old_settings['work_end'])
                row.setdefault('revision', 0)
            backup['version'] = 4
        tables = backup.get('tables')
        if isinstance(tables, dict) and isinstance(tables.get('users'), list):
            for account in tables['users']:
                if isinstance(account, dict):
                    account.setdefault('onboarding_seen_at', None)
        if not isinstance(tables, dict) or set(tables) != set(TABLES):
            raise ValueError('جداول النسخة غير مكتملة')
        for table in TABLES:
            rows = tables[table]
            cols = {r[1] for r in connection.execute('PRAGMA table_info(' + table + ')')}
            if not isinstance(rows, list) or len(rows) > 50000 or any((not isinstance(r, dict) or set(r) != cols for r in rows)):
                raise ValueError('صيغة جدول غير صحيحة: ' + table)
        if not any((r.get('role') == 'manager' and r.get('enabled') == 1 and (r.get('username') == user['username']) and password_ok(text(body['password'], 200), r.get('password_hash', '')) for r in tables['users'])):
            raise ValueError('النسخة يجب أن تحتوي حساب المدير الحالي وكلمة مروره')
        validate_settings = {r['key']: json.loads(r['value']) for r in tables['settings']}
        if set(validate_settings) != set(DEFAULTS):
            raise ValueError('إعدادات النسخة غير مكتملة')
        for account in tables['users']:
            if account['enabled'] not in (0, 1) or (account['role'] == 'employee' and account['employee_id'] is None):
                raise ValueError('حساب غير صالح في النسخة')
        scratch = sqlite3.connect(':memory:')
        scratch.row_factory = sqlite3.Row
        scratch.execute('PRAGMA foreign_keys=ON')
        scratch.executescript(BASE_SCHEMA)
        init(scratch)
        for table in reversed(TABLES):
            scratch.execute('DELETE FROM ' + table)
        for table in TABLES:
            for row in tables[table]:
                cols = list(row)
                scratch.execute('INSERT INTO ' + table + '(' + ','.join(cols) + ') VALUES(' + ','.join(('?' for _ in cols)) + ')', list(row.values()))
        scratch_owner = scratch.execute('SELECT * FROM users WHERE username=?', (user['username'],)).fetchone()
        route(scratch, scratch_owner, '/api/settings', validate_settings)
        if scratch.execute('PRAGMA foreign_key_check').fetchall():
            raise ValueError('علاقات البيانات غير سليمة')
        scratch.close()
        snapshots = DB_PATH.parent / 'backups'
        snapshots.mkdir(exist_ok=True)
        target = snapshots / ('before-restore-' + str(time.time_ns()) + '.sqlite3')
        dest = sqlite3.connect(str(target))
        connection.backup(dest)
        dest.close()
        connection.execute('DELETE FROM sessions')
        for table in reversed(TABLES):
            connection.execute('DELETE FROM ' + table)
        for table in TABLES:
            for row in tables[table]:
                cols = list(row)
                connection.execute('INSERT INTO ' + table + '(' + ','.join(cols) + ') VALUES(' + ','.join(('?' for _ in cols)) + ')', list(row.values()))
        owner = connection.execute('SELECT * FROM users WHERE username=?', (user['username'],)).fetchone()
        audit(connection, owner, 'استعادة نسخة احتياطية', backup['created_at'])
        if current_mode == 'demo':
            from demo_seed import enhance_team
            enhance_team(connection)
        return ({'ok': True, 'logout': True}, 200)
    return ({'ok': True}, 200)
