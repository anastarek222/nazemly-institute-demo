"""Shared deterministic language, date, pay and privacy helpers for the assistant."""
import datetime as dt
import re
import unicodedata
from decimal import Decimal, ROUND_HALF_UP

from common import cairo_today


def normalized(value):
    value = unicodedata.normalize("NFKC", value).lower().strip()
    value = re.sub(r"[\u064b-\u065f\u0670\u0640]", "", value)
    value = value.translate(str.maketrans("أإآٱىة", "اااايه"))
    value = value.translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789"))
    return re.sub(r"\s+", " ", value)


def includes(question, *phrases):
    return any(normalized(phrase) in question for phrase in phrases)


def money(cents, english):
    if cents is None:
        return "—"
    amount = f"{cents / 100:,.2f}".rstrip("0").rstrip(".")
    return ("EGP " + amount) if english else (amount + " جنيه")


def period_for_question(question, selected_month, today=None):
    """Explicit relative periods are relative to Cairo today; otherwise use selected month."""
    q = normalized(question) if isinstance(question, str) else ""
    today = today or cairo_today()
    month = selected_month
    day = None
    if includes(q, "الشهر اللي فات", "الشهر الفات", "الشهر السابق", "الشهر الماضي",
                "الشهر اللى فات", "last month", "previous month"):
        month = (today.replace(day=1) - dt.timedelta(days=1)).strftime("%Y-%m")
    elif includes(q, "الشهر ده", "الشهر دا", "الشهر الحالي", "this month"):
        month = today.strftime("%Y-%m")
    if includes(q, "بكره", "بكرا", "غدا", "tomorrow"):
        day = (today + dt.timedelta(days=1)).isoformat()
    elif includes(q, "امبارح", "بالامس", "yesterday"):
        day = (today - dt.timedelta(days=1)).isoformat()
    elif includes(q, "النهارده", "النهاردا", "اليوم", "today"):
        day = today.isoformat()
    if day:
        month = day[:7]
    return month, day


def salary_penalty_cents(base_cents, quarters, divisor):
    # Same total-penalty rounding as refresh_drafts / payroll approval.
    return min(base_cents, int(
        (Decimal(base_cents) * quarters / (4 * divisor))
        .quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    ))


def colleague_pay_request(connection, user, q, own):
    # Avoid reporting the existence or salary of any colleague to staff.
    others = connection.execute(
        "SELECT name FROM employees WHERE id != ?", (user["employee_id"],)
    ).fetchall()
    own_first = normalized(own["name"]).split()[0] if own else ""
    tokens = set(re.findall(r"[\w]+", q))
    if includes(q, "زميلي", "زميلتي", "الزميل", "موظف اخر", "موظف ثاني",
                "مرتب الموظفين", "مرتبات الموظفين", "رواتب الموظفين",
                "their salary", "coworker", "colleague", "other employee"):
        return True
    for person in others:
        full = normalized(person["name"])
        first = full.split()[0]
        if full in q or (first != own_first and first in tokens):
            return True
    # A name after "مرتب" means another person unless it is clearly self,
    # a month/status descriptor or a pronoun.
    match = re.search(r"(?:مرتب|راتب|قبض)\s+([\w]+)", q)
    if match:
        nxt = match.group(1)
        generic = {
            "الشهر", "شهر", "السنه", "السنة", "الاساسي", "الصافي", "كام", "قد",
            "بتاعي", "بتاعى", "انا", "الخاص", "ده", "دا", "اللي", "السابق",
            "اتعمد", "اتوافق", "اتصرف", "بعد", "قبل", "عندي", "الحالي",
        }
        if nxt not in generic and nxt != own_first:
            return True
    after_en = re.search(r'\b(?:salary|payroll|pay)\s+(?:of\s+)?([a-z]+)', q)
    before_en = re.search(r'\b([a-z]+)\s+(?:salary|payroll)\b', q)
    generic_en = {'my', 'own', 'this', 'last', 'next', 'the', 'for', 'status',
                  'approved', 'draft', 'is', 'was', 'current', 'base',
                  'monthly', 'net', 'deduction', 'details', 'amount', 'month'}
    if after_en and after_en.group(1) not in generic_en:
        return True
    if before_en and before_en.group(1) not in generic_en:
        return True
    return False
