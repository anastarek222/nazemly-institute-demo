"""Seed records for the separate demo database."""
import datetime as dt
import json
from common import now, refresh_drafts


def context(connection):
    row = connection.execute(
        "SELECT entity FROM audit WHERE action LIKE 'تهيئة%' ORDER BY id LIMIT 1"
    ).fetchone()
    return json.loads(row['entity']) if row else {}


def seed(connection, today):
    if context(connection):
        enhance_team(connection)
        return
    month_end = today.replace(day=1) - dt.timedelta(days=1)
    focus_day = month_end
    while focus_day.weekday() in (4, 5):  # Fictional company: Friday and Saturday off.
        focus_day -= dt.timedelta(days=1)
    day = focus_day.isoformat()
    month = day[:7]
    stamp = now()
    # Synthetic records for a complete prior work month, not fabricated dashboard totals.
    for number in range(1, month_end.day + 1):
        date = month_end.replace(day=number)
        if date.weekday() in (4, 5):
            continue
        for employee_id in range(1, 5):
            focus = date == focus_day
            if focus and employee_id == 3:
                continue  # This missing record must be reviewed by the manager.
            leave = focus and employee_id == 4
            late = focus and employee_id == 1
            checkout = None if (leave or focus and employee_id == 2) else '17:00'
            connection.execute(
                'INSERT INTO attendance(employee_id,day,status,scheduled,scheduled_end,'
                'check_in,check_out,late_minutes,penalty_quarters,note,source) '
                'VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                (employee_id, date.isoformat(), 'leave' if leave else 'present',
                 '09:00', '17:00', None if leave else '09:40' if late else '09:00',
                 checkout, 40 if late else 0, 1 if late else 0,
                 'بيانات عرض لشركة افتراضية تعمل من الأحد للخميس',
                 'approved_leave' if leave else 'manual'),
            )
    connection.execute(
        'INSERT INTO daily_targets(employee_id,day,amount_cents,note,assigned_by,updated_at) '
        "VALUES(1,?,500000,'مثال هدف 5,000 جنيه',1,?)", (day, stamp),
    )
    for index, amount in enumerate((200000, 150000, 250000), 1):
        approved = index < 3
        connection.execute(
            'INSERT INTO sales(employee_id,day,reference,customer,amount_cents,status,note,'
            'submitted_by,created_at,decided_by,decided_at,decision_note) '
            'VALUES(1,?,?,?,?,?,?,1,?,?,?,?)',
            (day, f'DEMO-{day}-{index}', f'عميل تجريبي {index}', amount,
             'approved' if approved else 'pending', 'عملية مبيعات',
             stamp, 1 if approved else None, stamp if approved else None,
             'اعتماد ضمن بيانات العرض' if approved else ''),
        )
    connection.execute(
        'INSERT INTO payroll(employee_id,month,base_cents,bonus_cents,deduction_cents,'
        'net_cents,penalty_quarters,created_at,divisor) VALUES(1,?,900000,0,0,900000,0,?,30)',
        (month, stamp),
    )
    refresh_drafts(connection, 1, month)
    connection.execute(
        'INSERT INTO audit(user_id,action,entity,created_at) VALUES(1,?,?,?)',
        ('تهيئة بيانات العرض', json.dumps({'month': month, 'day': day}), stamp),
    )
    enhance_team(connection)


def enhance_team(connection):
    """Complete the existing demo month without touching the regular database."""
    info = context(connection)
    if not info:
        return
    # Keep user-facing records clean, including older isolated demo databases.
    connection.execute("UPDATE attendance SET note='' WHERE note IN ('بيانات تجريبية','بيانات عرض لشركة افتراضية تعمل من الأحد للخميس')")
    connection.execute("UPDATE reviews SET note='' WHERE note='تقييم تجريبي'")
    if connection.execute(
        "SELECT 1 FROM audit WHERE action='تجهيز فريق العرض' LIMIT 1"
    ).fetchone():
        return
    from common import password_hash
    import os
    month, focus = info['month'], info['day']
    start = dt.date.fromisoformat(month + '-01')
    end = (start.replace(day=28) + dt.timedelta(days=4)).replace(day=1)
    dates = [start + dt.timedelta(days=n) for n in range((end-start).days)]
    dates = [date.isoformat() for date in dates if date.weekday() not in (4, 5)]
    stamp = now()
    for eid, username in ((2, 'sara_demo'), (3, 'omar_demo'), (4, 'mariam_demo')):
        if not connection.execute('SELECT 1 FROM users WHERE employee_id=?', (eid,)).fetchone():
            connection.execute(
                "INSERT INTO users(username,password_hash,role,employee_id) VALUES(?,?,'employee',?)",
                (username, password_hash(os.environ.get('NAZEMLY_EMPLOYEE_PASSWORD', 'Welcome@12345') if os.environ.get('NAZEMLY_CLOUD_DEMO') == '1' else 'Welcome@12345'), eid))
    jobs = (
        (1, 'متابعة العملاء', 'تابع العملاء وسجّل نتائج المكالمات.'),
        (2, 'تحديث ملفات الموظفين', 'راجع ملفات الفريق والطلبات المفتوحة.'),
        (3, 'تجهيز تقرير التشغيل', 'اجمع مؤشرات التشغيل وراجع الحالات الناقصة.'),
        (4, 'مراجعة حسابات الشهر', 'راجع المصروفات والمستندات وقسائم المرتبات.'),
    )
    for eid, title, description in jobs:
        connection.execute(
            'INSERT INTO tasks(employee_id,title,description,due_day,created_by,created_at,updated_at) '
            "VALUES(?,?,?,?,1,?,?)",
            (eid, title, description, focus, stamp, stamp))
    for eid, amount in ((1,500000), (2,300000), (3,200000)):
        for day in dates:
            connection.execute(
                "INSERT OR IGNORE INTO daily_targets(employee_id,day,amount_cents,note,assigned_by,updated_at) "
                "VALUES(?,?,?,'',1,?)", (eid, day, amount, stamp))

    for eid, amount in ((1,420000), (2,210000), (3,150000)):
        for day in dates:
            if day == focus:
                continue
            reference = 'TEAM-%s-%s' % (eid, day)
            connection.execute(
                "INSERT OR IGNORE INTO sales(employee_id,day,reference,customer,amount_cents,"
                "status,note,submitted_by,created_at,decided_by,decided_at,decision_note) "
                "VALUES(?,?,?,?,?,'approved','',1,?,1,?,'')",
                (eid, day, reference, 'عميل ' + reference, amount, stamp, stamp))
    # Give each employee a distinct salary situation, without overriding approvals.
    for eid in (2,3):
        if connection.execute(
            "SELECT 1 FROM payroll WHERE employee_id=? AND month=? AND status='approved'",
            (eid, month)).fetchone():
            continue
        example_day = next(day for day in dates if day != focus)
        if eid == 2:
            connection.execute(
                "UPDATE attendance SET status='absent',check_in=NULL,check_out=NULL,"
                "late_minutes=0,penalty_quarters=12,note='' "
                "WHERE employee_id=? AND day=? AND source='manual'",
                (eid, example_day))
        else:
            connection.execute(
                "UPDATE attendance SET check_in='09:55',late_minutes=55,"
                "penalty_quarters=2,note='' "
                "WHERE employee_id=? AND day=? AND source='manual'",
                (eid, example_day))
    for eid in range(1, 5):
        person = connection.execute(
            'SELECT salary_cents FROM employees WHERE id=?', (eid,)).fetchone()
        if not person:
            continue
        connection.execute(
            'INSERT OR IGNORE INTO payroll(employee_id,month,base_cents,bonus_cents,'
            'deduction_cents,net_cents,penalty_quarters,created_at,divisor) '
            'VALUES(?,?,?,0,0,?,0,?,30)',
            (eid, month, person['salary_cents'], person['salary_cents'], stamp))
        refresh_drafts(connection, eid, month)
    connection.execute(
        "UPDATE attendance SET note='' WHERE note='بيانات عرض لشركة افتراضية تعمل من الأحد للخميس'")
    connection.execute(
        "UPDATE sales SET note='',decision_note=CASE WHEN status='approved' THEN '' ELSE decision_note END "
        "WHERE note='عملية مبيعات'")
    connection.execute(
        "UPDATE sales SET customer=REPLACE(customer,'عميل تجريبي','عميل') "
        "WHERE customer LIKE 'عميل تجريبي %'")
    connection.execute(
        "INSERT INTO audit(user_id,action,entity,created_at) VALUES(1,'تجهيز فريق العرض',?,?)",
        (month, stamp))
