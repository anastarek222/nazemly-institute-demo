"""HTTP routes for the employee management app. Run: python3 app/server.py"""
import argparse
import os
import demo_seed
import datetime as dt
import hashlib
import json
import sqlite3
from decimal import Decimal, ROUND_HALF_UP
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
import hr_features as features
import sales
import attendance
import assistant_rules
import auth
import demo_reset
from storage import PUBLIC, DB_PATH, SCHEMA, db
from common import cairo_today, now, money, text, integer, salary_value, month_value, day_value, clock, penalty, password_hash, password_ok, audit, active_employee, editable_month, refresh_drafts

def init():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with db() as connection:
        connection.executescript(SCHEMA)
        features.init(connection)
        if connection.execute('SELECT COUNT(*) FROM users').fetchone()[0]:
            return
        # Only the demo and isolated QA need built-in example employees.
        sample_mode = os.environ.get('HR_DEMO_MODE') == '1' or os.environ.get('HR_SEED_EXAMPLES') == '1'
        examples = [('أحمد محمد', 'المبيعات', 'مسؤول مبيعات', '', 900000), ('سارة علي', 'الموارد البشرية', 'أخصائية موارد بشرية', '', 1050000), ('عمر حسن', 'التشغيل', 'منسق عمليات', '', 800000), ('مريم خالد', 'الحسابات', 'محاسبة', '', 1100000)] if sample_mode else []
        for row in examples:
            connection.execute('INSERT INTO employees(name,department,title,phone,salary_cents,created_at) VALUES(?,?,?,?,?,?)', row + (now(),))
        connection.execute('INSERT INTO users(username,password_hash,role) VALUES(?,?,?)', ('admin', password_hash(os.environ.get('NAZEMLY_ADMIN_PASSWORD', 'Admin@12345') if os.environ.get('NAZEMLY_CLOUD_DEMO') == '1' else 'Admin@12345'), 'manager'))
        if not sample_mode:
            return
        connection.execute('INSERT INTO users(username,password_hash,role,employee_id) VALUES(?,?,?,?)', ('employee', password_hash(os.environ.get('NAZEMLY_EMPLOYEE_PASSWORD', 'Employee@12345') if os.environ.get('NAZEMLY_CLOUD_DEMO') == '1' else 'Employee@12345'), 'employee', 1))
        today = cairo_today()
        for employee_id in range(1, 5):
            days = [today - dt.timedelta(days=i) for i in range(1, min(today.day, 8))]
            for (i, d) in enumerate(days):
                status = 'absent' if employee_id == 3 and i == 2 else 'present'
                late = 40 if employee_id == 1 and i == 1 else 0
                connection.execute('INSERT INTO attendance(employee_id,day,status,scheduled,check_in,check_out,late_minutes,penalty_quarters,note) VALUES(?,?,?,?,?,?,?,?,?)', (employee_id, d.isoformat(), status, '09:00', '09:40' if late else '09:00' if status == 'present' else None, '17:00' if status == 'present' else None, late, 12 if status == 'absent' else penalty(late), ''))
            for offset in (0, 1):
                base = today.replace(day=1) - dt.timedelta(days=1) if offset else today
                m = base.strftime('%Y-%m')
                connection.execute('INSERT INTO reviews(employee_id,month,quality,productivity,teamwork,note) VALUES(?,?,?,?,?,?)', (employee_id, m, 85 + employee_id - offset * 3, 80 + employee_id * 2 - offset * 4, 90 - offset * 2, ''))
        attendance.migrate(connection, features.settings(connection))

def state(connection, user, month):
    manager = user['role'] == 'manager'
    eid = user['employee_id']
    where = '' if manager else ' WHERE id=?'
    employees = [dict(r) for r in connection.execute('SELECT * FROM employees' + where, () if manager else (eid,))]
    params = (month,) if manager else (month, eid)
    extra = '' if manager else ' AND employee_id=?'
    attendance_rows = [attendance.timing(r) for r in connection.execute('SELECT * FROM attendance WHERE substr(day,1,7)=?' + extra + ' ORDER BY day DESC,employee_id', params)]
    reviews = [dict(r) for r in connection.execute('SELECT * FROM reviews WHERE month=?' + extra, params)]
    previous = (dt.date.fromisoformat(month + '-01') - dt.timedelta(days=1)).strftime('%Y-%m')
    old = {r['employee_id']: r for r in connection.execute('SELECT * FROM reviews WHERE month=?' + extra, (previous,) if manager else (previous, eid))}
    for r in reviews:
        r['score'] = features.score(r)
        p = old.get(r['employee_id'])
        r['previous_score'] = features.score(p) if p else None
    payroll = [dict(r) for r in connection.execute('SELECT * FROM payroll WHERE month=?' + extra + ' ORDER BY employee_id', params)]
    logs = [dict(r) for r in connection.execute('SELECT action,entity,created_at FROM audit ORDER BY id DESC LIMIT 30')] if manager else []
    demo_mode = os.environ.get('HR_DEMO_MODE') == '1'
    demo = demo_seed.context(connection) if demo_mode else {}
    return {
        'demo_mode': demo_mode, 'demo_month': demo.get('month'), 'demo_day': demo.get('day'),
        'user': {k: user[k] for k in ('id', 'username', 'role', 'employee_id')},
        'onboarding_pending': not manager and not user['onboarding_seen_at'],
        'security_setup_required': auth.must_change_admin_password(user),
        'demo_reset_allowed': demo_reset.allowed() and manager,
        'employees': employees,
        'attendance': attendance_rows,
        'reviews': reviews,
        'payroll': payroll,
        'audit': logs,
        'month': month,
        **features.extra_state(connection, user, month),
        **sales.extra_state(connection, user, month),
        **attendance.extra_state(connection, user, month),
    }
class Handler(SimpleHTTPRequestHandler):

    def __init__(self, *a, **kw):
        super().__init__(*a, directory=str(PUBLIC), **kw)

    def log_message(self, fmt, *args):
        if not self.path.startswith('/api/state'):
            super().log_message(fmt, *args)

    def end_headers(self):
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'")
        super().end_headers()

    def reply(self, obj, status=200, cookie=None):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        if cookie:
            self.send_header('Set-Cookie', cookie)
        self.end_headers()
        self.wfile.write(body)

    def session(self, connection):
        return auth.session(connection, self.headers.get('Cookie', ''))

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == '/api/health':
            database_id = hashlib.sha256(str(DB_PATH).encode()).hexdigest()[:12]
            return self.reply({'app':'nazemly', 'database_id':database_id, 'demo':os.environ.get('HR_DEMO_MODE')=='1'})
        if parsed.path == '/api/state':
            with db() as connection:
                user = self.session(connection)
                if not user:
                    return self.reply({'error': 'سجل الدخول أولًا'}, 401)
                try:
                    return self.reply(state(connection, user, month_value(parse_qs(parsed.query).get('month', [cairo_today().strftime('%Y-%m')])[0])))
                except ValueError as e:
                    return self.reply({'error': str(e)}, 400)
        if parsed.path == '/api/backup/export':
            with db() as connection:
                user = self.session(connection)
                if not user:
                    return self.reply({'error': 'سجل الدخول أولًا'}, 401)
                if user['role'] != 'manager':
                    return self.reply({'error': 'هذه العملية للمدير فقط'}, 403)
                if auth.must_change_admin_password(user):
                    return self.reply({'error': 'غيّر كلمة مرور المدير أولًا'}, 403)
                return self.reply(features.export_backup(connection, now()))
        if parsed.path.startswith('/api/'):
            return self.reply({'error': 'المسار غير موجود'}, 404)
        public_pages = {
            '/': '/site-home.html',
            '/home': '/site-home.html',
            '/features': '/site-features.html',
            '/how-it-works': '/site-how.html',
            '/login': '/index.html',
        }
        if parsed.path in public_pages:
            # These are static pages: no personal records are rendered here.
            self.path = public_pages[parsed.path]
            return super().do_GET()
        static_files = (
            '/index.html', '/site-home.html', '/site-features.html',
            '/site-how.html', '/public-site.css', '/public-site.js',
            '/dashboard-preview.png', '/sales-preview.png',
            '/app.js', '/style.css', '/components.css', '/assistant.css',
            '/dashboard.css', '/people.js', '/features.js',
            '/feature_actions.js', '/reports.js', '/sales.js', '/review.js',
            '/i18n.js', '/welcome.js', '/icons.js', '/assistant.js',
        )
        if parsed.path not in static_files:
            return self.reply({'error': 'غير موجود'}, 404)
        return super().do_GET()

    def do_POST(self):
        origin = self.headers.get('Origin')
        if origin and urlparse(origin).netloc != self.headers.get('Host'):
            return self.reply({'error': 'مصدر الطلب غير مسموح'}, 403)
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if size > (5000000 if urlparse(self.path).path == '/api/backup/restore' else 20000):
                return self.reply({'error': 'طلب كبير'}, 413)
            body = json.loads(self.rfile.read(size))
            if not isinstance(body, dict):
                raise ValueError('طلب غير صحيح')
            path = urlparse(self.path).path
            with db() as connection:
                if path == '/api/login':
                    result, status, cookie = auth.login(
                        connection, body, self.client_address[0]
                    )
                    return self.reply(result, status, cookie)
                user = self.session(connection)
                if not user:
                    return self.reply({'error': 'سجل الدخول أولًا'}, 401)
                if path == '/api/logout':
                    return self.reply(
                        {'ok': True}, cookie=auth.logout(
                            connection, self.headers.get('Cookie', '')
                        ),
                    )
                if auth.must_change_admin_password(user) and path != '/api/password':
                    return self.reply(
                        {'error': 'غيّر كلمة مرور المدير أولًا من قائمة الحساب'}, 403
                    )
                if path == '/api/demo/reset':
                    result = demo_reset.reset(connection, user, body)
                    return self.reply(result[0], result[1])
                if path == '/api/assistant/ask':
                    selected_month = month_value(
                        body.get('month', cairo_today().strftime('%Y-%m'))
                    )
                    effective_month, _ = assistant_rules.period_for_question(
                        body.get('question'), selected_month
                    )
                    scoped_state = state(connection, user, effective_month)
                    return self.reply(
                        assistant_rules.answer(connection, user, scoped_state, body)
                    )
                extra = sales.route(connection, user, path, body)
                if extra is not None:
                    return self.reply(extra[0], extra[1])
                extra = features.route(connection, user, path, body)
                if extra is not None:
                    return self.reply(extra[0], extra[1])
                if user['role'] != 'manager':
                    return self.reply({'error': 'هذه العملية للمدير فقط'}, 403)
                if path == '/api/employees':
                    eid = body.get('id')
                    vals = (text(body.get('name')), text(body.get('department')), text(body.get('title')), text(body.get('phone', ''), 30, False), salary_value(body.get('salary')))
                    if eid:
                        active_employee(connection, eid)
                        connection.execute('UPDATE employees SET name=?,department=?,title=?,phone=?,salary_cents=? WHERE id=?', vals + (eid,))
                        refresh_drafts(connection, eid)
                    else:
                        eid = connection.execute('INSERT INTO employees(name,department,title,phone,salary_cents,created_at) VALUES(?,?,?,?,?,?)', vals + (now(),)).lastrowid
                    audit(connection, user, 'حفظ بيانات موظف', eid)
                elif path == '/api/employees/archive':
                    eid = integer(body.get('id'), 1, 1000000)
                    active_employee(connection, eid)
                    connection.execute('UPDATE employees SET active=0 WHERE id=?', (eid,))
                    audit(connection, user, 'أرشفة موظف', eid)
                elif path == '/api/attendance':
                    attendance.manual_record(connection, user, body, features.settings(connection), features.policy)
                    refresh_drafts(connection, integer(body.get('employee_id'), 1, 1000000), body['day'][:7])
                elif path == '/api/reviews':
                    eid = integer(body.get('employee_id'), 1, 1000000)
                    active_employee(connection, eid)
                    month = month_value(body.get('month'))
                    vals = (eid, month, integer(body.get('quality'), 0, 100), integer(body.get('productivity'), 0, 100), integer(body.get('teamwork'), 0, 100), text(body.get('note', ''), 500, False))
                    connection.execute('INSERT INTO reviews(employee_id,month,quality,productivity,teamwork,note) VALUES(?,?,?,?,?,?) ON CONFLICT(employee_id,month) DO UPDATE SET quality=excluded.quality,productivity=excluded.productivity,teamwork=excluded.teamwork,note=excluded.note', vals)
                    weights = features.settings(connection)
                    connection.execute('UPDATE reviews SET weight_quality=?,weight_productivity=?,weight_teamwork=? WHERE employee_id=? AND month=?', (weights['weight_quality'], weights['weight_productivity'], weights['weight_teamwork'], eid, month))
                    audit(connection, user, 'حفظ تقييم', str(eid) + ' / ' + month)
                elif path == '/api/payroll/generate':
                    month = month_value(body.get('month'))
                    people = connection.execute('SELECT * FROM employees WHERE active=1').fetchall()
                    for e in people:
                        if connection.execute("SELECT 1 FROM payroll WHERE employee_id=? AND month=? AND status='approved'", (e['id'], month)).fetchone():
                            continue
                        q = connection.execute('SELECT COALESCE(SUM(penalty_quarters),0) FROM attendance WHERE employee_id=? AND substr(day,1,7)=?', (e['id'], month)).fetchone()[0]
                        deduction = min(e['salary_cents'], int((Decimal(e['salary_cents']) * q / (4 * features.divisor(connection))).quantize(Decimal('1'), rounding=ROUND_HALF_UP)))
                        connection.execute('INSERT INTO payroll(employee_id,month,base_cents,bonus_cents,deduction_cents,net_cents,penalty_quarters,created_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(employee_id,month) DO UPDATE SET base_cents=excluded.base_cents,deduction_cents=excluded.deduction_cents,net_cents=excluded.base_cents+payroll.bonus_cents-excluded.deduction_cents,penalty_quarters=excluded.penalty_quarters,created_at=excluded.created_at', (e['id'], month, e['salary_cents'], 0, deduction, e['salary_cents'] - deduction, q, now()))
                    connection.execute("UPDATE payroll SET divisor=? WHERE month=? AND status='draft'", (features.divisor(connection), month))
                    audit(connection, user, 'حساب مسودات المرتبات', month)
                elif path in ('/api/payroll/approve', '/api/payroll/bonus'):
                    pid = integer(body.get('id'), 1, 1000000)
                    p = connection.execute('SELECT * FROM payroll WHERE id=?', (pid,)).fetchone()
                    if not p:
                        raise ValueError('كشف المرتب غير موجود')
                    if p['status'] == 'approved':
                        raise ValueError('كشف المرتب معتمد بالفعل ولا يقبل التعديل')
                    if path.endswith('approve'):
                        checks = attendance.approval_check(connection, p, body)
                        changed = connection.execute(
                            "UPDATE payroll SET status='approved' WHERE id=? AND status='draft' "
                            'AND base_cents=? AND bonus_cents=? AND deduction_cents=? AND net_cents=?',
                            (pid,) + tuple(p[key] for key in attendance.MONEY_FIELDS),
                        ).rowcount
                        if changed != 1:
                            raise ValueError('الكشف تغير أثناء المراجعة؛ حدّث الصفحة')
                        evidence = {'payroll_id': pid, 'employee_id': p['employee_id'], 'month': p['month'],
                                    'confirmed': True, 'warnings': checks['warnings'], 'amounts': body['expected']}
                        audit(connection, user, 'اعتماد مرتب', json.dumps(evidence, ensure_ascii=False))
                        features.notify(connection, p['employee_id'], 'تم اعتماد مرتب شهر ' + p['month'], now())
                    else:
                        bonus = salary_value(body.get('bonus'))
                        connection.execute('UPDATE payroll SET bonus_cents=?,net_cents=base_cents+?-deduction_cents WHERE id=?', (bonus, bonus, pid))
                        audit(connection, user, 'تعديل مكافأة', pid)
                else:
                    return self.reply({'error': 'المسار غير موجود'}, 404)
                return self.reply({'ok': True})
        except (ValueError, TypeError, KeyError, ArithmeticError, OverflowError) as e:
            self.reply({'error': str(e) or 'راجع البيانات المدخلة'}, 400)
        except sqlite3.IntegrityError:
            self.reply({'error': 'البيانات متعارضة مع سجل موجود'}, 409)
        except Exception:
            import traceback
            traceback.print_exc()
            self.reply({'error': 'تعذر تنفيذ العملية'}, 500)
if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--port', type=int, default=4178)
    args = p.parse_args()
    init()
    if os.environ.get('HR_DEMO_MODE') == '1':
        with db() as connection:
            demo_seed.seed(connection, cairo_today())
        snapshot = DB_PATH.parent / 'demo-initial.json'
        if not snapshot.exists():
            with db() as connection:
                snapshot.write_text(json.dumps(features.export_backup(connection, now()), ensure_ascii=False), encoding='utf-8')
    print('Nazemly: http://127.0.0.1:' + str(args.port), flush=True)
    ThreadingHTTPServer(('127.0.0.1', args.port), Handler).serve_forever()
