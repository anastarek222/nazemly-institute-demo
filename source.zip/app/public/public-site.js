'use strict';

// Public pages are static. No employee or payroll data is loaded here.
const publicLabels = [...document.querySelectorAll('[data-en]')];
for (const element of publicLabels) {
  element.dataset.originalHtml = element.innerHTML;
}
const pageNames = {
  home: ['الرئيسية', 'Home'],
  features: ['المميزات', 'Features'],
  how: ['طريقة العمل', 'How it works'],
};
const publicPage = document.body.dataset.sitePage || 'home';
const activeLink = document.querySelector('.desktop-nav [data-nav="' + publicPage + '"]');
if (activeLink) activeLink.setAttribute('aria-current', 'page');

function applyPublicLanguage(language) {
  const english = language === 'en';
  document.documentElement.lang = english ? 'en' : 'ar';
  document.documentElement.dir = english ? 'ltr' : 'rtl';
  document.title = (english ? pageNames[publicPage][1] : pageNames[publicPage][0]) +
    (english ? ' | Nazemly' : ' | نظملي');
  for (const element of publicLabels) {
    if (english) element.textContent = element.dataset.en;
    else element.innerHTML = element.dataset.originalHtml;
  }
  for (const image of document.querySelectorAll('[data-alt-en]')) {
    if (!image.dataset.originalAlt) image.dataset.originalAlt = image.alt;
    image.alt = english ? image.dataset.altEn : image.dataset.originalAlt;
  }
  for (const toggle of document.querySelectorAll('[data-switch-lang]')) {
    toggle.textContent = english ? 'العربية' : 'English';
    toggle.setAttribute('aria-label', english ? 'التبديل إلى العربية' : 'Switch to English');
  }
}

let publicLanguage = 'ar';
try {
  publicLanguage = localStorage.getItem('nazemly.language') === 'en' ? 'en' : 'ar';
} catch (error) {
  // The pages still work when browser storage is unavailable.
}
applyPublicLanguage(publicLanguage);

document.addEventListener('click', (event) => {
  const toggle = event.target.closest('[data-switch-lang]');
  if (!toggle) return;
  publicLanguage = publicLanguage === 'ar' ? 'en' : 'ar';
  try { localStorage.setItem('nazemly.language', publicLanguage); } catch (error) {}
  applyPublicLanguage(publicLanguage);
});

// Returning users can open their workspace directly from the main address.
// Other public pages remain readable even if a session is active.
if (location.pathname === '/') {
  fetch('/api/state', {credentials: 'same-origin'})
    .then((response) => {
      if (response.ok) location.replace('/login');
    })
    .catch(() => {});
}

// Home page: interactive previews use real, isolated demo screenshots.
// All controls are manual; no fabricated activity or live employee information.
if (publicPage === 'home') {
  const roleButtons = Array.from(document.querySelectorAll('[data-role-switch]'));
  const roleScenes = Array.from(document.querySelectorAll('[data-role-scene]'));
  const featureButtons = Array.from(document.querySelectorAll('[data-feature-tab]'));
  const featurePanels = Array.from(document.querySelectorAll('[data-feature-panel]'));

  function selectRole(role) {
    if (!roleScenes.some((scene) => scene.dataset.roleScene === role)) return;
    for (const button of roleButtons) {
      const active = button.dataset.roleSwitch === role;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-pressed', String(active));
    }
    for (const scene of roleScenes) {
      scene.hidden = scene.dataset.roleScene !== role;
    }
  }

  function selectFeature(feature, focus) {
    if (!featurePanels.some((panel) => panel.dataset.featurePanel === feature)) return;
    for (const button of featureButtons) {
      const active = button.dataset.featureTab === feature;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-selected', String(active));
      button.tabIndex = active ? 0 : -1;
      if (active && focus) button.focus();
    }
    for (const panel of featurePanels) {
      panel.hidden = panel.dataset.featurePanel !== feature;
    }
  }

  for (const button of roleButtons) {
    button.addEventListener('click', () => selectRole(button.dataset.roleSwitch));
  }
  for (const button of featureButtons) {
    button.id = 'feature-tab-' + button.dataset.featureTab;
    button.addEventListener('click', () => selectFeature(button.dataset.featureTab, false));
    button.addEventListener('keydown', (event) => {
      const nextKeys = ['ArrowDown', 'ArrowRight'];
      const prevKeys = ['ArrowUp', 'ArrowLeft'];
      if (![...nextKeys, ...prevKeys, 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      const current = featureButtons.indexOf(button);
      const index = event.key === 'Home' ? 0 :
        event.key === 'End' ? featureButtons.length - 1 :
        (current + (nextKeys.includes(event.key) ? 1 : -1) + featureButtons.length) % featureButtons.length;
      selectFeature(featureButtons[index].dataset.featureTab, true);
    });
  }
  selectRole('manager');
  selectFeature('attendance', false);
  for (const link of document.querySelectorAll('[data-feature-jump]')) {
    link.addEventListener('click', () => selectFeature(link.dataset.featureJump, false));
  }

  // Motion is optional and respects the visitor's system accessibility settings.
  const reducesMotion = window.matchMedia &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!reducesMotion && 'IntersectionObserver' in window) {
    const targets = Array.from(document.querySelectorAll('.reveal'));
    if (targets.length) {
      document.body.classList.add('enhance-motion');
      const observer = new IntersectionObserver((entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        }
      }, { threshold: 0.08, rootMargin: '0px 0px 35px 0px' });
      for (const item of targets) observer.observe(item);
    }
  }
  document.querySelectorAll('.mobile-navigation a').forEach((link) => {
    link.addEventListener('click', () => {
      const details = link.closest('.mobile-navigation');
      if (details) details.open = false;
    });
  });
}
