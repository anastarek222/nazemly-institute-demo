'use strict';
/* Employee, attendance, payroll and evaluation screens; app.js owns shared UI. */
function openEmployee(id) {
  const e = data.employees.find((e) => e.id == id) || {};
  formOpen(
    id ? ui('تعديل بيانات موظف') : ui('إضافة موظف'),
    'employee',
    id,
    field(
      ui('الاسم الكامل'),
      'name',
      e.name || '',
      'text',
      'required maxlength="100"',
    ) +
      field(
        ui('القسم'),
        'department',
        e.department || '',
        'text',
        'required maxlength="100" list="department-options"',
      ) +
      field(
        ui('المسمى الوظيفي'),
        'title',
        e.title || '',
        'text',
        'required maxlength="100"',
      ) +
      field(ui('رقم الهاتف'), 'phone', e.phone || '', 'tel', 'maxlength="30"') +
      field(
        ui('المرتب الأساسي — جنيه'),
        'salary',
        (e.salary_cents || 0) / 100,
        'number',
        'required min="0" max="10000000" step=".01"',
      ) +
      ui(
        '<p class="hint wide">تعديل البيانات لا يغيّر كشوف المرتبات المعتمدة. يمكنك إنشاء حساب دخول للموظف من قائمة الموظفين.</p>',
      ),
  );
}
function openAttendance(id) {
  const a = data.attendance.find((x) => x.id == id) || {};
  formOpen(
    id ? ui('تعديل سجل حضور') : ui('تسجيل حضور'),
    'attendance',
    id,
    selectField(ui('الموظف'), 'employee_id', employeeOptions(a.employee_id)) +
      field(
        ui('التاريخ'),
        'day',
        a.day || today(),
        'date',
        'required max="' + today() + '"',
      ) +
      selectField(
        ui('الحالة'),
        'status',
        [
          ['present', ui('حضور')],
          ['absent', ui('غياب بدون إذن')],
          ['leave', ui('إجازة بإذن')],
        ]
          .map(
            ([v, n]) =>
              '<option value="' +
              v +
              '" ' +
              (a.status === v ? 'selected' : '') +
              '>' +
              n +
              '</option>',
          )
          .join(''),
      ) +
      field(
        ui('بداية العمل'),
        'scheduled',
        a.scheduled || data.settings.work_start,
        'time',
        'required',
      ) +
      field(
        ui('وقت الحضور'),
        'check_in',
        a.check_in || data.settings.work_start,
        'time',
        'required',
      ) +
      field(ui('وقت الانصراف'), 'check_out', a.check_out || '', 'time') +
      field(
        ui('نهاية الدوام المتوقعة'),
        'scheduled_end',
        a.scheduled_end || data.settings.work_end,
        'time',
        'required',
      ) +
      ui(
        '<label class="wide">ملاحظات<textarea dir="auto" name="note" maxlength="500">',
      ) +
      esc(a.note || '') +
      '</textarea></label>' +
      (id
        ? ui(
            '<label class="wide">سبب التصحيح (إلزامي)<textarea dir="auto" name="change_reason" required maxlength="500"></textarea></label><input type="hidden" name="expected_revision" value="',
          ) +
          a.revision +
          '">'
        : '') +
      ui(
        '<p class="hint wide">سجل واحد لكل موظف في اليوم. الإجازة بإذن دون خصم. المواعيد محلية بتوقيت القاهرة، والشيفت داخل نفس اليوم.</p>',
      ),
  );
  if (id) {
    const f = $('#modal form');
    f.elements.day.readOnly = true;
    f.elements.employee_id.disabled = true;
    const h = document.createElement('input');
    h.type = 'hidden';
    h.name = 'employee_id';
    h.value = String(a.employee_id);
    f.append(h);
  }
  attendanceFields();
}
function attendanceFields() {
  const f = $('#modal form');
  if (!f || f.dataset.kind !== 'attendance') return;
  const present = f.elements.status.value === 'present';
  for (const key of ['check_in', 'check_out']) {
    f.elements[key].disabled = !present;
    f.elements[key].required = key === 'check_in' && present;
  }
}
function openReview(id) {
  const r = data.reviews.find((x) => x.id == id) || {};
  formOpen(
    id ? ui('تعديل تقييم شهري') : ui('تقييم موظف'),
    'review',
    id,
    selectField(ui('الموظف'), 'employee_id', employeeOptions(r.employee_id)) +
      field(ui('شهر التقييم'), 'month', r.month || month, 'month', 'required') +
      field(
        ui('جودة العمل — ') + data.settings.weight_quality + '%',
        'quality',
        r.quality ?? 80,
        'number',
        'min="0" max="100" required',
      ) +
      field(
        ui('إنجاز المهام — ') + data.settings.weight_productivity + '%',
        'productivity',
        r.productivity ?? 80,
        'number',
        'min="0" max="100" required',
      ) +
      field(
        ui('التعاون — ') + data.settings.weight_teamwork + '%',
        'teamwork',
        r.teamwork ?? 80,
        'number',
        'min="0" max="100" required',
      ) +
      ui(
        '<label class="wide">ملاحظات المدير<textarea dir="auto" name="note" maxlength="500">',
      ) +
      esc(r.note || '') +
      ui(
        '</textarea></label><p class="hint wide">كل معيار من 100. النتيجة تحسب بالأوزان الحالية من صفحة الإعدادات.</p>',
      ),
  );
}
function attendanceTable(rows, edit = true) {
  const manager = data.user.role === 'manager';
  return table(
    [
      ui('الموظف'),
      ui('التاريخ'),
      ui('الحالة'),
      ui('الحضور / الانصراف'),
      ui('التأخير'),
      ui('أيام الجزاء'),
      ui('مصدر الوقت'),
      ...(manager && edit ? [''] : []),
    ],
    rows.map((a) => [
      esc(employee(a.employee_id)),
      esc(a.day),
      tag(
        a.status === 'present'
          ? ui('حاضر')
          : a.status === 'leave'
            ? ui('إجازة بإذن')
            : ui('غائب'),
        a.status === 'present'
          ? 'green'
          : a.status === 'leave'
            ? 'blue'
            : 'red',
      ),
      esc((a.check_in || '—') + ' / ' + (a.check_out || '—')),
      a.late_minutes + ui(' د'),
      a.penalty_quarters / 4,
      attendanceSource(a),
      ...(manager && edit ? [attendanceEditButton(a)] : []),
    ]),
  );
}
function employeesPage() {
  const filtered = data.employees.filter((e) =>
    (e.name + ' ' + e.department + ' ' + e.title)
      .toLowerCase()
      .includes(search.toLowerCase()),
  );
  return (
    ui(
      '<section class="panel"><div class="toolbar"><input id="search" class="search" placeholder="ابحث بالاسم أو القسم أو الوظيفة…" value="',
    ) +
    esc(search) +
    '">' +
    (data.user.role === 'manager'
      ? button(ui('+ إضافة موظف'), 'employee-new')
      : '') +
    '</div><div id="employees-table">' +
    employeesTable(filtered) +
    '</div></section>'
  );
}
function employeesTable(rows) {
  return table(
    [
      ui('الموظف'),
      ui('القسم'),
      ui('الوظيفة'),
      ui('المرتب الأساسي'),
      ui('الحالة'),
      ...(data.user.role === 'manager' ? [ui('الإجراءات')] : []),
    ],
    rows.map((e) => [
      '<div class="person"><span class="avatar">' +
        esc(e.name.charAt(0)) +
        '</span><div><strong>' +
        esc(e.name) +
        '</strong><small>' +
        esc(e.phone) +
        '</small></div></div>',
      esc(e.department),
      esc(e.title),
      cash(e.salary_cents),
      tag(e.active ? ui('نشط') : ui('مؤرشف'), e.active ? 'green' : ''),
      ...(data.user.role === 'manager'
        ? [
            e.active
              ? accountControls(e.id) +
                ' ' +
                button(ui('تعديل'), 'employee-edit', e.id, 'secondary small') +
                ' ' +
                button(
                  ui('أرشفة'),
                  'employee-archive',
                  e.id,
                  'text-button danger',
                )
              : '—',
          ]
        : []),
    ]),
  );
}
function payrollPage() {
  return (
    '<div class="stats three">' +
    stat(
      ui('إجمالي الأساسي'),
      cash(data.payroll.reduce((s, p) => s + p.base_cents, 0)),
      ui('للكشوف المحسوبة'),
    ) +
    stat(
      ui('إجمالي الخصومات'),
      cash(data.payroll.reduce((s, p) => s + p.deduction_cents, 0)),
      ui('حسب سجلات الشهر'),
    ) +
    stat(
      ui('صافي المستحقات'),
      cash(data.payroll.reduce((s, p) => s + p.net_cents, 0)),
      ui('بعد المكافآت والخصومات'),
    ) +
    ui(
      '</div><section class="panel"><div class="toolbar"><div><h3>كشف مرتبات ',
    ) +
    esc(month) +
    ui('</h3><p class="subtle">راجع المسودات قبل الاعتماد.</p></div>') +
    (data.user.role === 'manager'
      ? button(ui('حساب / تحديث المسودات'), 'payroll-generate')
      : '') +
    '</div>' +
    table(
      [
        ui('الموظف'),
        ui('الأساسي'),
        ui('الجزاء / يوم'),
        ui('الخصم'),
        ui('المكافأة'),
        ui('الصافي'),
        ui('الحالة'),
        ...(data.user.role === 'manager' ? [ui('الإجراءات')] : []),
      ],
      data.payroll.map((p) => [
        esc(employee(p.employee_id)),
        cash(p.base_cents),
        p.penalty_quarters / 4,
        cash(p.deduction_cents),
        cash(p.bonus_cents),
        '<strong>' +
          cash(p.net_cents) +
          '</strong><br>' +
          button(ui('قسيمة'), 'payslip', p.id, 'text-button'),
        tag(
          p.status === 'approved' ? ui('معتمد') : ui('مسودة'),
          p.status === 'approved' ? 'green' : 'amber',
        ),
        ...(data.user.role === 'manager'
          ? [
              p.status === 'draft'
                ? button(
                    ui('مكافأة'),
                    'payroll-bonus',
                    p.id,
                    'secondary small',
                  ) +
                  ' ' +
                  button(ui('اعتماد'), 'payroll-approve', p.id, 'primary small')
                : ui('محفوظ ومعتمد'),
            ]
          : []),
      ]),
    ) +
    ui(
      '</section>',
    )
  );
}
function reviewsPage() {
  return (
    ui(
      '<section class="panel"><h3>تطور تقييمات المدير اليدوية — آخر 6 شهور</h3>',
    ) +
    historyChart() +
    ui(
      '</section><section class="panel"><div class="toolbar"><div><h3>تقييم المدير — إدخال يدوي</h3><p class="subtle">الأوزان الحالية: جودة ',
    ) +
    data.settings.weight_quality +
    ui('% · إنجاز ') +
    data.settings.weight_productivity +
    ui('% · تعاون ') +
    data.settings.weight_teamwork +
    ui('%. يحتفظ كل تقييم سابق بأوزانه.</p></div>') +
    (data.user.role === 'manager'
      ? button(ui('+ تقييم موظف'), 'review-new')
      : '') +
    '</div>' +
    table(
      [
        ui('الموظف'),
        ui('الجودة'),
        ui('الإنجاز'),
        ui('التعاون'),
        ui('النتيجة'),
        ui('مقارنة بالشهر السابق'),
        ...(data.user.role === 'manager' ? [''] : []),
      ],
      data.reviews.map((r) => [
        esc(employee(r.employee_id)),
        r.quality + '%',
        r.productivity + '%',
        r.teamwork + '%',
        '<strong>' + r.score + '%</strong>',
        r.previous_score == null
          ? ui('لا يوجد تقييم سابق')
          : tag(
              (r.score - r.previous_score > 0
                ? ui('تحسن +')
                : r.score - r.previous_score < 0
                  ? ui('تراجع ')
                  : ui('ثبات ')) +
                (r.score - r.previous_score).toFixed(1) +
                ui(' نقطة'),
              r.score >= r.previous_score ? 'green' : 'red',
            ),
        ...(data.user.role === 'manager'
          ? [button(ui('تعديل'), 'review-edit', r.id, 'secondary small')]
          : []),
      ]),
    ) +
    '</section>' +
    data.reviews
      .filter((r) => r.note)
      .map(
        (r) =>
          '<article class="note"><strong>' +
          esc(employee(r.employee_id)) +
          '</strong><p>' +
          esc(r.note) +
          '</p></article>',
      )
      .join('')
  );
}
