/* Sales screens. Every total comes from database transactions in data.sales. */
names.sales = ui('التارجت والمبيعات');
names.reviews = ui('تقييم المدير');
icons.sales = 'target';
let selectedSalesDay = '';
let salesEmployeeFilter = 'all';
let salesRange = 'day';
function navigationEntries() {
  const primary = [
    'overview',
    'employees',
    'attendance',
    'sales',
    'payroll',
    'reports',
  ];
  const support = [
    'profile',
    'tasks',
    'leaves',
    'reviews',
    'notifications',
    'settings',
  ];
  return [...primary, ...support]
    .filter((key) => key !== 'settings' || data.user.role === 'manager')
    .map((key) => [key, names[key]]);
}
function percent(value) {
  return value === null || value === undefined
    ? ui('غير متاح')
    : value.toFixed(1) + '%';
}
function monthlyTotals() {
  const rows = data.sales_summary;
  const target = rows.reduce((sum, row) => sum + row.target_cents, 0);
  const approved = rows.reduce((sum, row) => sum + row.approved_cents, 0);
  const matched = rows.reduce((sum, row) => sum + row.matched_cents, 0);
  return {
    target,
    approved,
    matched,
    achievement: target ? (matched * 100) / target : null,
  };
}
function employeeFocus() {
  const todayDay = data.today;
  const upcoming = data.tasks
    .filter((t) => t.status !== 'done')
    .slice().sort((a, b) => a.due_day.localeCompare(b.due_day));
  const next = upcoming[0];
  const currentMonth = month === todayDay.slice(0, 7);
  const dailyTarget = currentMonth
    ? data.targets.filter((t) => t.day === todayDay)
       .reduce((n, t) => n + t.amount_cents, 0)
    : null;
  const dailySales = currentMonth
    ? data.sales.filter((s) => s.day === todayDay && s.status === 'approved')
       .reduce((n, s) => n + s.amount_cents, 0)
    : null;
  const taskLine = next
    ? '<strong>' + esc(next.title) + '</strong><small>' +
      (next.due_day < todayDay ? ui('متأخرة') + ' · ' : '') +
      esc(next.due_day) + '</small>'
    : '<strong>' + ui('مفيش مهام مفتوحة') + '</strong>';
  const targetLine = dailyTarget === null
    ? '<strong>' + ui('اختار الشهر الحالي') + '</strong>' +
      button(ui('عرض الشهر الحالي'), 'current-month', '', 'secondary small')
    : dailyTarget
      ? '<strong>' + cash(dailySales || 0) + ' / ' + cash(dailyTarget) +
        '</strong><small>' + percent(100 * (dailySales || 0) / dailyTarget) + '</small>'
      : '<strong>' + ui('لسه مفيش تارجت لليوم') + '</strong>';
  return '<section class="panel focus-panel employee-focus">' +
    '<div class="focus-head"><div><h2>' + ui('يومك النهارده') + '</h2>' +
    '<p>' + esc(todayDay) + '</p></div>' +
    '<span class="focus-pill">' + ui('مساحتك الشخصية') + '</span></div>' +
    '<div class="focus-grid"><div class="focus-item"><span class="focus-icon">' +
    svgIcon('tasks') + '</span><div><small>' + ui('المهمة الجاية') + '</small>' +
    taskLine + '</div>' +
    button(ui('افتح المهام'), 'go-tasks', '', 'secondary small') +
    '</div><div class="focus-item"><span class="focus-icon">' +
    svgIcon('target') + '</span><div><small>' + ui('تارجت اليوم') + '</small>' +
    targetLine + '</div>' +
    button(ui('المبيعات'), 'go-sales', '', 'secondary small') +
    '</div></div></section>';
}

function managerFocus() {
  const pendingLeaves = data.leaves.filter((l) => l.status === 'pending').length;
  const overdue = data.tasks.filter(
    (t) => t.status !== 'done' && t.due_day < data.today,
  ).length;
  return '<section class="focus-manager"><div class="focus-head">' +
    '<div><h2>' + ui('محتاج قرارك') + '</h2>' +
    '<p>' + ui('المراجعات والطلبات اللي منتظراك') + '</p></div>' +
    '</div>' + actionCards() +
    '<div class="focus-shortcuts">' +
    '<button type="button" data-page="leaves">' +
    svgIcon('calendar') + ui('طلبات إجازة معلقة') +
    '<strong>' + pendingLeaves + '</strong></button>' +
    '<button type="button" data-page="tasks">' +
    svgIcon('tasks') + ui('مهام متأخرة') +
    '<strong>' + overdue + '</strong></button>' +
    '</div></section>';
}

function overview() {
  const totals = monthlyTotals();
  const pending = data.sales.filter((sale) => sale.status === 'pending').length;
  return (
    (data.user.role === 'employee'
      ? employeeFocus() + selfAttendance()
      : managerFocus()) +
    '<div class="stats overview-stats">' +
    stat(ui('المبيعات المعتمدة'), totals.approved ? cash(totals.approved) : ui('0 ج.م'), '', 'receipt') +
    stat(ui('التارجت الشهري'), totals.target ? cash(totals.target) : ui('0 ج.م'), '', 'target') +
    stat(
      ui('نسبة الإنجاز'),
      totals.achievement === null ? ui('بدون تارجت') : percent(totals.achievement),
      '', 'trend',
    ) +
    stat(ui('مبيعات قيد المراجعة'), String(pending), '', 'clock') +
    '</div><div class="two-col"><section class="panel"><h3>' +
    (data.user.role === 'manager' ? ui('أداء الفريق') : ui('أدائي')) +
    '</h3>' +
    computedPerformanceTable() +
    ui('</section><section class="panel"><h3>آخر سجلات الحضور</h3>') +
    attendanceTable(data.attendance.slice(0, 5), false) +
    ui('</section></div>')
  );
}
function computedPerformanceTable() {
  return table(
    [
      ui('الموظف'),
      ui('الحضور المسجّل'),
      ui('الوصول في الموعد'),
      ui('تحقيق التارجت'),
    ],
    data.sales_summary.map((row) => [
      esc(employee(row.employee_id)),
      percent(row.attendance_rate),
      percent(row.on_time_rate),
      row.achievement === null ? ui('لم يحدد هدف') : percent(row.achievement),
    ]),
  );
}
function dailyRows() {
  const employees = data.employees.filter(
    (employee) =>
      salesEmployeeFilter === 'all' || employee.id == salesEmployeeFilter,
  );
  return employees
    .filter(
      (employee) =>
        employee.active ||
        data.targets.some(
          (target) =>
            target.employee_id === employee.id &&
            target.day === selectedSalesDay,
        ) ||
        data.sales.some(
          (sale) =>
            sale.employee_id === employee.id && sale.day === selectedSalesDay,
        ),
    )
    .map((employee) => {
      const target = data.targets.find(
        (target) =>
          target.employee_id === employee.id && target.day === selectedSalesDay,
      );
      const sales = data.sales.filter(
        (sale) =>
          sale.employee_id === employee.id && sale.day === selectedSalesDay,
      );
      const sum = (status) =>
        sales
          .filter((sale) => sale.status === status)
          .reduce((total, sale) => total + sale.amount_cents, 0);
      return {
        employee,
        target,
        approved: sum('approved'),
        pending: sum('pending'),
        achievement: target
          ? (sum('approved') * 100) / target.amount_cents
          : null,
      };
    });
}
function salesPage() {
  if (!selectedSalesDay.startsWith(month)) {
    selectedSalesDay = data.demo_day?.startsWith(month)
      ? data.demo_day
      : data.today.startsWith(month)
        ? data.today
        : month + '-01';
  }
  const manager = data.user.role === 'manager';
  const totals = monthlyTotals();
  const statusLabels = {
    pending: ui('تحت المراجعة'),
    approved: ui('معتمدة'),
    rejected: ui('مرفوضة'),
    cancelled: ui('ملغاة'),
  };
  const transactions = data.sales.filter(
    (sale) =>
      (salesStatusFilter === 'all' || sale.status === salesStatusFilter) &&
      (salesRange === 'month' || sale.day === selectedSalesDay) &&
      (salesEmployeeFilter === 'all' ||
        sale.employee_id == salesEmployeeFilter),
  );
  return (
    '<div class="stats three">' +
    stat(
      ui('مبيعات الشهر المعتمدة'),
      cash(totals.approved),
      ui('من سجلات البيع المعتمدة فقط'),
    ) +
    stat(
      ui('هدف الشهر'),
      cash(totals.target),
      ui('مجموع أهداف الأيام المحددة'),
    ) +
    stat(
      ui('تحقيق أهداف الشهر'),
      totals.achievement === null
        ? ui('لم يحدد هدف')
        : percent(totals.achievement),
      ui('يستبعد مبيعات الأيام التي ليس لها هدف'),
    ) +
    ui(
      '</div><section class="panel"><div class="toolbar"><div><h3>هدف اليوم ومبيعاته</h3>',
    ) +
    ui(
      '<p class="subtle">اختر اليوم ثم تابع مصدر كل رقم.</p></div><div class="actions">',
    ) +
    (manager ? button(ui('تحديد تارجت'), 'target-new') : '') +
    button(
      ui('تسجيل عملية بيع'),
      'sale-new',
      '',
      manager ? 'secondary' : 'primary',
    ) +
    '</div></div><div class="sales-filters">' +
    field(
      ui('اليوم'),
      'sales_day',
      selectedSalesDay,
      'date',
      'id="sales-day" required',
    ) +
    (manager
      ? selectField(
          ui('الموظف'),
          'sales_employee',
          ui('<option value="all">كل الموظفين</option>') +
            data.employees
              .map(
                (e) =>
                  '<option value="' +
                  e.id +
                  '" ' +
                  (e.id == salesEmployeeFilter ? 'selected' : '') +
                  '>' +
                  esc(e.name) +
                  '</option>',
              )
              .join(''),
        ).replace(
          'name="sales_employee"',
          'name="sales_employee" id="sales-employee"',
        )
      : '') +
    '</div>' +
    table(
      [
        ui('الموظف'),
        ui('هدف اليوم'),
        ui('المعتمد'),
        ui('تحت المراجعة'),
        ui('الإنجاز'),
        ...(manager ? [''] : []),
      ],
      dailyRows().map((row) => [
        esc(row.employee.name),
        row.target ? cash(row.target.amount_cents) : ui('لم يحدد'),
        cash(row.approved),
        cash(row.pending),
        targetProgress(row.achievement),
        ...(manager
          ? [
              button(
                row.target ? ui('تعديل الهدف') : ui('تحديد الهدف'),
                'target-employee',
                row.employee.id,
                'secondary small',
              ),
            ]
          : []),
      ]),
    ) +
    ui(
      '<p class="hint">هدف غير محدد لا يعني أداء 0%. المبيعات المسجلة دون هدف تظهر كمبيعات، ولا نستخدمها لرفع نسبة تحقيق أيام أخرى.</p>',
    ) +
    ui(
      '</section><section class="panel"><div class="toolbar"><h3>سجل عمليات البيع</h3>',
    ) +
    ui('<label>الفترة<select id="sales-range"><option value="day" ') +
    (salesRange === 'day' ? 'selected' : '') +
    ui('>اليوم المختار</option><option value="month" ') +
    (salesRange === 'month' ? 'selected' : '') +
    ui(
      '>الشهر المختار</option></select></label><label>الحالة<select id="sales-status">',
    ) +
    Object.entries({
      all: ui('كل الحالات'),
      pending: ui('تحت المراجعة'),
      approved: ui('معتمدة'),
      rejected: ui('مرفوضة'),
      cancelled: ui('ملغاة'),
    })
      .map(
        ([value, label]) =>
          '<option value="' +
          value +
          '" ' +
          (salesStatusFilter === value ? 'selected' : '') +
          '>' +
          label +
          '</option>',
      )
      .join('') +
    '</select></label></div>' +
    table(
      [
        ui('المرجع'),
        ui('الموظف'),
        ui('اليوم'),
        ui('العميل'),
        ui('القيمة'),
        ui('الحالة'),
        ui('المراجعة'),
        ui('الإجراء'),
      ],
      transactions.map((sale) => [
        '<strong>' + esc(sale.reference) + '</strong>',
        esc(employee(sale.employee_id)),
        esc(sale.day),
        esc(sale.customer),
        cash(sale.amount_cents),
        tag(
          statusLabels[sale.status],
          sale.status === 'approved'
            ? 'green'
            : sale.status === 'pending'
              ? 'amber'
              : 'red',
        ),
        '<span class="wrap-text">' +
          esc(sale.reviewer || ui('لم تراجع بعد')) +
          (sale.decision_note ? '<br>' + esc(sale.decision_note) : '') +
          '</span>',
        sale.status === 'pending'
          ? manager
            ? button(ui('مراجعة'), 'sale-decide', sale.id, 'primary small')
            : button(ui('إلغاء'), 'sale-cancel', sale.id, 'secondary small')
          : ui('محفوظ'),
      ]),
    ) +
    '</section>' +
    (manager ? '<div class="sales-demo-tools">' +
      button(ui('إنشاء نموذج مبيعات 5,000 جنيه'), 'sales-demo', '', 'secondary small') +
      '</div>' : '')
  );
}
function openTarget(employeeId) {
  const id =
    employeeId ||
    (salesEmployeeFilter !== 'all'
      ? Number(salesEmployeeFilter)
      : data.employees.find((e) => e.active)?.id);
  const target = data.targets.find(
    (target) => target.employee_id === id && target.day === selectedSalesDay,
  );
  formOpen(
    target ? ui('تعديل تارجت اليوم') : ui('تحديد تارجت يومي'),
    'target',
    0,
    selectField(ui('الموظف'), 'employee_id', employeeOptions(id)) +
      field(
        ui('تاريخ الهدف'),
        'day',
        selectedSalesDay || data.today,
        'date',
        'required',
      ) +
      field(
        ui('هدف المبيعات — جنيه'),
        'amount',
        target ? target.amount_cents / 100 : '',
        'number',
        'required min=".01" max="10000000" step=".01"',
      ) +
      ui(
        '<label class="wide">ملاحظة / سبب التعديل<textarea dir="auto" name="note" maxlength="500">',
      ) +
      esc(target?.note || '') +
      '</textarea></label>' +
      ui(
        '<p class="hint wide">يوجد هدف واحد لكل موظف في اليوم. عند تعديل هدف موجود، سبب التعديل إلزامي ويسجل في سجل الإدارة.</p>',
      ),
  );
}
function openSale() {
  const manager = data.user.role === 'manager';
  formOpen(
    ui('تسجيل عملية بيع للمراجعة'),
    'sale',
    0,
    (manager
      ? selectField(
          ui('الموظف'),
          'employee_id',
          employeeOptions(
            salesEmployeeFilter === 'all' ? null : salesEmployeeFilter,
          ),
        )
      : '') +
      field(
        ui('تاريخ البيع'),
        'day',
        manager ? selectedSalesDay : data.today,
        'date',
        'required max="' + data.today + '" ' + (manager ? '' : 'readonly'),
      ) +
      field(
        ui('مرجع الفاتورة / العملية'),
        'reference',
        '',
        'text',
        'required maxlength="80"',
      ) +
      field(
        ui('اسم العميل'),
        'customer',
        '',
        'text',
        'required maxlength="100"',
      ) +
      field(
        ui('قيمة البيع — جنيه'),
        'amount',
        '',
        'number',
        'required min=".01" max="10000000" step=".01"',
      ) +
      ui(
        '<label class="wide">ملاحظات<textarea dir="auto" name="note" maxlength="500"></textarea></label>',
      ) +
      ui(
        '<p class="hint wide">تسجّل العملية تحت المراجعة، ولا تحقق التارجت قبل اعتمادها. التسجيل من حساب الموظف متاح لليوم الحالي بعد بدء العمل.</p>',
      ),
  );
}
function openSaleDecision(id) {
  const sale = data.sales.find((sale) => sale.id === id);
  formOpen(
    ui('مراجعة عملية ') + sale.reference,
    'sale-decision',
    id,
    ui('<div class="wide policy">الموظف: ') +
      esc(employee(sale.employee_id)) +
      ui('<br>العميل: ') +
      esc(sale.customer) +
      ui('<br>المبلغ: ') +
      cash(sale.amount_cents) +
      ui('<br>التاريخ: ') +
      esc(sale.day) +
      ui('<br>الملاحظة: ') +
      esc(sale.note || '—') +
      '</div>' +
      selectField(
        ui('القرار'),
        'status',
        ui(
          '<option value="approved">اعتماد</option><option value="rejected">رفض</option>',
        ),
      ) +
      ui(
        '<label class="wide">سبب القرار (إلزامي عند الرفض)<textarea dir="auto" name="decision_note" maxlength="500"></textarea></label>',
      ),
  );
}
function openSalesDemo() {
  formOpen(
    ui('نموذج مبيعات'),
    'sales-demo',
    0,
    selectField(ui('الموظف'), 'employee_id', employeeOptions()) +
      field(
        ui('اليوم'),
        'day',
        selectedSalesDay,
        'date',
        'required max="' + data.today + '"',
      ) +
      ui(
        '<p class="hint wide">هدف 5,000 جنيه؛ عمليتان معتمدتان بقيمة 2,000 و1,500، وثالثة بقيمة 2,500 تحت المراجعة. الإنجاز اليومي يبدأ 70% ويوصل 120% بعد اعتماد الثالثة.</p>',
      ),
  );
}
async function salesAction(actionName, id) {
  if (actionName === 'target-new' || actionName === 'target-employee') {
    openTarget(id);
    return true;
  }
  if (actionName === 'sale-new') {
    openSale();
    return true;
  }
  if (actionName === 'sale-decide') {
    openSaleDecision(id);
    return true;
  }
  if (actionName === 'sales-demo') {
    openSalesDemo();
    return true;
  }
  if (actionName === 'sale-cancel') {
    if (confirm(ui('إلغاء العملية المعلقة؟ سيبقى مرجعها محفوظًا في السجل.'))) {
      await action('sales/cancel', { id });
    }
    return true;
  }
  return false;
}
async function salesSubmit(form, values) {
  const paths = {
    target: 'targets/save',
    sale: 'sales/submit',
    'sale-decision': 'sales/decide',
    'sales-demo': 'demo/sales',
  };
  const path = paths[form.dataset.kind];
  if (!path) return false;
  const body = { ...values };
  if ('employee_id' in body) body.employee_id = Number(body.employee_id);
  if (form.dataset.kind === 'sale-decision') body.id = Number(form.dataset.id);
  if (busy) return true;
  const submitButton = form.querySelector('[type=submit]');
  submitButton.disabled = true;
  await action(path, body);
  if (submitButton.isConnected) submitButton.disabled = false;
  return true;
}
