'use strict';
/* Reports, payslip details and attendance record sources. */
function reportHeaders() {
  return [
    ui('الموظف'),
    ui('حضور'),
    ui('غياب'),
    ui('الوصول في الموعد'),
    ui('هدف الشهر'),
    ui('المبيعات المعتمدة'),
    ui('المعتمد المطابق لأيام الهدف'),
    ui('تحقيق التارجت'),
    ui('صافي المرتب'),
  ];
}
function reportRows() {
  return data.employees.map((e) => {
    const row = data.sales_summary.find((row) => row.employee_id === e.id);
    const payroll = data.payroll.find(
      (payroll) => payroll.employee_id === e.id,
    );
    return [
      esc(e.name),
      row.present,
      row.absent,
      percent(row.on_time_rate),
      row.target_cents ? cash(row.target_cents) : ui('لم يحدد'),
      cash(row.approved_cents),
      cash(row.matched_cents),
      row.achievement === null ? ui('غير محدد') : percent(row.achievement),
      payroll ? cash(payroll.net_cents) : ui('لم يحسب'),
    ];
  });
}
function salesHistoryChart() {
  const history = data.sales_history;
  const maximum = Math.max(100, ...history.map((row) => row.achievement || 0));
  const bars = history
    .map((row, index) => {
      const x = 55 + index * 80;
      const height =
        row.achievement === null ? 0 : (row.achievement * 100) / maximum;
      return (
        '<text x="' +
        x +
        '" y="156" text-anchor="middle">' +
        esc(row.month) +
        '</text>' +
        (row.achievement === null
          ? '<text x="' + x + '" y="120" text-anchor="middle">—</text>'
          : '<rect x="' +
            (x - 20) +
            '" y="' +
            (130 - height) +
            '" width="40" height="' +
            height +
            '" rx="5" fill="#2c7565"><title>' +
            percent(row.achievement) +
            '</title></rect><text x="' +
            x +
            '" y="' +
            (120 - height) +
            '" text-anchor="middle">' +
            percent(row.achievement) +
            '</text>')
      );
    })
    .join('');
  return (
    ui(
      '<svg class="history-chart" viewBox="0 0 510 175" role="img" aria-label="تحقيق أهداف المبيعات لآخر ستة شهور">',
    ) +
    '<line x1="18" y1="130" x2="495" y2="130" stroke="#d5e2da"/>' +
    bars +
    '</svg>'
  );
}
function reportsPage() {
  return (
    ui(
      '<section class="panel"><div class="toolbar"><div><h3>تقرير الأداء والمبيعات — ',
    ) +
    esc(month) +
    ui(
      '</h3><p class="subtle">كل قيمة محسوبة من الحضور أو الأهداف أو المبيعات أو كشف المرتب.</p></div>',
    ) +
    '<div class="actions">' +
    button(ui('تصدير CSV'), 'export', '', 'secondary') +
    button(ui('طباعة التقرير'), 'print') +
    '</div></div>' +
    table(reportHeaders(), reportRows()) +
    ui('</section><section class="panel"><h3>تحقيق أهداف المبيعات — آخر 6 شهور</h3>') +
    salesHistoryChart() +
    '</section>' +
    (data.user.role === 'manager'
      ? ui('<section class="panel"><h3>سجل الإدارة</h3>') +
        table(
          [ui('العملية'), ui('السجل'), ui('التوقيت UTC')],
          data.audit.map((row) => [
            esc(systemText(row.action)),
            esc(readableAudit(row.entity)),
            esc(row.created_at),
          ]),
        ) +
        '</section>'
      : '')
  );
}
function deductionDetails(payroll) {
  let previousDeduction = 0;
  let quarters = 0;
  const rows = data.attendance
    .filter(
      (row) =>
        row.employee_id === payroll.employee_id && row.penalty_quarters > 0,
    )
    .sort((a, b) => a.day.localeCompare(b.day))
    .map((row) => {
      quarters += row.penalty_quarters;
      const cumulative = Math.min(
        payroll.base_cents,
        Math.round((payroll.base_cents * quarters) / (4 * payroll.divisor)),
      );
      const amount = cumulative - previousDeduction;
      previousDeduction = cumulative;
      return [
        esc(row.day),
        row.status === 'absent'
          ? ui('غياب بدون إذن')
          : ui('تأخير ') + row.late_minutes + ui(' دقيقة'),
        row.penalty_quarters / 4,
        cash(amount),
      ];
    });
  return (
    ui('<h3>تفاصيل الخصومات</h3>') +
    table([ui('اليوم'), ui('السبب'), ui('أيام الجزاء'), ui('المبلغ')], rows) +
    ui('<p class="hint">القيمة اليومية = الأساسي ÷ ') +
    payroll.divisor +
    ui(
      '. إجمالي الخصم لا يتجاوز الأساسي. التقريب على مجموع الأيام يحافظ على تطابق التفاصيل والإجمالي.</p>',
    )
  );
}
document.addEventListener('change', (event) => {
  if (event.target.id === 'sales-day') {
    if (!event.target.value || !event.target.value.startsWith(month)) {
      toast(ui('اختر يومًا داخل الشهر المختار من أعلى الصفحة'), true);
      event.target.value = selectedSalesDay;
      return;
    }
    selectedSalesDay = event.target.value;
    render();
  }
  if (event.target.id === 'sales-employee') {
    salesEmployeeFilter = event.target.value;
    render();
  }
  if (event.target.id === 'sales-range') {
    salesRange = event.target.value;
    render();
  }
});
function attendanceSource(row) {
  const label =
    row.source === 'self'
      ? ui('تسجيل ذاتي بالخادم')
      : row.source === 'approved_leave'
        ? ui('إجازة معتمدة')
        : ui('إدخال يدوي');
  const recordedTime = row.started_at_utc
    ? new Date(row.started_at_utc).toLocaleString(currentLocale(), {
        timeZone: 'Africa/Cairo',
      })
    : '';
  return (
    tag(label, row.source === 'self' ? 'green' : '') +
    (recordedTime
      ? '<small class="source-time">' +
        (row.source === 'self'
          ? ui('وقت الخادم: ')
          : ui('التسجيل الذاتي الأصلي: ')) +
        esc(recordedTime) +
        '</small>'
      : '')
  );
}
