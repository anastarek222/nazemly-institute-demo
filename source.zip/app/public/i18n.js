// Arabic and English UI text. User-entered data is never translated.
const ENGLISH = {
  'الرجوع للرئيسية': 'Back to home',
  'نظملي / إدارة الموظفين': 'Nazemly / Employee management',
  'نظملي': 'Nazemly',
  'الحضور والمهام والمبيعات والمرتبات في مكان واحد.': 'Attendance, tasks, sales and payroll in one place.',
  'بيانات الموظفين': 'Employee records',
  'التارجت والمرتبات': 'Targets and payroll',
  'حسابك في نظملي': 'Your Nazemly account',
  'تسجيل الدخول': 'Sign in',
  'ادخل اسم المستخدم وكلمة المرور.': 'Enter your username and password.',
  'مهامي': 'My tasks',
  'المهام المسندة وتواريخ تسليمها': 'Assigned tasks and due dates',
  'استخدم زر إضافة موظف عشان تبدأ تسجيل الفريق.': 'Use Add employee to build your team.',
  'المهام هتظهر هنا أول ما المدير يسندها.': 'Tasks appear here after the manager assigns them.',
  'كشف المرتب هيظهر هنا بعد تجهيز مسودة الشهر.': 'Your payslip appears here after the monthly draft is prepared.',
  'المبيعات هتظهر هنا بعد تسجيل أول عملية.': 'Sales appear after the first entry is recorded.',
  'التقارير هتظهر بمجرد وجود سجلات للفترة المحددة.': 'Reports appear when this period has records.',
  'طلبات الإجازات هتظهر هنا بعد تقديمها.': 'Leave requests appear here after submission.',
  'البيانات هتظهر هنا أول ما تتسجل.': 'Records appear here when added.',
  'أمّن حساب المدير': 'Secure the manager account',
  'غيّر كلمة المرور الأولية قبل إضافة أي بيانات. بعد الحفظ هتدخل بكلمتك الجديدة.': 'Change the initial password before adding any records. Sign in again with the new password.',
  'تغيير كلمة المرور': 'Change password',
  'إعادة ضبط نسخة العرض': 'Reset the local demo',
  'ترجع حسابات وبيانات الـDemo لنقطة البداية من غير ما تمس نسخة التشغيل العادية.': 'Restore the original demo without changing the normal database.',
  'إعادة البداية': 'Reset demo',
  'إعادة بداية نسخة العرض': 'Reset local demo',
  'هيتم مسح تغييرات الـDemo فقط وإرجاع المهام والحضور والمبيعات والمرتبات لحالة البداية. نسخة التشغيل العادية مش هتتأثر.': 'Reset only the demo records to their starting state. The normal database is not affected.',
  'كلمة مرور المدير': 'Manager password',
  'فاهم إن تغييرات نسخة العرض الحالية هتتمسح': 'I understand that current demo changes will be deleted',
  'تسليم النهارده': 'Due today',
  'تنبيهات غير مقروءة': 'Unread notifications',
  'أدائي': 'My performance',
  'يومك النهارده': 'Your day',
  'مساحتك الشخصية': 'Your workspace',
  'المهمة الجاية': 'Next task',
  'مفيش مهام مفتوحة': 'No open tasks',
  'اختار الشهر الحالي': 'Switch to current month',
  'عرض الشهر الحالي': 'Show current month',
  'افتح المهام': 'Open tasks',
  'تارجت اليوم': 'Today\'s target',
  'لسه مفيش تارجت لليوم': 'No target set for today',
  'محتاج قرارك': 'Needs your review',
  'المراجعات والطلبات اللي منتظراك': 'Pending requests and approvals',
  'طلبات إجازة معلقة': 'Pending leave requests',
  'مهام متأخرة': 'Overdue tasks',
  '0 ج.م': 'EGP 0',
  'أداء الفريق': 'Team performance',
  'التارجت الشهري': 'Monthly target',
  'نسبة الإنجاز': 'Achievement',
  'بدون تارجت': 'No target',
  'مبيعات قيد المراجعة': 'Sales awaiting review',
  'مبيعات تحتاج مراجعة': 'Sales to review',
  'موظفون لم يسجلوا حضورًا': 'Employees without check-in',
  'مسودات المرتبات': 'Draft payroll',
  'نموذج مبيعات': 'Sales example',
  'إنشاء نموذج مبيعات 5,000 جنيه': 'Create EGP 5,000 sales example',
  'بيضيف هدف و3 عمليات مبيعات ليوم واحد بتختاره، من غير تعديل أي عمليات موجودة.': 'Creates a target and three sales for a selected day without replacing existing records.',
  'هدف 5,000 جنيه؛ عمليتان معتمدتان بقيمة 2,000 و1,500، وثالثة بقيمة 2,500 تحت المراجعة. الإنجاز اليومي يبدأ 70% ويوصل 120% بعد اعتماد الثالثة.': 'EGP 5,000 target: two approved sales of 2,000 and 1,500, plus 2,500 awaiting review. Daily achievement rises from 70% to 120% after approval.',
  'قواعد الحضور والانصراف': 'Attendance policy',
  ' · ملخص كشف المرتب.': ' · Payroll summary.',
  'راجعت أيام الشهر والتنبيهات، وفاهم إن اليوم غير المسجل مش غياب تلقائي.': 'I reviewed the month and its alerts; unrecorded workdays are not automatic absences.',
  'فيه {count} يوم عمل (الأحد للخميس) من غير تسجيل؛ راجعهم قبل الاعتماد: {days}. الأيام دي مش غياب تلقائي.': '{count} Sun–Thu workdays have no record. Review before approval: {days}. These are not automatic absences.',
  '" aria-label="الشهر">': '" aria-label="Month">',
  '% · إنجاز': '% · Delivery',
  '% · تعاون': '% · Teamwork',
  '%. يحتفظ كل تقييم سابق بأوزانه.':
    '%. Earlier reviews retain their original weights.',
  '+ إضافة مهمة': '+ Add task',
  '+ إضافة موظف': '+ Add employee',
  '+ تسجيل حضور': '+ Record attendance',
  '+ تقييم موظف': '+ Review employee',
  '+ طلب إجازة': '+ Request leave',
  '. إجمالي الخصم لا يتجاوز الأساسي. التقريب على مجموع الأيام يحافظ على تطابق التفاصيل والإجمالي.':
    '. Total deductions cannot exceed base pay. Rounding cumulative days keeps the details equal to the total.',
  '. الخصم = أيام الجزاء × قيمة اليوم، بحد أقصى المرتب الأساسي. الصافي = الأساسي + المكافأة − الخصم. الاعتماد يثبت الكشف ويمنع تعديل حضور نفس الشهر. لا توجد تحويلات مالية فعلية.':
    ". Deduction = penalty days × daily rate, capped at base pay. Net pay = base + bonus − deduction. Approval locks the payslip and the employee's attendance for this month. No funds are transferred.",
  '. الموافقة تسجل أيام إجازة بدون خصم. لا يمكن تعديل الطلب المقبول.':
    '. Approval records leave days without deductions. Approved requests cannot be edited.',
  '. لا يُفترض أن الأيام غير المسجلة حضور أو غياب.':
    '. Unrecorded days are not assumed to be attendance or absence.',
  '01 / بيانات الموظفين': '01 / Employee records',
  '02 / الحضور والمرتبات': '02 / Attendance and payroll',
  '03 / التقييم والتقارير': '03 / Performance and reports',
  ': ربع يوم، حتى أقل من': ': quarter day, then below',
  ': نصف يوم، ثم يوم. غياب بدون إذن:':
    ': half day, then one day. Unexcused absence:',
  '>الشهر المختار': '>Selected month',
  '>اليوم المختار': '>Selected day',
  '· الانصراف': '· Check-out',
  '· تاريخ الإضافة:': '· Added on:',
  '· كشف حساب بدون تحويل أموال.':
    '· Payslip calculation only; no money is transferred.',
  '· مراجعة واعتماد': '· Reviewed and approved',
  'آخر تحديث:': 'Last updated:',
  'آخر سجلات الحضور': 'Recent attendance records',
  أ: 'E',
  'أدوات إضافية': 'More tools',
  أرشفة: 'Archive',
  'أرشفة الموظف مع الاحتفاظ بسجلاته السابقة؟':
    'Archive this employee while preserving previous records?',
  'أفهم أن الاستعادة تستبدل البيانات الحالية وتنهي الجلسات':
    'I understand that restoring replaces current data and ends all sessions',
  'أهلًا بيك في نظملي': 'Welcome to Nazemly',
  'أيام الجزاء': 'Penalty days',
  'أيام الحضور': 'Attendance days',
  'أيام. الأيام غير المسجلة لا تُحتسب غيابًا تلقائيًا.':
    'days. Unrecorded days are not counted as absence automatically.',
  إجازة: 'Leave',
  'إجازة بإذن': 'Authorized leave',
  'إجازة معتمدة': 'Approved leave',
  'إجمالي الأساسي': 'Total base pay',
  'إجمالي الخصومات': 'Total deductions',
  إدارة: 'Manage',
  'إدارة الحساب': 'Manage account',
  'إدارة الموظفين': 'Employee management',
  'إدارة حساب': 'Manage account',
  'إدخال يدوي': 'Manual entry',
  'إضافة نموذج مبيعات 5,000 جنيه': 'Add an EGP 5,000 sales example',
  'إضافة مهمة': 'Add task',
  'إضافة موظف': 'Add employee',
  إغلاق: 'Close',
  إلغاء: 'Cancel',
  'إلغاء الطلب': 'Cancel request',
  'إلغاء العملية المعلقة؟ سيبقى مرجعها محفوظًا في السجل.':
    'Cancel this pending sale? Its reference will remain in the records.',
  'إلغاء طلب الإجازة؟': 'Cancel this leave request?',
  إلى: 'To',
  'إلى تاريخ': 'End date',
  'إنجاز المهام —': 'Task delivery —',
  'إنشاء حساب': 'Create account',
  'إنشاء حساب جديد متاح من صفحة الموظفين.':
    'Create new accounts from the Employees page.',
  'إنهاء العمل': 'End work',
  'ابحث بالاسم أو القسم أو الوظيفة…':
    'Search by name, department or job title…',
  'اختر اليوم ثم تابع مصدر كل رقم.':
    'Choose a day and trace each total to its records.',
  'اختر موظفًا': 'Choose employee',
  'اختر نسخة JSON بحجم أقل من 4.5 ميجابايت':
    'Choose a JSON backup smaller than 4.5 MB',
  'اختر يومًا داخل الشهر المختار من أعلى الصفحة':
    'Choose a day within the month selected above',
  'اختر يومًا في الشهر المعروض': 'Choose a day within the displayed month',
  'استعادة بيانات النسخة الأساسية': 'Restore local workspace data',
  'استعادة نسخة': 'Restore backup',
  'اسم الشركة': 'Company name',
  'اسم العميل': 'Customer name',
  'اسم المستخدم': 'Username',
  'اسم المستخدم بالإنجليزية': 'Username in English',
  اعتماد: 'Approve',
  'اعتماد نهائي': 'Final approval',
  الأساسي: 'Base pay',
  'الأقسام — قسم في كل سطر': 'Departments — one per line',
  'الأهداف المحددة': 'Assigned targets',
  'الأوزان الحالية: جودة': 'Current weights: Quality',
  'الأيام غير المسجلة لا نفترض فيها حضورًا أو غيابًا. تحقيق التارجت يستخدم المبيعات المعتمدة في أيام لها أهداف فقط.':
    'Unrecorded days are not assumed to be attendance or absence. Achievement only counts approved sales on days with assigned targets.',
  الإجازات: 'Leave requests',
  الإجراء: 'Action',
  الإجراءات: 'Actions',
  الإعدادات: 'Settings',
  'الإعدادات الجديدة تطبق على السجلات الجديدة، ومسودات المرتبات. الكشوف المعتمدة والتقييمات السابقة تحتفظ بحساباتها.':
    'New settings apply to new records and draft payroll. Approved payslips and earlier reviews retain their original calculations.',
  الإنجاز: 'Achievement',
  'الاسم الكامل': 'Full name',
  البيان: 'Item',
  التأخير: 'Lateness',
  'التارجت والمبيعات': 'Targets and sales',
  التاريخ: 'Date',
  'التاريخ:': 'Date:',
  'التسجيل الذاتي الأصلي:': 'Original self check-in:',
  التسليم: 'Due date',
  التعاون: 'Teamwork',
  'التعاون —': 'Teamwork —',
  'التعطيل أو تغيير كلمة المرور ينهي جلسات الموظف الحالية.':
    "Disabling an account or changing its password ends the employee's current sessions.",
  التقارير: 'Reports',
  'التقييم الشهري': 'Monthly review',
  التنبيهات: 'Notifications',
  'التوقيت UTC': 'Time (UTC)',
  'الجزاء / يوم': 'Penalty / days',
  الجودة: 'Quality',
  الحالة: 'Status',
  'الحساب الحالي': 'Current account',
  الحضور: 'Attendance',
  'الحضور / الانصراف': 'Check-in / Check-out',
  'الحضور · المرتبات · الأداء': 'Attendance · Payroll · Performance',
  'الحضور المسجّل': 'Recorded attendance',
  'الحضور المسجّل = الحضور ÷ (الحضور + الغياب المسجّل). الوصول في الموعد = أيام الحضور دون تأخير ÷ أيام الحضور.':
    'Recorded attendance = present ÷ (present + recorded absence). On-time arrival = attendance days without lateness ÷ attendance days.',
  'الحضور والانصراف': 'Attendance',
  'الحضور —': 'Attendance —',
  الخصم: 'Deduction',
  الدخول: 'Access',
  'الدخول للحساب لا يسجّل الحضور. بدء العمل يسجّل الوقت من الخادم، والمبيعات تُحتسب بعد اعتماد المدير.':
    'Signing in does not record attendance. Start work records the server time; sales count after manager approval.',
  الدور: 'Role',
  السبب: 'Reason',
  السجل: 'Record',
  الشهر: 'Month',
  'الشهر:': 'Month:',
  'الشهر<input id="month" type="month" value="':
    'Month<input id="month" type="month" value="',
  الصافي: 'Net pay',
  'الطلبات عبر جميع الشهور. كل فترة تشمل الأيام التقويمية من البداية للنهاية.':
    'Requests across all months. Each period includes all calendar days from start to end.',
  العملية: 'Operation',
  العميل: 'Customer',
  'العميل:': 'Customer:',
  الفترة: 'Period',
  القرار: 'Decision',
  القسم: 'Department',
  القيمة: 'Amount',
  'القيمة اليومية = الأساسي ÷': 'Daily rate = base pay ÷',
  المبلغ: 'Amount',
  'المبلغ:': 'Amount:',
  'المبيعات المعتمدة': 'Approved sales',
  'المبيعات المعلقة لا تحقق التارجت. راجع مرجع العملية وقيمتها قبل الاعتماد.':
    'Pending sales do not count toward targets. Check the transaction reference and amount before approval.',
  'المدة المسجلة': 'Recorded duration',
  المدير: 'Manager',
  المراجعة: 'Review',
  'المرتب الأساسي': 'Base salary',
  'المرتب الأساسي — جنيه': 'Base salary — EGP',
  المرتبات: 'Payroll',
  المرجع: 'Reference',
  'المسمى الوظيفي': 'Job title',
  المعتمد: 'Approved',
  'المعتمد المطابق لأيام الهدف': 'Approved sales on target days',
  'المعتمد في أيام لها هدف ÷ أهدافها':
    'Approved sales on target days ÷ their targets',
  المعروض: 'Showing',
  المكافأة: 'Bonus',
  'الملاحظة:': 'Note:',
  'الملف ليس JSON صالحًا': 'The file is not valid JSON',
  المهام: 'Tasks',
  'المهام الظاهرة حسب صلاحيتك': 'Tasks visible to your account',
  'المهام المكتملة': 'Completed tasks',
  المهمة: 'Task',
  'المواعيد ومصدر التسجيل والجزاء المسجّل لكل يوم.':
    'Daily times, recording source and recorded penalties.',
  الموظف: 'Employee',
  'الموظف / اليوم': 'Employee / Date',
  'الموظف المسؤول': 'Assigned employee',
  'الموظف وحساب الدخول': 'Employee and login account',
  'الموظف يسجل مبلغ البيع ومرجع الفاتورة. المدير يراجع ويعتمد أو يرفض بسبب. المرجع لا يتكرر، والعمليات المعلقة أو المرفوضة أو الملغاة لا تدخل في الإنجاز.':
    'The employee records the sale amount and invoice reference. The manager approves or rejects it with a reason. References cannot be reused. Pending, rejected and cancelled sales do not count toward achievement.',
  'الموظف:': 'Employee:',
  الموظفون: 'Employees',
  النتيجة: 'Result',
  'النسخ الاحتياطي والاستعادة': 'Backup and restore',
  'النسخة تشمل بيانات النظام وحساباته وتجزئات كلمات المرور. الاستعادة تستبدل بيانات النسخة الأساسية وتنهي كل الجلسات. تحفظ نسخة تلقائية قبل الاستعادة.':
    'The backup includes system data, accounts and password hashes. Restoring replaces local workspace data and ends all sessions. A local snapshot is saved before restoration.',
  'الهاتف:': 'Phone:',
  'الوصول في الموعد': 'On-time arrival',
  الوظيفة: 'Job title',
  اليوم: 'Day',
  'اليوم لم يأتِ بعد': 'This date has not arrived',
  'اليوم مستقبلي': 'Future date',
  'بانتظار الموافقة': 'Awaiting approval',
  'بدء العمل': 'Start work',
  'بداية العمل': 'Work starts',
  'بداية خصم نصف يوم — دقيقة': 'Half-day penalty starts — minutes',
  'بداية خصم يوم — دقيقة': 'Full-day penalty starts — minutes',
  'بعد التعديل': 'After',
  'بعد الحفظ ستحتاج تسجيل الدخول بكلمة المرور الجديدة.':
    'After saving, sign in again using your new password.',
  'بعد السماح وأقل من حد نصف اليوم: ربع يوم. مجموع أوزان التقييم يجب أن يساوي 100%.':
    'After grace and below the half-day threshold: a quarter day. Review weights must total 100%.',
  'بعد المكافآت والخصومات': 'After bonuses and deductions',
  'بواسطة / التوقيت': 'Changed by / Time',
  'بيانات الشركة وسياسة العمل': 'Company and work policy',
  'بيانات النظام': 'System data',
  'بيانات تجريبية · تشغيل محلي': 'Demo data · Local use',
  تأخير: 'Late by',
  'تابع فريقك من مكان واحد.': 'Manage your team in one place.',
  'تاريخ البيع': 'Sale date',
  'تاريخ الهدف': 'Target date',
  'تجاوزت تاريخ التسليم': 'Past their due date',
  'تحت المراجعة': 'Pending review',
  تحديث: 'Refresh',
  'تحديث الحالة': 'Update status',
  'تحديث حالة المهمة': 'Update task status',
  'تحديد الكل كمقروء': 'Mark all as read',
  'تحديد الهدف': 'Set target',
  'تحديد تارجت': 'Set target',
  'تحديد تارجت يومي': 'Set daily target',
  'تحديد هدف اليوم': "Set today's target",
  'تحسن +': 'Improved +',
  'تحقيق أهداف الشهر': 'Monthly target achievement',
  'تحقيق أهداف المبيعات لآخر ستة شهور':
    'Sales target achievement over the last six months',
  'تحقيق أهداف المبيعات — آخر 6 شهور':
    'Sales target achievement — last 6 months',
  'تحقيق التارجت': 'Target achievement',
  تراجع: 'Declined',
  'تسجيل الحالة': 'Record status',
  'تسجيل المبيعات': 'Record sales',
  'تسجيل حضور': 'Record attendance',
  'تسجيل ذاتي بالخادم': 'Self check-in (server)',
  'تسجيل عملية بيع': 'Record sale',
  'تسجيل عملية بيع للمراجعة': 'Submit sale for review',
  'تسجّل العملية تحت المراجعة، ولا تحقق التارجت قبل اعتمادها. التسجيل من حساب الموظف متاح لليوم الحالي بعد بدء العمل.':
    "The sale stays pending until approval. Employees can record today's sales after starting work.",
  'تصدير CSV': 'Export CSV',
  'تطور تقييمات المدير اليدوية — آخر 6 شهور':
    'Manager review trend — last 6 months',
  تعديل: 'Edit',
  'تعديل البيانات لا يغيّر كشوف المرتبات المعتمدة. يمكنك إنشاء حساب دخول للموظف من قائمة الموظفين.':
    'Changes do not alter approved payslips. Create employee login accounts from the Employees page.',
  'تعديل الهدف': 'Edit target',
  'تعديل بيانات موظف': 'Edit employee',
  'تعديل تارجت اليوم': 'Edit daily target',
  'تعديل تقييم شهري': 'Edit monthly review',
  'تعديل سجل حضور': 'Correct attendance',
  'تعديل مهمة': 'Edit task',
  'تعذر الاتصال': 'Could not connect',
  'تعذر تحميل النظام': 'Could not load the system',
  'تعطيل الدخول': 'Disable access',
  'تغيير حالة دخول الموظف وإنهاء جلساته الحالية؟':
    'Change employee access and end their current sessions?',
  'تغيير كلمة المرور': 'Change password',
  'تغيير كلمة مروري': 'Change my password',
  'تفاصيل الخصومات': 'Deduction details',
  'تفاصيل المهمة': 'Task details',
  'تفعيل الدخول': 'Enable access',
  'تقرير الأداء والمبيعات —': 'Performance and sales report —',
  'تقييم الأداء': 'Performance review',
  'تقييم المدير': 'Manager review',
  'تقييم المدير — إدخال يدوي': 'Manager review — entered manually',
  'تقييم موظف': 'Review employee',
  'تم الانتهاء منها': 'Finished',
  'تم الحفظ. سجّل دخولك من جديد.': 'Saved. Please sign in again.',
  'تم حفظ التغييرات بنجاح': 'Changes saved successfully',
  'تنزيل نسخة احتياطية': 'Download backup',
  ثبات: 'Unchanged',
  جديد: 'New',
  جزاء: 'Penalty',
  'جزاء الغياب بدون إذن — أيام': 'Unexcused absence penalty — days',
  'جنيه مصري': 'Egyptian pounds',
  'جودة العمل —': 'Work quality —',
  حاضر: 'Present',
  حتى: 'Up to',
  'حد أقصى 31 يومًا للطلب. لا تسجل الإجازة في الحضور إلا بعد موافقة المدير.':
    'A maximum of 31 days per request. Leave is added to attendance only after manager approval.',
  'حساب / تحديث المسودات': 'Calculate / refresh drafts',
  'حساب الموظف يعرض بيانات أحمد محمد فقط. التشغيل مقصور على جهازك.':
    'The employee account shows أحمد محمد only. This app runs on your device.',
  'حساب دخول —': 'Login account —',
  'حساب موظف': 'Employee account',
  'حسابات التجربة المحلية': 'Demo accounts',
  'حسابات الدخول': 'Login accounts',
  'حسب سجلات الشهر': 'Based on monthly records',
  حضور: 'Present',
  'حضورك اليوم —': 'Your attendance today —',
  'حفظ الإعدادات': 'Save settings',
  'حفظ البيانات': 'Save changes',
  خروج: 'Sign out',
  'خروج مبكر': 'Early check-out',
  د: 'min',
  'دخول مساحة العمل': 'Sign in',
  دقيقة: 'minutes',
  'دقيقة: دون جزاء، بعدها وأقل من': 'minutes: no penalty; then below',
  'راجع المسودات قبل الاعتماد.': 'Review drafts before approval.',
  'راجع تشغيل الخادم ثم أعد تحميل الصفحة.':
    'Check that the server is running, then reload the page.',
  'راجعت الحضور والإجازات والأيام غير المسجلة ومبالغ الكشف. الاعتماد يثبت المرتب ويمنع تعديل حضور الشهر.':
    "I reviewed attendance, leave, unrecorded days and payslip amounts. Approval locks this payslip and the employee's attendance for this month.",
  'راجعت تنبيهات الشهر، وفهمت أن الخروج المبكر ليس خصمًا تلقائيًا.':
    "I reviewed this month's alerts and understand that early check-out does not create an automatic deduction.",
  'رحلة المدير': 'Manager journey',
  'رد الإدارة': 'Manager response',
  رفض: 'Reject',
  'رقم الكشف #': 'Payslip #',
  'رقم الهاتف': 'Phone number',
  س: 'h',
  'سبب الإجازة': 'Leave reason',
  'سبب التصحيح (إلزامي)': 'Correction reason (required)',
  'سبب التعديل': 'Reason for change',
  'سبب القرار (إلزامي عند الرفض)': 'Decision reason (required when rejecting)',
  'ستظهر البيانات هنا بمجرد تسجيلها.':
    'Records will appear here after you add them.',
  سجل: 'records',
  'سجل الإدارة': 'Management log',
  'سجل تصحيحات الحضور — قبل وبعد': 'Attendance corrections — before and after',
  'سجل حضور الشهر': 'Monthly attendance records',
  'سجل عمليات البيع': 'Sales transaction log',
  'سجل مفتوح': 'Open records',
  'سجل مكتمل': 'Complete record',
  'سجل واحد لكل موظف في اليوم. الإجازة بإذن دون خصم. المواعيد محلية بتوقيت القاهرة، والشيفت داخل نفس اليوم.':
    'One record per employee per day. Authorized leave has no deduction. Times use Cairo time; shifts must start and end on the same day.',
  'سجّل دخولك': 'Sign in',
  'سماح التأخير — دقيقة': 'Lateness grace — minutes',
  'سياسة الحضور': 'Attendance policy',
  'شهر التقييم': 'Review month',
  'شهر معتمد': 'Month approved',
  'صافي المرتب': 'Net salary',
  'صافي المستحق': 'Net amount due',
  'صافي المستحقات': 'Total net pay',
  'طباعة التقرير': 'Print report',
  'طباعة القسيمة': 'Print payslip',
  'طريقة الحساب': 'Calculation method',
  'طلب إجازة': 'Request leave',
  'طلبات الإجازات': 'Leave requests',
  'عدد الأيام لحساب قيمة اليوم': 'Days used to calculate the daily rate',
  'عدد سجلات الشهر:': 'Monthly records:',
  'عرض آخر 12 سجل': 'Show latest 12 records',
  'عرض كل سجلات الشهر': 'Show all monthly records',
  'عمليات بانتظار المراجعة': 'Transactions awaiting review',
  'عمليات بيع تحت المراجعة': 'Sales awaiting review',
  'عنوان المهمة': 'Task title',
  غائب: 'Absent',
  غياب: 'Absence',
  'غياب بدون إذن': 'Unexcused absence',
  'غياب مسجل': 'Recorded absence',
  'غياب مسجّل': 'Recorded absence',
  'غير جاهز للاعتماد': 'Not ready for approval',
  'غير متاح': 'Unavailable',
  'غير محدد': 'Not assigned',
  'غير مسجل': 'Not recorded',
  'فتح المراجعة': 'Open review',
  'في الشهر المختار': 'In the selected month',
  'قائمة الموظفين النشطين حاليًا للمراجعة؛ عدم التسجيل ليس غيابًا تلقائيًا.':
    'Current active employees shown for review. Missing check-in is not automatic absence.',
  'قبل التعديل': 'Before',
  قسيمة: 'Payslip',
  'قسيمة المرتب': 'Payslip',
  'قسيمة مرتب': 'Payslip',
  'قيد التنفيذ': 'In progress',
  'قيمة البيع — جنيه': 'Sale amount — EGP',
  'قيمة المكافأة — جنيه': 'Bonus amount — EGP',
  'قيمة اليوم': 'Daily rate',
  'قيمة اليوم = المرتب الأساسي ÷': 'Daily rate = base salary ÷',
  'كشف #': 'Payslip #',
  'كشف المرتب': 'Payslip',
  'كشف مرتبات': 'Payroll for',
  'كشف معتمد': 'Approved payslip',
  'كشوف المرتب': 'Payslips',
  'كشوف مرتبات مسودة': 'Draft payslips',
  'كل الحالات': 'All statuses',
  'كل المهام': 'All tasks',
  'كل الموظفين': 'All employees',
  'كل فريق عظيم،': 'Every great team',
  'كل قيمة محسوبة من الحضور أو الأهداف أو المبيعات أو كشف المرتب.':
    'Every figure comes from attendance, targets, sales or a payslip.',
  'كل معيار من 100. النتيجة تحسب بالأوزان الحالية من صفحة الإعدادات.':
    'Each criterion is scored out of 100. The result uses the current settings when the review is saved.',
  'كل مهمة لها مسؤول وموعد تسليم. تحديث حالتها لا يضيف مبيعات ولا يحقق التارجت.':
    'Each task has an assignee and a deadline. Changing its status does not add sales or achieve a target.',
  'كلمة المرور': 'Password',
  'كلمة المرور الجديدة': 'New password',
  'كلمة المرور الحالية': 'Current password',
  'كلمة مرور المدير الحالية': 'Current manager password',
  'كيف نتحقق من التارجت؟': 'How are targets verified?',
  'لا تدخل في نسبة الإنجاز': 'Excluded from achievement',
  'لا توجد تقييمات خلال آخر 6 شهور': 'No reviews in the last 6 months',
  'لا توجد تنبيهات جديدة': 'No new notifications',
  'لا توجد سجلات لهذا الشهر': 'No records for this month',
  'لا نجمع هذه المؤشرات في درجة واحدة بوزن عشوائي؛ تقييم المدير منفصل وواضح أنه يدوي.':
    "We do not combine these indicators using arbitrary weights. The manager's manual review is shown separately.",
  'لا يوجد تقييم سابق': 'No previous review',
  'لا يوجد موظفون': 'No employees',
  'للكشوف المحسوبة': 'For calculated payslips',
  'لم تبدأ': 'Not started',
  'لم تراجع بعد': 'Not reviewed yet',
  'لم تسجل حضورك بعد': 'You have not checked in',
  'لم يحدد': 'Not assigned',
  'لم يحدد هدف': 'No target assigned',
  'لم يحسب': 'Not calculated',
  'لم يسجل': 'No check-in',
  'لم يسجل انصرافًا': 'No check-out recorded',
  'لم يسجل بعد': 'No check-in yet',
  'لم يسجلوا في': 'No check-in on',
  'لم يكتمل السجل': 'Record is incomplete',
  م: 'M',
  مؤرشف: 'Archived',
  'مؤشرات من السجلات الفعلية': 'Indicators from actual records',
  'مبيعات الشهر المعتمدة': 'Approved monthly sales',
  متأخرة: 'Overdue',
  'متابعة الاعتماد': 'Track approval',
  'متوسط تقييم الأداء لآخر ستة شهور':
    'Average performance review over the last six months',
  'نموذج مبيعات': 'Sales example',
  'مجموع أهداف الأيام المحددة': 'Sum of assigned daily targets',
  'مجموع الأهداف اليومية': 'Sum of daily targets',
  محفوظ: 'Recorded',
  'محفوظ ومعتمد': 'Saved and approved',
  'مدة الحضور فرق وقتي التسجيل وليست قياسًا للإنتاجية. الخروج المبكر يظهر للمراجعة ولا يضيف جزاءً أو خصمًا تلقائيًا.':
    'Recorded duration is the interval between check-in and check-out, not a measure of productivity. Early check-out is flagged for review and does not create an automatic penalty or deduction.',
  مدير: 'Manager',
  'مدير النظام': 'System manager',
  مراجعة: 'Review',
  'مراجعة / تصحيح': 'Review / correct',
  'مراجعة إجازة': 'Review leave for',
  'مراجعة الطلب': 'Review request',
  'مراجعة المبيعات': 'Review sales',
  'مراجعة المرتب': 'Review payroll',
  'مراجعة اليوم المختار': 'Daily attendance review',
  'مراجعة عملية': 'Review sale',
  'مراجعة واعتماد مرتب': 'Review and approve payroll for',
  'مرجع الفاتورة / العملية': 'Invoice / transaction reference',
  مرفوض: 'Rejected',
  مرفوضة: 'Rejected',
  'مركز التنبيهات': 'Notifications',
  مساحة: 'Account:',
  'مساحة العمل': 'Workspace',
  'مساحة واحدة لإدارة الموظفين، وتنظيم الحضور، وحساب المرتبات، ومتابعة الأداء.':
    'One place for employee records, attendance, payroll and performance.',
  مسودة: 'Draft',
  'مسودة غير معتمدة': 'Unapproved draft',
  'وضع العرض · بيانات منفصلة': 'Demo workspace',
  'مصدر الوقت': 'Time source',
  معتمد: 'Approved',
  معتمدة: 'Approved',
  معطّل: 'Disabled',
  'معنى المؤشرات': 'What the indicators mean',
  مفعّل: 'Enabled',
  'مقارنة بالشهر السابق': 'Compared with the previous month',
  مقبول: 'Approved',
  مكافأة: 'Bonus',
  مكتملة: 'Completed',
  ملاحظات: 'Notes',
  'ملاحظات المدير': 'Manager notes',
  'ملاحظة / سبب التعديل': 'Note / reason for change',
  ملغاة: 'Cancelled',
  ملغي: 'Cancelled',
  'ملف الموظف': 'Employee profile',
  'ملف النسخة الاحتياطية': 'Backup file',
  من: 'From',
  'من تاريخ': 'Start date',
  'من سجلات البيع المعتمدة فقط': 'From approved sales records only',
  'مهام الفريق': 'Team tasks',
  'مهام متأخرة': 'Overdue tasks',
  'مهام مكتملة': 'Completed tasks',
  مهمة: 'task',
  موافقة: 'Approve',
  موظف: 'Employee',
  'موظف مؤرشف': 'Archived employee',
  'موعد التسليم': 'Due date',
  ن: 'N',
  'نتائج التقييم المحفوظة، وفق أوزان كل تقييم وقت تسجيله.':
    'Saved reviews use the weights recorded when each review was entered.',
  'نسخة العرض المنفصلة': 'Separate demo mode',
  'النسخة الأساسية': 'Local workspace',
  'نسخة عرض مستقلة — بيانات تدريبية، وليست بيانات النسخة الأساسية':
    'Separate demo mode — training data, independent of local workspace data',
  نشط: 'Active',
  'نظرة عامة': 'Overview',
  'نظملي / إدارة الموارد البشرية': 'Nazemly / Human resources',
  'نظملي / الموارد البشرية': 'Nazemly / Human resources',
  'نظملي — إدارة الموارد البشرية': 'Nazemly — Human resources',
  نقطة: 'points',
  'نهاية الدوام المتوقعة': 'Expected end of shift',
  'نهاية العمل': 'Work ends',
  'هدف 5,000 جنيه؛ عمليتان معتمدتان بقيمة 2,000 و1,500، وثالثة بقيمة 2,500 تحت المراجعة. النتيجة تبدأ 70% وتصبح 120% عند اعتماد الثالثة. هذه معاملات تجريبية.':
    'EGP 5,000 target; two approved sales of 2,000 and 1,500, plus a pending sale of 2,500. Achievement starts at 70% and becomes 120% after the third sale is approved. These are demo transactions.',
  'هدف الشهر': 'Monthly target',
  'هدف المبيعات — جنيه': 'Sales target — EGP',
  'هدف اليوم': 'Daily target',
  'هدف اليوم ومبيعاته': 'Daily target and sales',
  'هدف غير محدد لا يعني أداء 0%. المبيعات المسجلة دون هدف تظهر كمبيعات، ولا نستخدمها لرفع نسبة تحقيق أيام أخرى.':
    'An unassigned target does not mean 0% performance. Approved sales on days without targets are shown as sales but do not raise achievement on other days.',
  'هذه بيانات تجريبية، لكن الأرقام محسوبة من السجلات وليست أرقامًا ثابتة. تسجيل الحضور يثبت وقت التسجيل، واعتماد المدير هو وسيلة التحقق داخل المشروع؛ لا يوجد ربط بكاشير أو جهاز بصمة.':
    "This is demo data, but figures are calculated from records rather than fixed dashboard values. Check-in proves the recording time; manager approval is the project's verification step. No cash register or biometric device is connected.",
  'وراه نظام واضح.': 'needs a clear system.',
  'وزن الإنجاز %': 'Delivery weight %',
  'وزن التعاون %': 'Teamwork weight %',
  'وزن الجودة %': 'Quality weight %',
  'وقت الانصراف': 'Check-out time',
  'وقت الحضور': 'Check-in time',
  'وقت الخادم:': 'Server time:',
  'يستبعد مبيعات الأيام التي ليس لها هدف':
    'Excludes sales on days without targets',
  'ينشئ هدفًا و3 عمليات تجريبية لموظف ويوم تختارهما، دون استبدال سجلات موجودة.':
    'Creates a target and 3 demo sales for an employee and day you choose without replacing existing records.',
  'يوجد هدف واحد لكل موظف في اليوم. عند تعديل هدف موجود، سبب التعديل إلزامي ويسجل في سجل الإدارة.':
    'One target per employee per day. A reason is required when changing an existing target and is recorded in the management log.',
  يوم: 'days',
  'يومك في نظملي': 'Your day in Nazemly',
  'طلب غير صحيح': 'Invalid request',
  'المسار غير موجود': 'Endpoint not found',
  'غير موجود': 'Not found',
  'مصدر الطلب غير مسموح': 'Request origin is not allowed',
  'طلب كبير': 'Request is too large',
  'حفظ بيانات موظف': 'Saved employee details',
  'البيانات متعارضة مع سجل موجود': 'The data conflicts with an existing record',
  'تعذر تنفيذ العملية': 'Could not complete the operation',
  'سجل الدخول أولًا': 'Please sign in first',
  'هذه العملية للمدير فقط': 'This action is for managers only',
  'أرشفة موظف': 'Archived employee',
  'محاولات كثيرة؛ جرّب بعد خمس دقائق':
    'Too many attempts. Try again in five minutes',
  'اسم المستخدم أو كلمة المرور غير صحيحة': 'Incorrect username or password',
  'حفظ تقييم': 'Saved review',
  'حساب مسودات المرتبات': 'Calculated draft payroll',
  'كشف المرتب غير موجود': 'Payslip not found',
  'كشف المرتب معتمد بالفعل ولا يقبل التعديل':
    'This payslip is already approved and cannot be changed',
  'الكشف تغير أثناء المراجعة؛ حدّث الصفحة':
    'The payslip changed during review. Refresh the page',
  'اعتماد مرتب': 'Approved payroll',
  'تعديل مكافأة': 'Updated bonus',
  'التارجت يجب أن يكون أكبر من صفر': 'The target must be greater than zero',
  'اكتب سبب تعديل التارجت': 'Enter a reason for changing the target',
  'لا يمكن تسجيل بيع بتاريخ مستقبلي':
    'Sales cannot be recorded for a future date',
  'قيمة البيع يجب أن تكون أكبر من صفر':
    'The sale amount must be greater than zero',
  'مرجع العملية مسجّل بالفعل؛ لا يمكن تكراره':
    'This transaction reference already exists and cannot be reused',
  'الموظف يسجل مبيعات اليوم الحالي فقط':
    'Employees can record sales for today only',
  'ابدأ العمل وسجّل حضورك قبل تسجيل المبيعات':
    'Start work and check in before recording sales',
  'قرار غير صحيح': 'Invalid decision',
  'اكتب سبب رفض العملية': 'Enter a reason for rejecting the sale',
  'العملية غير موجودة أو تمت مراجعتها بالفعل':
    'The sale does not exist or has already been reviewed',
  'يمكن إلغاء العمليات المعلقة فقط':
    'Only pending transactions can be cancelled',
  'إلغاء عملية بيع': 'Cancelled sale',
  'اختر تاريخ اليوم أو قبله للمثال':
    'Choose today or an earlier date for the example',
  'اختر يومًا دون تارجت أو مبيعات لإضافة المثال بدون استبدال بيانات':
    'Choose a day without targets or sales to add the example without replacing records',
  'إنشاء نموذج مبيعات': 'Created a sales example',
  'العملية غير موجودة': 'Transaction not found',
  'لا يمكن تسجيل حضور أو غياب بتاريخ مستقبلي':
    'Attendance and absence cannot be recorded for a future date',
  'الحالة غير صحيحة': 'Invalid status',
  'التاريخ ضمن إجازة معتمدة': 'This date is covered by approved leave',
  'نهاية الدوام يجب أن تكون بعد بدايته في نفس اليوم':
    'The shift must end after it starts on the same day',
  'الانصراف يجب أن يكون بعد الحضور في نفس اليوم':
    'Check-out must be after check-in on the same day',
  'أكّد مراجعة سجلات الشهر قبل اعتماد المرتب':
    'Confirm that you reviewed the monthly records before approving payroll',
  'راجع تنبيهات الشهر وأكّد الاطلاع عليها':
    'Review the monthly alerts and acknowledge them',
  'مبالغ الكشف تغيرت؛ حدّث الصفحة وراجعها من جديد':
    'The payslip amounts changed. Refresh the page and review them again',
  'السجل اتعدل بالفعل؛ حدّث الصفحة قبل الحفظ':
    'This attendance record changed. Refresh before saving',
  'تعديل حضور': 'Corrected attendance',
  'حفظ حضور': 'Saved attendance',
  'الشهر لم ينتهِ بعد؛ المتاح الآن مسودة فقط':
    'This month has not ended. Only a draft is available',
  'لا توجد سجلات حضور أو غياب أو إجازة للشهر':
    'No attendance, absence or leave records exist for this month',
  'يوجد {open_count} سجل حضور دون انصراف':
    'There are {open_count} attendance records without check-out',
  'يوجد {pending_leaves} طلب إجازة معلق يخص الشهر':
    'There are {pending_leaves} pending leave requests for this month',
  'يوجد {early_count} سجل خروج مبكر للمراجعة؛ لا يضيف خصمًا تلقائيًا':
    'There are {early_count} early check-out records to review; no automatic deduction is added',
  'اسم المستخدم: 3–40 حرفًا إنجليزيًا أو رقمًا أو . أو _ أو -':
    'Username: 3–40 English letters, numbers, dots, underscores or hyphens',
  'كلمة المرور لا تقل عن 8 أحرف':
    'The password must contain at least 8 characters',
  'للموظف حساب بالفعل؛ استخدم إعادة تعيين كلمة المرور':
    'This employee already has an account. Use password reset',
  'إنشاء حساب موظف': 'Created employee account',
  'حساب الموظف غير موجود': 'Employee account not found',
  'تغيير حالة حساب': 'Changed account access',
  'إعادة تعيين كلمة مرور': 'Reset password',
  'كلمة المرور الحالية غير صحيحة': 'The current password is incorrect',
  'كلمة المرور الجديدة لا تقل عن 8 أحرف':
    'The new password must contain at least 8 characters',
  'تسجيل الحضور الذاتي متاح لحساب الموظف':
    'Self check-in is available to employee accounts',
  'يوجد سجل بالفعل لهذا اليوم': 'A record already exists for this day',
  'نوع التسجيل غير صحيح': 'Invalid attendance action',
  'طلب الإجازة من حساب الموظف':
    'Leave requests are submitted from employee accounts',
  'اختر فترة من اليوم أو بعده، بحد أقصى 31 يومًا':
    'Choose a period starting today or later, up to 31 days',
  'الفترة تتداخل مع طلب موجود': 'This period overlaps an existing request',
  'سجّل الحضور أولًا': 'Check in first',
  'تم تسجيل الانصراف بالفعل': 'Check-out has already been recorded',
  'وقت الانصراف غير صحيح': 'Invalid check-out time',
  'يمكن إلغاء الطلبات المعلقة فقط': 'Only pending requests can be cancelled',
  'إلغاء طلب إجازة': 'Cancelled leave request',
  'الطلب غير موجود أو تم البت فيه':
    'The request does not exist or has already been reviewed',
  'اكتب سبب الرفض': 'Enter a rejection reason',
  'قرار إجازة': 'Reviewed leave request',
  'الطلب غير موجود': 'Request not found',
  'حفظ مهمة': 'Saved task',
  'المهمة غير موجودة': 'Task not found',
  'حالة المهمة غير صحيحة': 'Invalid task status',
  'تحديث حالة مهمة': 'Updated task status',
  'نهاية العمل يجب أن تكون بعد بدايته': 'Work must end after it starts',
  'حدود التأخير يجب أن تكون تصاعدية':
    'Lateness thresholds must be in ascending order',
  'مجموع أوزان التقييم يجب أن يساوي 100': 'Review weights must total 100',
  'أضف قسمًا واحدًا على الأقل وبحد أقصى 30':
    'Add at least one department, up to 30',
  'تعديل إعدادات الشركة': 'Updated company settings',
  'كلمة مرور المدير غير صحيحة': 'Incorrect manager password',
  'ملف النسخة غير صالح أو إصدار غير مدعوم':
    'The backup file is invalid or its version is unsupported',
  'ملف النسخة يخص وضع تشغيل مختلف؛ افتح نسخة العرض أو النسخة العادية المناسبة':
    'This backup belongs to a different mode. Open the matching demo or normal system',
  'جداول النسخة غير مكتملة': 'The backup tables are incomplete',
  'النسخة يجب أن تحتوي حساب المدير الحالي وكلمة مروره':
    'The backup must include the current manager account and its password',
  'إعدادات النسخة غير مكتملة': 'The backup settings are incomplete',
  'علاقات البيانات غير سليمة': 'The data relationships are invalid',
  'استعادة نسخة احتياطية': 'Restored backup',
  'حساب غير صالح في النسخة': 'The backup contains an invalid account',
  'راجع الحقول المطلوبة وطول النص': 'Check required fields and text length',
  'قيمة رقمية غير صحيحة': 'Invalid numeric value',
  'القيمة خارج النطاق المسموح': 'The value is outside the allowed range',
  'المرتب غير صحيح': 'Invalid amount',
  'الشهر غير صحيح': 'Invalid month',
  'التاريخ غير صحيح': 'Invalid date',
  'الوقت غير صحيح': 'Invalid time',
  'الموظف غير موجود أو حسابه غير نشط':
    'The employee does not exist or is inactive',
  'كشف الشهر معتمد؛ لا يمكن تعديل بياناته':
    "This month's payroll is approved; its attendance cannot be changed",
  'من أصل': 'out of',
  'هذا الحقل مطلوب': 'This field is required.',
  'أكّد هذا الاختيار': 'Please confirm this choice.',
  'القيمة يجب ألا تقل عن {limit}': 'The value must be at least {limit}.',
  'القيمة يجب ألا تزيد عن {limit}': 'The value must not exceed {limit}.',
  'أدخل {limit} أحرف على الأقل': 'Enter at least {limit} characters.',
  'الحد الأقصى {limit} حرفًا': 'Use no more than {limit} characters.',
  'راجع صيغة القيمة المدخلة': 'Check the format of this value.',
  'الإجازة تتعارض مع سجل حضور أو غياب في {date}':
    'Leave conflicts with an attendance or absence record on {date}',
  'صيغة جدول غير صحيحة: {table}': 'Invalid table format: {table}',
  'تهيئة بيانات العرض': 'Initialized demo data',
  'اعتماد بيع': 'Approved sale',
  'رفض بيع': 'Rejected sale',
  'حضور ذاتي': 'Self check-in',
  'انصراف ذاتي': 'Self check-out',
  'طلب إجازة جديد: {name}': 'New leave request: {name}',
  'طلب الإجازة من {start} إلى {end}: {decision}':
    'Leave request from {start} to {end}: {decision}',
  'مهمة: {title} — موعد التسليم {date}': 'Task: {title} — due {date}',
  'تحديث مهمة {title} — {status}': 'Task update: {title} — {status}',
  'تم اعتماد مرتب شهر {month}': 'Payroll approved for {month}',
  'عملية بيع جديدة للمراجعة: {reference}': 'Sale awaiting review: {reference}',
  'تم اعتماد {reference}': 'Approved {reference}',
  'تم رفض {reference}': 'Rejected {reference}',
};

const TEXT = {
  ar: Object.fromEntries(Object.keys(ENGLISH).map((key) => [key, key])),
  en: ENGLISH,
};
let currentLanguage = 'ar';
try {
  currentLanguage =
    localStorage.getItem('nazemly.language') === 'en' ? 'en' : 'ar';
} catch (error) {
  /* Storage is optional. */
}

function currentLocale() {
  return currentLanguage === 'en' ? 'en-EG' : 'ar-EG';
}
function t(key, values = {}) {
  const message = TEXT[currentLanguage][key] ?? key;
  return message.replace(/\{([A-Za-z_]+)\}/g, (whole, name) =>
    Object.prototype.hasOwnProperty.call(values, name)
      ? String(values[name])
      : whole,
  );
}
function translatedFragment(value) {
  const match = value.match(/^(\s*)([\s\S]*?)(\s*)$/);
  return match[1] + t(match[2]) + match[3];
}
function ui(template) {
  // Only static UI fragments pass through this function, never user-entered data.
  return template
    .split(/(<[^>]*>)/g)
    .map((part) => {
      if (part.startsWith('<')) {
        return part.replace(
          /(placeholder|aria-label|title)=(["'])(.*?)\2/g,
          (whole, name, quote, value) => name + '=' + quote + t(value) + quote,
        );
      }
      return translatedFragment(part);
    })
    .join('');
}
function systemText(message) {
  const value = String(message ?? '');
  if (currentLanguage === 'ar') return value;
  if (ENGLISH[value] !== undefined) return t(value);
  let match;
  if ((match = value.match(/^طلب إجازة جديد: (.+)$/s))) {
    return t('طلب إجازة جديد: {name}', { name: match[1] });
  }
  if (
    (match = value.match(
      /^تم (قبول|رفض) طلب الإجازة من (\d{4}-\d{2}-\d{2}) إلى (\d{4}-\d{2}-\d{2})(?: — (.*))?$/s,
    ))
  ) {
    return (
      t('طلب الإجازة من {start} إلى {end}: {decision}', {
        start: match[2],
        end: match[3],
        decision: t(match[1] === 'قبول' ? 'مقبول' : 'مرفوض'),
      }) + (match[4] ? ' — ' + match[4] : '')
    );
  }
  if (
    (match = value.match(/^مهمة: (.*) — موعد التسليم (\d{4}-\d{2}-\d{2})$/s))
  ) {
    return t('مهمة: {title} — موعد التسليم {date}', {
      title: match[1],
      date: match[2],
    });
  }
  if (
    (match = value.match(/^تحديث مهمة (.*) — (لم تبدأ|قيد التنفيذ|مكتملة)$/s))
  ) {
    return t('تحديث مهمة {title} — {status}', {
      title: match[1],
      status: t(match[2]),
    });
  }
  for (const [pattern, key, name] of [
    [/^تم اعتماد مرتب شهر (.+)$/s, 'تم اعتماد مرتب شهر {month}', 'month'],
    [
      /^عملية بيع جديدة للمراجعة: (.+)$/s,
      'عملية بيع جديدة للمراجعة: {reference}',
      'reference',
    ],
    [/^تم اعتماد (.+)$/s, 'تم اعتماد {reference}', 'reference'],
    [/^تم رفض (.+)$/s, 'تم رفض {reference}', 'reference'],
  ]) {
    if ((match = value.match(pattern))) return t(key, { [name]: match[1] });
  }
  for (const key of Object.keys(ENGLISH).filter((key) =>
    /\{[A-Za-z_]+\}/.test(key),
  )) {
    const names = [];
    const expression = key
      .split(/(\{[A-Za-z_]+\})/g)
      .map((part) => {
        if (/^\{/.test(part)) {
          names.push(part.slice(1, -1));
          return '(.+?)';
        }
        return part.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&');
      })
      .join('');
    match = value.match(new RegExp('^' + expression + '$', 's'));
    if (match)
      return t(
        key,
        Object.fromEntries(names.map((name, i) => [name, match[i + 1]])),
      );
  }
  if (value.includes(' — '))
    return value.split(' — ').map(systemText).join(' — ');
  return value;
}
function languageButton() {
  const label = currentLanguage === 'ar' ? 'Switch to English' : 'التبديل للعربي';
  return '<button type="button" class="secondary small language-toggle" ' +
    'data-action="language" aria-label="' + label + '" title="' + label + '">' +
    (currentLanguage === 'ar' ? '<strong>عربي</strong> <span>· EN</span>' :
      '<span>عربي · </span><strong>EN</strong>') + '</button>';
}
function applyLanguage() {
  document.documentElement.lang = currentLanguage;
  document.documentElement.dir = currentLanguage === 'ar' ? 'rtl' : 'ltr';
  document.title =
    currentLanguage === 'ar'
      ? 'نظملي | إدارة الموظفين'
      : 'Nazemly | Employee management';
}
const PAGE_LABELS = {
  overview: 'نظرة عامة',
  employees: 'الموظفون',
  attendance: 'الحضور والانصراف',
  sales: 'التارجت والمبيعات',
  payroll: 'المرتبات',
  reports: 'التقارير',
  reviews: 'تقييم المدير',
  profile: 'ملف الموظف',
  tasks: 'المهام',
  leaves: 'الإجازات',
  notifications: 'التنبيهات',
  settings: 'الإعدادات',
};
function formValues(form) {
  if (!form) return [];
  return [...form.elements]
    .filter((element) => element.name)
    .map((element) => ({
      name: element.name,
      value: element.value,
      checked: element.checked,
      file: element.type === 'file' ? element : null,
    }));
}
function restoreForm(form, values) {
  if (!form) return;
  for (const item of values) {
    const field = form.querySelector('[name="' + item.name + '"]');
    if (!field) continue;
    if (item.file) field.replaceWith(item.file);
    else {
      field.value = item.value;
      if (field.type === 'checkbox') field.checked = item.checked;
    }
  }
}
async function restoreModal(kind, id, values, slipId) {
  if (slipId) {
    payslip(Number(slipId));
    return;
  }
  const value = (name) => values.find((item) => item.name === name)?.value;
  const employeeId = Number(value('employee_id'));
  if (kind === 'employee') openEmployee(id);
  else if (kind === 'attendance') openAttendance(id);
  else if (kind === 'review') openReview(id);
  else if (kind === 'bonus') openBonus(id);
  else if (kind === 'account') openAccount(id);
  else if (kind === 'account-reset')
    openAccount(data.accounts.find((row) => row.id === id).employee_id);
  else if (kind === 'password') openPassword();
  else if (kind === 'leave') openLeave();
  else if (kind === 'leave-decision') openLeaveDecision(id);
  else if (kind === 'task') openTask(id);
  else if (kind === 'task-status') openTaskStatus(id);
  else if (kind === 'restore') await featureAction('backup-restore', 0);
  else if (kind === 'target') openTarget(employeeId);
  else if (kind === 'sale') openSale();
  else if (kind === 'sale-decision') openSaleDecision(id);
  else if (kind === 'sales-demo') openSalesDemo();
  else if (kind === 'payroll-approval') openPayrollApproval(id);
  restoreForm(document.querySelector('#modal form'), values);
}
async function switchLanguage() {
  if (busy) return;
  const modal = document.querySelector('#modal');
  const modalForm = modal.querySelector('form');
  const isModalOpen = modal.open;
  const kind = modalForm?.dataset.kind;
  const id = Number(modalForm?.dataset.id || 0);
  const modalValues = formValues(modalForm);
  const slipId = !modalForm && isModalOpen ? modal.dataset.payslipId : null;
  const screenForm =
    document.querySelector('#settings-form') ||
    document.querySelector('#login-form');
  const screenId = screenForm?.id;
  const screenValues = formValues(screenForm);
  currentLanguage = currentLanguage === 'ar' ? 'en' : 'ar';
  try {
    localStorage.setItem('nazemly.language', currentLanguage);
  } catch (error) {}
  applyLanguage();
  for (const [key, label] of Object.entries(PAGE_LABELS)) names[key] = t(label);
  if (data) render();
  else login();
  restoreForm(
    screenId ? document.getElementById(screenId) : null,
    screenValues,
  );
  if (isModalOpen) await restoreModal(kind, id, modalValues, slipId);
  document
    .querySelectorAll('input,textarea,select')
    .forEach((field) => field.setCustomValidity(''));
  document.querySelector('#toast').className = '';
}
document.addEventListener(
  'invalid',
  (event) => {
    const input = event.target;
    const validity = input.validity;
    if (validity.valueMissing) {
      input.setCustomValidity(
        t(input.type === 'checkbox' ? 'أكّد هذا الاختيار' : 'هذا الحقل مطلوب'),
      );
    } else if (validity.rangeUnderflow) {
      input.setCustomValidity(
        t('القيمة يجب ألا تقل عن {limit}', { limit: input.min }),
      );
    } else if (validity.rangeOverflow) {
      input.setCustomValidity(
        t('القيمة يجب ألا تزيد عن {limit}', { limit: input.max }),
      );
    } else if (validity.tooShort) {
      input.setCustomValidity(
        t('أدخل {limit} أحرف على الأقل', { limit: input.minLength }),
      );
    } else if (validity.tooLong) {
      input.setCustomValidity(
        t('الحد الأقصى {limit} حرفًا', { limit: input.maxLength }),
      );
    } else if (
      validity.badInput ||
      validity.typeMismatch ||
      validity.patternMismatch
    ) {
      input.setCustomValidity(t('راجع صيغة القيمة المدخلة'));
    }
  },
  true,
);
document.addEventListener('input', (event) => {
  if (event.target.setCustomValidity) event.target.setCustomValidity('');
});
document.addEventListener('change', (event) => {
  if (event.target.setCustomValidity) event.target.setCustomValidity('');
});
applyLanguage();
