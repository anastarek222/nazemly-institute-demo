'use strict';
/* Employee account, leave, task and settings form handlers. */
async function featureAction(a, id) {
  if (a === 'account-open') {
    openAccount(id);
    return true;
  }
  if (a === 'account-state') {
    const u = data.accounts.find((a) => a.id === id);
    if (confirm(ui('تغيير حالة دخول الموظف وإنهاء جلساته الحالية؟')))
      await action('accounts/state', { id, enabled: u.enabled ? 0 : 1 });
    return true;
  }
  if (a === 'password-open') {
    openPassword();
    return true;
  }
  if (a === 'demo-reset-open') {
    if (!data.demo_reset_allowed) return true;
    formOpen(
      ui('إعادة بداية نسخة العرض'), 'demo-reset', 0,
      '<p class="hint wide">' +
      ui('هيتم مسح تغييرات الـDemo فقط وإرجاع المهام والحضور والمبيعات والمرتبات لحالة البداية. نسخة التشغيل العادية مش هتتأثر.') +
      '</p>' +
      field(ui('كلمة مرور المدير'), 'password', '', 'password', 'required autocomplete="current-password"') +
      '<label class="wide confirm-check"><input type="checkbox" name="confirmed" value="yes" required> ' +
      ui('فاهم إن تغييرات نسخة العرض الحالية هتتمسح') + '</label>'
    );
    return true;
  }
  if (a === 'self-in' || a === 'self-out') {
    await action('attendance/self', { kind: a === 'self-in' ? 'in' : 'out' });
    return true;
  }
  if (a === 'leave-new') {
    openLeave();
    return true;
  }
  if (a === 'leave-decide') {
    openLeaveDecision(id);
    return true;
  }
  if (a === 'leave-cancel') {
    if (confirm(ui('إلغاء طلب الإجازة؟')))
      await action('leaves/cancel', { id });
    return true;
  }
  if (a === 'task-new' || a === 'task-edit') {
    openTask(id);
    return true;
  }
  if (a === 'task-status') {
    openTaskStatus(id);
    return true;
  }
  if (a === 'notifications-read') {
    await action('notifications/read', {});
    return true;
  }
  if (a === 'payslip') {
    payslip(id);
    return true;
  }
  if (a === 'payslip-print') {
    document.body.classList.add('print-payslip');
    window.print();
    document.body.classList.remove('print-payslip');
    return true;
  }
  if (a === 'backup-export') {
    try {
      const b = await api('backup/export');
      const url = URL.createObjectURL(
        new Blob([JSON.stringify(b, null, 2)], { type: 'application/json' }),
      );
      const link = document.createElement('a');
      link.href = url;
      link.download = 'Nazm-backup-' + data.today + '.json';
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (e) {
      toast(e.message, true);
    }
    return true;
  }
  if (a === 'backup-restore') {
    formOpen(
      ui('استعادة بيانات النسخة الأساسية'),
      'restore',
      0,
      ui(
        '<label class="wide">ملف النسخة الاحتياطية<input type="file" name="backup_file" accept=".json,application/json" required></label>',
      ) +
        field(
          ui('كلمة مرور المدير الحالية'),
          'password',
          '',
          'password',
          'required autocomplete="current-password"',
        ) +
        ui(
          '<label class="wide check-label"><input type="checkbox" name="confirm_restore" required>أفهم أن الاستعادة تستبدل البيانات الحالية وتنهي الجلسات</label>',
        ),
    );
    return true;
  }
  return false;
}
async function featureSubmit(f, v) {
  const kind = f.dataset.kind;
  let path = '',
    body = { ...v };
  const id = Number(f.dataset.id);
  if (f.id === 'settings-form') {
    path = 'settings';
    for (const k of [
      'grace_minutes',
      'quarter_until',
      'half_until',
      'absence_days',
      'payroll_divisor',
      'weight_quality',
      'weight_productivity',
      'weight_teamwork',
    ])
      body[k] = Number(body[k]);
    body.departments = body.departments
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);
  } else if (kind === 'account') {
    path = 'accounts/save';
    body.employee_id = id;
  } else if (kind === 'account-reset') {
    path = 'accounts/reset';
    body.id = id;
  } else if (kind === 'demo-reset') {
    if (!data.demo_reset_allowed || body.confirmed !== 'yes') return true;
    path = 'demo/reset';
    body = { password: body.password, confirm: 'RESET' };
  } else if (kind === 'password') {
    path = 'password';
  } else if (kind === 'leave') {
    path = 'leaves/request';
  } else if (kind === 'leave-decision') {
    path = 'leaves/decide';
    body.id = id;
  } else if (kind === 'task') {
    path = 'tasks/save';
    body.employee_id = Number(body.employee_id);
    if (id) body.id = id;
  } else if (kind === 'task-status') {
    path = 'tasks/status';
    body.id = id;
  } else if (kind === 'restore') {
    if (!f.elements.confirm_restore.checked) return true;
    const file = f.elements.backup_file.files[0];
    if (!file || file.size > 4500000) {
      toast(ui('اختر نسخة JSON بحجم أقل من 4.5 ميجابايت'), true);
      return true;
    }
    try {
      body = { password: body.password, backup: JSON.parse(await file.text()) };
    } catch (e) {
      toast(ui('الملف ليس JSON صالحًا'), true);
      return true;
    }
    path = 'backup/restore';
  } else return false;
  if (busy) return true;
  setBusy(true);
  const submit = f.querySelector('[type=submit]');
  if (submit) submit.disabled = true;
  try {
    const result = await api(path, body);
    $('#modal').close();
    if (result.logout) {
      login();
      toast(ui('تم الحفظ. سجّل دخولك من جديد.'));
    } else {
      await load();
      render();
      toast(ui('تم حفظ التغييرات بنجاح'));
    }
  } catch (e) {
    toast(e.message, true);
  } finally {
    setBusy(false);
    if (submit?.isConnected) submit.disabled = false;
  }
  return true;
}
document.addEventListener('change', (e) => {
  if (e.target.id === 'profile-select') {
    profileId = Number(e.target.value);
    render();
  }
});
