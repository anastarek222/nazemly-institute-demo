/* Chat interface and suggested questions. */
let helperOwner = null;
let helperOpen = false;
let helperBusy = false;
let helperMessages = [];

function helperText(ar, en) {
  return currentLanguage === 'en' ? en : ar;
}
function helperPrompts(manager, currentPage = 'overview') {
  const employee = {
    overview: [
      ['مهامي النهارده', 'فاضلي كام على التارجت؟', 'مرتبي كام؟', 'قواعد التأخير'],
      ['My tasks today', 'Remaining target', 'My salary', 'Late policy'],
    ],
    tasks: [
      ['مهامي النهارده', 'مهامي بكرة', 'مهامي إيه؟', 'قواعد التأخير'],
      ['My tasks today', 'My tasks tomorrow', 'My tasks', 'Late policy'],
    ],
    sales: [
      ['تارجت النهارده كام؟', 'فاضلي كام على التارجت؟', 'مبيعات قيد المراجعة', 'تارجت الشهر اللي فات'],
      ['Today target', 'Remaining target', 'Pending sales', 'Last month target'],
    ],
    payroll: [
      ['مرتبي اتعمد ولا لسه؟', 'خصمي الشهر ده كام؟', 'مرتب الشهر اللي فات؟', 'لو اتأخرت 40 دقيقة؟'],
      ['Is my salary approved?', 'My deductions this month', 'Last month salary', 'Late 40 minutes'],
    ],
    attendance: [
      ['حضوري النهارده', 'غيابي الشهر ده', 'قواعد التأخير', 'مواعيد الشغل إيه؟'],
      ['My attendance today', 'My absences this month', 'Late policy', 'Work hours'],
    ],
    leaves: [
      ['إجازاتي الشهر ده؟', 'إجازات الشهر اللي فات؟', 'إجازتي النهارده؟', 'مهامي إيه؟'],
      ['My leaves this month', 'Last month leave', 'My leave today', 'My tasks'],
    ],
    reviews: [
      ['تقييمي الشهر اللي فات كام؟', 'تقييمي الشهر ده؟', 'مهامي إيه؟', 'مرتبي كام؟'],
      ['My review last month', 'My performance this month', 'My tasks', 'My salary'],
    ],
  };
  const lead = {
    overview: [
      ['المبيعات المعلقة', 'مسودات المرتبات', 'مهام الفريق', 'قواعد التأخير'],
      ['Pending sales', 'Draft payroll', 'Team tasks', 'Late policy'],
    ],
    tasks: [
      ['مهام الفريق النهارده', 'مهام الفريق', 'المبيعات المعلقة', 'مواعيد الشغل إيه؟'],
      ['Team tasks today', 'Team tasks', 'Pending sales', 'Work hours'],
    ],
    sales: [
      ['المبيعات المعلقة', 'تارجت النهارده', 'تارجت الشهر اللي فات', 'مسودات المرتبات'],
      ['Pending sales', 'Today target', 'Last month target', 'Draft payroll'],
    ],
    payroll: [
      ['مسودات المرتبات', 'المرتبات اتعمدت؟', 'قواعد التأخير', 'مهام الفريق'],
      ['Draft payroll', 'Approved payroll', 'Late policy', 'Team tasks'],
    ],
    attendance: [
      ['حضور النهارده', 'حضور الشهر ده', 'قواعد التأخير', 'مهام الفريق'],
      ['Attendance today', 'Attendance this month', 'Late policy', 'Team tasks'],
    ],
    leaves: [
      ['إجازات الشهر ده؟', 'إجازات الشهر اللي فات؟', 'مهام الفريق', 'مسودات المرتبات'],
      ['Leave this month', 'Leave last month', 'Team tasks', 'Draft payroll'],
    ],
    reports: [
      ['تارجت الشهر ده', 'المبيعات المعلقة', 'حضور الشهر ده', 'مسودات المرتبات'],
      ['This month target', 'Pending sales', 'Attendance this month', 'Draft payroll'],
    ],
    settings: [
      ['مواعيد الشغل إيه؟', 'قواعد التأخير', 'مسودات المرتبات', 'مهام الفريق'],
      ['Work hours', 'Late policy', 'Draft payroll', 'Team tasks'],
    ],
  };
  const group = manager ? lead : employee;
  const prompts = group[currentPage] || group.overview;
  return prompts[currentLanguage === 'en' ? 1 : 0];
}
function assistantReset() {
  helperOwner = null;
  helperOpen = false;
  helperBusy = false;
  helperMessages = [];
  const root = document.querySelector('#assistant-root');
  if (root) root.innerHTML = '';
}
function assistantSync(state) {
  if (!state || !state.user) {
    assistantReset();
    return;
  }
  const owner = state.user.role + ':' + state.user.id;
  if (owner !== helperOwner) {
    helperOwner = owner;
    helperOpen = false;
    helperMessages = [];
    helperBusy = false;
  }
  assistantRender();
}
function assistantRender() {
  const root = document.querySelector('#assistant-root');
  if (!root || !data || !data.user) return;
  const manager = data.user.role === 'manager';
  const title = helperText('مساعد نظملي', 'Nazemly Assistant');
  const t = (ar, en) => helperText(ar, en);
  const lines = helperMessages.map((message, index) =>
    '<div class="helper-message ' + (message.role === 'user' ? 'helper-mine' : 'helper-reply') +
    '"><p dir="auto">' + esc(message.text) + '</p>' +
    (message.page && message.page !== 'overview' ?
       '<button type="button" class="helper-open-page" data-helper-index="' + index +
       '" data-helper-page="' + esc(message.page) +
       '">' + esc(t('افتح الصفحة', 'Open page')) + ' ' + svgIcon('arrow') + '</button>' : '') +
    '</div>'
  ).join('');
  const prompts = helperPrompts(manager, page).map((question) =>
    '<button type="button" data-helper-prompt="' + esc(question) + '">' + esc(question) + '</button>'
  ).join('');
  root.innerHTML =
    '<button type="button" class="helper-launcher" data-helper-toggle aria-expanded="' + helperOpen +
    '" aria-controls="helper-panel" aria-label="' + esc(title) + '">' +
    svgIcon('tasks') + '<span>' + esc(title) + '</span></button>' +
    '<section class="helper-panel' + (helperOpen ? ' helper-visible' : '') +
    '" id="helper-panel" role="dialog" aria-label="' + esc(title) + '"' +
    (helperOpen ? '' : ' hidden') + '>' +
    '<header class="helper-header"><span class="helper-brand">' + svgIcon('tasks') +
    '</span><div><strong>' + esc(title) +
    '</strong><small>' + esc(t('اسأل عن مهامك وشغلك', 'Help with your work and records')) +
    '</small></div><button type="button" class="helper-close" data-helper-toggle aria-label="' +
    esc(t('إغلاق', 'Close')) + '">×</button></header>' +
    '<div class="helper-thread" aria-live="polite">' +
    '<div class="helper-message helper-reply"><p>' +
    esc(t('أهلًا بيك! اسألني عن مهامك والتارجت والمرتب والحضور، أو اختار سؤال من تحت.',
          'Hi! Ask about tasks, targets, payroll and attendance, or pick a question below.')) +
    '</p></div>' + lines +
    (helperBusy ? '<div class="helper-thinking">' + esc(t('براجع بياناتك...', 'Checking your records...')) + '</div>' : '') +
    '</div><div class="helper-prompts"><span class="helper-prompts-title">' +
    esc(t('أسئلة مناسبة للصفحة دي', 'Questions for this page')) +
    '</span>' + prompts + '</div>' +
    '<form id="helper-form" class="helper-form">' +
    '<input name="question" type="text" autocomplete="off" maxlength="180" required ' +
    'placeholder="' + esc(t('اكتب سؤالك هنا...', 'Type your question...')) + '" ' +
    'aria-label="' + esc(t('سؤالك للمساعد', 'Ask the assistant')) + '"' +
    (helperBusy ? ' disabled' : '') + '>' +
    '<button type="submit" aria-label="' + esc(t('إرسال', 'Send')) + '"' +
    (helperBusy ? ' disabled' : '') + '>' + svgIcon('arrow') + '</button></form>' +
    '</section>';
  if (helperOpen) {
    const thread = root.querySelector('.helper-thread');
    thread.scrollTop = thread.scrollHeight;
  }
}

async function assistantAsk(question) {
  const message = String(question || '').trim();
  if (!data || !data.user || helperBusy || !message) return;
  if (message.length > 180) {
    toast(helperText('السؤال طويل؛ اختصره شوية.', 'Please shorten your question.'), true);
    return;
  }
  const owner = helperOwner;
  helperMessages.push({role:'user', text:message});
  helperMessages = helperMessages.slice(-16);
  helperBusy = true;
  assistantRender();
  try {
    const result = await api('assistant/ask', {
      question:message, month, language:currentLanguage,
    });
    if (helperOwner !== owner || !data || !data.user) return;
    const allowed = ['overview','tasks','attendance','payroll','sales','leaves','reviews'];
    helperMessages.push({
      role:'assistant',
      text:result.answer,
      page: allowed.includes(result.page) ? result.page : 'overview',
      month: result.month,
    });
  } catch (error) {
    if (helperOwner !== owner) return;
    helperMessages.push({
      role:'assistant',
      text: error.status === 401
        ? helperText('سجل دخولك الأول عشان أقدر أساعدك.', 'Please sign in to continue.')
        : helperText('مش قادر أجيب الرد دلوقتي. جرّب تاني.', 'Could not fetch the answer. Please retry.'),
    });
  } finally {
    if (helperOwner === owner) {
      helperBusy = false;
      helperMessages = helperMessages.slice(-16);
      assistantRender();
    }
  }
}

document.addEventListener('click', async (event) => {
  const toggle = event.target.closest('[data-helper-toggle]');
  if (toggle) {
    event.preventDefault();
    helperOpen = !helperOpen;
    assistantRender();
    if (helperOpen) document.querySelector('#helper-form input')?.focus();
    return;
  }
  const prompt = event.target.closest('[data-helper-prompt]');
  if (prompt) {
    event.preventDefault();
    await assistantAsk(prompt.dataset.helperPrompt);
    return;
  }
  const open = event.target.closest('[data-helper-page]');
  if (open) {
    event.preventDefault();
    if (busy) return;
    const destination = open.dataset.helperPage;
    if (!['overview','tasks','attendance','payroll','sales','leaves','reviews'].includes(destination)) return;
    page = destination;
    const answerMessage = helperMessages[Number(open.dataset.helperIndex)];
    if (answerMessage?.month) month = answerMessage.month;
    search = '';
    try {
      setBusy(true);
      await load();
      helperOpen = false;
      render();
    } catch (error) {
      toast(error.message, true);
    } finally {
      setBusy(false);
    }
  }
});

document.addEventListener('submit', async (event) => {
  if (event.target.id !== 'helper-form') return;
  event.preventDefault();
  event.stopPropagation();
  const question = event.target.elements.question.value;
  await assistantAsk(question);
}, true);

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && helperOpen) {
    helperOpen = false;
    assistantRender();
    document.querySelector('[data-helper-toggle]')?.focus();
  }
});
