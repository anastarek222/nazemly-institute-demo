/* First-login welcome, based on each employee's actual company rules and tasks. */
function showOnboarding() {
  const dialog = document.querySelector('#welcome-dialog');
  if (!data || !data.onboarding_pending || data.user.role !== 'employee') {
    if (dialog.open) dialog.close();
    return;
  }
  const s = data.settings;
  const english = currentLanguage === 'en';
  const name = esc(data.employees[0]?.name || data.user.username);
  const start = esc(s.work_start), end = esc(s.work_end);
  const extra = data.tasks.slice(0, 3).map((task) =>
    '<li><strong>' + esc(task.title) + '</strong><small>' +
    esc(task.due_day) + '</small></li>').join('');
  const rules = english ? [
    ['Your hours', start + ' – ' + end + '. Press Start work when you arrive, and End work before you leave.'],
    ['Grace period', 'Up to ' + s.grace_minutes + ' minutes late: no deduction.'],
    ['Late arrival', 'From minute ' + (s.grace_minutes + 1) + ' to ' +
      (s.quarter_until - 1) + ': quarter-day deduction. ' +
      'From ' + s.quarter_until + ' to ' + (s.half_until - 1) + ': half day. ' +
      'From ' + s.half_until + ' onward: one day.'],
    ['Absence & leave', 'Unexcused absence: ' + s.absence_days +
      ' penalty days. Apply for leave in the system. An unrecorded day is not automatically marked absent.'],
    ['Your work', 'You can track your tasks and target. Only manager-approved sales count.']
  ] : [
    ['مواعيدك', 'شغلك من ' + start + ' لـ ' + end +
      '. دوس «بدء العمل» أول ما توصل، و«إنهاء العمل» قبل ما تمشي.'],
    ['وقت السماح', 'متاح لك لحد ' + s.grace_minutes + ' دقيقة تأخير من غير خصم.'],
    ['لو اتأخرت', 'من الدقيقة ' + (s.grace_minutes + 1) + ' لأقل من ' +
      s.quarter_until + ' خصم ربع يوم، ومن ' + s.quarter_until +
      ' لأقل من ' + s.half_until + ' نص يوم، ومن ' + s.half_until +
      ' فأكتر يوم كامل.'],
    ['الإجازات والغياب', 'الغياب من غير إذن جزاؤه ' + s.absence_days +
      ' أيام. اطلب إجازتك من النظام، واليوم اللي مش متسجل بيتراجع مع المدير ومش بيتحسب غياب تلقائي.'],
    ['شغلك وتارجتك', 'هتلاقي مهامك وتارجتك في حسابك. المبيعات بتتحسب بعد اعتماد المدير.']
  ];

  dialog.innerHTML =
    '<div class="welcome-sheet"><div class="welcome-hero">' +
    '<div class="welcome-icon" aria-hidden="true">✦</div>' +
    '<div><span class="welcome-kicker">NAZEMLY · TEAM</span><h2 id="welcome-title">' +
    (english ? 'Welcome, ' : 'أهلاً بيك يا ') + name + ' 👋</h2><p>' +
    (english ? "Everything you need for a smooth first day." :
      'بص على القواعد دي، وهتكون جاهز تبدأ يومك معانا.') +
    '</p></div>' + languageButton() + '</div>' +
    '<div class="welcome-rules">' +
    rules.map(([title,description], i) =>
      '<div class="welcome-rule"><span>' + String(i + 1).padStart(2, '0') +
      '</span><div><strong>' + esc(title) + '</strong><p>' +
      esc(description) + '</p></div></div>').join('') +
    '</div>' +
    (extra ? '<section class="welcome-tasks"><strong>' +
      (english ? 'Your first tasks' : 'أول مهام ليك') +
      '</strong><ul>' + extra + '</ul></section>' : '') +
    '<div class="welcome-note">' +
      (english ? 'Early check-out is reviewed by your manager; there is no automatic deduction.' :
       'لو خرجت بدري هيتراجع الموضوع مع المدير، من غير خصم تلقائي.') +
    '</div>' +
    '<button type="button" class="primary welcome-go" data-action="onboarding-ack">' +
    (english ? "Got it, let's start" : 'تمام، فهمت.. يلا نبدأ') +
    '</button></div>';
  if (!dialog.open) dialog.showModal();
}
