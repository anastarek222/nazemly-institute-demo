'use strict';
// Small offline SVG icon set using familiar line-icon conventions.
// No network requests or font files; ships with every standalone ZIP.
const iconPaths = {
  dashboard: '<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>',
  users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  wallet: '<rect x="3" y="5" width="18" height="15" rx="2"/><path d="M3 9h18M16 14h2"/>',
  chart: '<path d="M3 3v18h18M7 17v-4M12 17V9M17 17V5"/>',
  profile: '<circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
  tasks: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="m7 11 2 2 4-4M15 10h3M15 15h3"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18M7 14h3M13 14h3"/>',
  bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
  settings: '<path d="M10.2 2.4h3.6l.5 2.2a8.4 8.4 0 0 1 1.9.8l1.9-1.2 2.5 2.5-1.2 1.9a8.4 8.4 0 0 1 .8 1.9l2.2.5v3.6l-2.2.5a8.4 8.4 0 0 1-.8 1.9l1.2 1.9-2.5 2.5-1.9-1.2a8.4 8.4 0 0 1-1.9.8l-.5 2.2h-3.6l-.5-2.2a8.4 8.4 0 0 1-1.9-.8l-1.9 1.2-2.5-2.5 1.2-1.9a8.4 8.4 0 0 1-.8-1.9l-2.2-.5v-3.6l2.2-.5a8.4 8.4 0 0 1 .8-1.9l-1.2-1.9 2.5-2.5 1.9 1.2a8.4 8.4 0 0 1 1.9-.8Z"/><circle cx="12" cy="12" r="3.2"/>',
  receipt: '<path d="M5 3h14v18l-3-2-4 2-4-2-3 2V3Z"/><path d="M9 8h6M9 12h6"/>',
  alert: '<circle cx="12" cy="12" r="9"/><path d="M12 7v6M12 17h.01"/>',
  file: '<path d="M13 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V10Z"/><path d="M13 3v7h7M8 15h8M8 18h6"/>',
  trend: '<path d="m3 17 6-6 4 4 7-7M14 8h6v6"/>',
  check: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
  star: '<path d="m12 2 3.1 6.5 7.1 1-5.1 5 .9 7-6-3.4-6 3.4.9-7-5.1-5 7.1-1Z"/>',
  arrow: '<path d="m15 18-6-6 6-6"/>',
};
function svgIcon(name, extra = '') {
  const path = iconPaths[name] || iconPaths.dashboard;
  return '<svg class="ui-icon ' + extra +
    '" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" ' +
    'fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" ' +
    'stroke-linejoin="round" aria-hidden="true" focusable="false">' + path + '</svg>';
}
