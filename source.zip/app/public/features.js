/* Employee accounts, attendance, leave, tasks and backups. */
Object.assign(names, {
  profile: ui('ملف الموظف'),
  leaves: ui('الإجازات'),
  tasks: ui('المهام'),
  notifications: ui('التنبيهات'),
  settings: ui('الإعدادات'),
});
Object.assign(icons, {
  profile: 'profile',
  leaves: 'calendar',
  tasks: 'tasks',
  notifications: 'bell',
  settings: 'settings',
});
let profileId = null;
function accountControls(eid) {
  const a = data.accounts.find((a) => a.employee_id === eid);
  return button(
    a ? ui('إدارة الحساب') : ui('إنشاء حساب'),
    'account-open',
    eid,
    'secondary small',
  );
}
function openAccount(eid) {
  const a = data.accounts.find((a) => a.employee_id === eid);
  if (!a)
    return formOpen(
      ui('حساب دخول — ') + employee(eid),
      'account',
      eid,
      field(
        ui('اسم المستخدم بالإنجليزية'),
        'username',
        '',
        'text',
        'required minlength="3" maxlength="40" autocomplete="off"',
      ) +
        field(
          ui('كلمة المرور'),
          'password',
          '',
          'password',
          'required minlength="8" maxlength="200" autocomplete="new-password"',
        ),
    );
  formOpen(
    ui('إدارة حساب ') + esc(a.username),
    'account-reset',
    a.id,
    field(
      ui('كلمة المرور الجديدة'),
      'password',
      '',
      'password',
      'required minlength="8" maxlength="200" autocomplete="new-password"',
    ) +
      '<div class="wide">' +
      button(
        a.enabled ? ui('تعطيل الدخول') : ui('تفعيل الدخول'),
        'account-state',
        a.id,
        a.enabled ? 'secondary' : 'primary',
      ) +
      ui(
        '</div><p class="hint wide">التعطيل أو تغيير كلمة المرور ينهي جلسات الموظف الحالية.</p>',
      ),
  );
}
function openPassword() {
  formOpen(
    ui('تغيير كلمة المرور'),
    'password',
    0,
    field(
      ui('كلمة المرور الحالية'),
      'current_password',
      '',
      'password',
      'required autocomplete="current-password"',
    ) +
      field(
        ui('كلمة المرور الجديدة'),
        'new_password',
        '',
        'password',
        'required minlength="8" maxlength="200" autocomplete="new-password"',
      ) +
      ui(
        '<p class="hint wide">بعد الحفظ ستحتاج تسجيل الدخول بكلمة المرور الجديدة.</p>',
      ),
  );
}
function selfAttendance() {
  const row = data.today_attendance;
  return (
    ui('<section class="panel self-attendance"><div><h3>حضورك اليوم — ') +
    esc(data.today) +
    '</h3><p class="subtle">' +
    (row
      ? row.status === 'leave'
        ? ui('إجازة معتمدة')
        : row.status === 'absent'
          ? ui('غياب مسجّل')
          : ui('الحضور ') +
            esc(row.check_in || '—') +
            ui(' · الانصراف ') +
            esc(row.check_out || ui('لم يسجل'))
      : ui('لم تسجل حضورك بعد')) +
    '</p></div><div class="actions">' +
    (!row
      ? button(ui('بدء العمل'), 'self-in')
      : row.status === 'present' && !row.check_out
        ? button(ui('إنهاء العمل'), 'self-out')
        : '') +
    '</div></section>'
  );
}
function leavesPage() {
  const manager = data.user.role === 'manager',
    label = {
      pending: ui('بانتظار الموافقة'),
      approved: ui('مقبول'),
      rejected: ui('مرفوض'),
      cancelled: ui('ملغي'),
    };
  return (
    ui(
      '<section class="panel"><div class="toolbar"><div><h3>طلبات الإجازات</h3><p class="subtle">الطلبات عبر جميع الشهور. كل فترة تشمل الأيام التقويمية من البداية للنهاية.</p></div>',
    ) +
    (!manager ? button(ui('+ طلب إجازة'), 'leave-new') : '') +
    '</div>' +
    table(
      [
        ui('الموظف'),
        ui('من'),
        ui('إلى'),
        ui('السبب'),
        ui('الحالة'),
        ui('رد الإدارة'),
        ui('الإجراءات'),
      ],
      data.leaves.map((r) => [
        esc(employee(r.employee_id)),
        esc(r.start_day),
        esc(r.end_day),
        '<span class="wrap-text">' + esc(r.reason) + '</span>',
        tag(
          label[r.status],
          r.status === 'approved'
            ? 'green'
            : r.status === 'pending'
              ? 'amber'
              : r.status === 'rejected'
                ? 'red'
                : '',
        ),
        '<span class="wrap-text">' + esc(r.decision_note || '—') + '</span>',
        r.status === 'pending'
          ? manager
            ? button(ui('مراجعة الطلب'), 'leave-decide', r.id, 'primary small')
            : button(ui('إلغاء الطلب'), 'leave-cancel', r.id, 'secondary small')
          : '—',
      ]),
    ) +
    '</section>'
  );
}
function openLeave() {
  formOpen(
    ui('طلب إجازة'),
    'leave',
    0,
    field(
      ui('من تاريخ'),
      'start_day',
      data.today,
      'date',
      'required min="' + data.today + '"',
    ) +
      field(
        ui('إلى تاريخ'),
        'end_day',
        data.today,
        'date',
        'required min="' + data.today + '"',
      ) +
      ui(
        '<label class="wide">سبب الإجازة<textarea dir="auto" name="reason" required maxlength="500"></textarea></label><p class="hint wide">حد أقصى 31 يومًا للطلب. لا تسجل الإجازة في الحضور إلا بعد موافقة المدير.</p>',
      ),
  );
}
function openLeaveDecision(id) {
  const r = data.leaves.find((r) => r.id === id);
  formOpen(
    ui('مراجعة إجازة ') + employee(r.employee_id),
    'leave-decision',
    id,
    selectField(
      ui('القرار'),
      'status',
      ui(
        '<option value="approved">موافقة</option><option value="rejected">رفض</option>',
      ),
    ) +
      ui(
        '<label class="wide">سبب القرار (إلزامي عند الرفض)<textarea dir="auto" name="decision_note" maxlength="500"></textarea></label><p class="hint wide">من ',
      ) +
      esc(r.start_day) +
      ui(' إلى ') +
      esc(r.end_day) +
      ui(
        '. الموافقة تسجل أيام إجازة بدون خصم. لا يمكن تعديل الطلب المقبول.</p>',
      ),
  );
}
function tasksPage() {
  const manager = data.user.role === 'manager',
    labels = {
      todo: ui('لم تبدأ'),
      doing: ui('قيد التنفيذ'),
      done: ui('مكتملة'),
    };
  const overdue = data.tasks.filter(
    (t) => t.status !== 'done' && t.due_day < data.today,
  );
  return (
    '<div class="stats three">' +
    stat(ui('كل المهام'), data.tasks.length) +
    stat(ui('مهام مكتملة'),
         data.tasks.filter((t) => t.status === 'done').length) +
    stat(ui('مهام متأخرة'), overdue.length) +
    '</div><section class="panel"><div class="toolbar"><div><h3>' +
    (manager ? ui('مهام الفريق') : ui('مهامي')) +
    '</h3><p class="subtle">' + ui('المهام المسندة وتواريخ تسليمها') +
    '</p></div>' +
    (manager ? button(ui('+ إضافة مهمة'), 'task-new') : '') +
    '</div>' +
    table(
      [
        ui('المهمة'),
        ui('الموظف'),
        ui('التسليم'),
        ui('الحالة'),
        ui('الإجراءات'),
      ],
      data.tasks.map((t) => [
        '<strong>' +
          esc(t.title) +
          '</strong><small class="task-description">' +
          esc(t.description) +
          '</small>',
        esc(employee(t.employee_id)),
        esc(t.due_day) +
          (t.status !== 'done' && t.due_day < data.today
            ? ' ' + tag(ui('متأخرة'), 'red')
            : t.status !== 'done' && t.due_day === data.today
              ? ' ' + tag(ui('تسليم النهارده'), 'blue')
              : ''),
        tag(
          labels[t.status],
          t.status === 'done'
            ? 'green'
            : t.status === 'doing'
              ? 'blue'
              : 'amber',
        ),
        button(ui('تحديث الحالة'), 'task-status', t.id, 'secondary small') +
          (manager
            ? ' ' + button(ui('تعديل'), 'task-edit', t.id, 'text-button')
            : ''),
      ]),
    ) +
    '</section>'
  );
}
function openTask(id) {
  const t = data.tasks.find((t) => t.id === id) || {};
  formOpen(
    id ? ui('تعديل مهمة') : ui('إضافة مهمة'),
    'task',
    id,
    field(
      ui('عنوان المهمة'),
      'title',
      t.title || '',
      'text',
      'required maxlength="150"',
    ) +
      selectField(
        ui('الموظف المسؤول'),
        'employee_id',
        employeeOptions(t.employee_id),
      ) +
      field(
        ui('موعد التسليم'),
        'due_day',
        t.due_day || data.today,
        'date',
        'required',
      ) +
      ui(
        '<label class="wide">تفاصيل المهمة<textarea dir="auto" name="description" maxlength="1000">',
      ) +
      esc(t.description || '') +
      '</textarea></label>',
  );
}
function openTaskStatus(id) {
  const t = data.tasks.find((t) => t.id === id);
  formOpen(
    ui('تحديث حالة المهمة'),
    'task-status',
    id,
    selectField(
      ui('الحالة'),
      'status',
      [
        ['todo', ui('لم تبدأ')],
        ['doing', ui('قيد التنفيذ')],
        ['done', ui('مكتملة')],
      ]
        .map(
          ([v, label]) =>
            '<option value="' +
            v +
            '" ' +
            (t.status === v ? 'selected' : '') +
            '>' +
            label +
            '</option>',
        )
        .join(''),
    ) +
      '<p class="hint wide">' +
      esc(t.title) +
      '</p>',
  );
}
function notificationsPage() {
  const overdue = data.tasks.filter(
    (t) => t.status !== 'done' && t.due_day < data.today,
  );
  return (
    ui('<section class="panel"><div class="toolbar"><h3>مركز التنبيهات</h3>') +
    button(ui('تحديد الكل كمقروء'), 'notifications-read', '', 'secondary') +
    '</div>' +
    (overdue.length
      ? '<div class="policy"><strong>' +
        overdue.length +
        ui(' مهام متأخرة</strong><p>') +
        overdue.map((t) => esc(t.title)).join(' · ') +
        '</p></div>'
      : '') +
    (data.notifications.length
      ? data.notifications
          .map(
            (n) =>
              '<article class="notification ' +
              (!n.read_at ? 'unread' : '') +
              '"><div>' +
              (!n.read_at ? tag(ui('جديد'), 'green') : '') +
              '<p>' +
              esc(systemText(n.message)) +
              '</p><small>' +
              esc(
                new Date(n.created_at).toLocaleString(currentLocale(), {
                  timeZone: 'Africa/Cairo',
                }),
              ) +
              '</small></div></article>',
          )
          .join('')
      : empty(ui('لا توجد تنبيهات جديدة'))) +
    '</section>'
  );
}
function historyChart() {
  const rows = data.history,
    valid = rows.filter((r) => r.score != null);
  if (!valid.length) return empty(ui('لا توجد تقييمات خلال آخر 6 شهور'));
  const plot = rows
    .map((r, i) => {
      const x = 55 + i * 80;
      return (
        '<text x="' +
        x +
        '" y="156" text-anchor="middle">' +
        esc(r.month) +
        '</text>' +
        (r.score == null
          ? '<text x="' + x + '" y="120" text-anchor="middle">—</text>'
          : '<rect x="' +
            (x - 20) +
            '" y="' +
            (130 - r.score) +
            '" width="40" height="' +
            r.score +
            '" rx="5" fill="#2c7565"><title>' +
            esc(r.month) +
            ': ' +
            r.score +
            '%</title></rect><text x="' +
            x +
            '" y="' +
            (120 - r.score) +
            '" text-anchor="middle">' +
            r.score +
            '%</text>')
      );
    })
    .join('');
  return (
    ui(
      '<svg class="history-chart" viewBox="0 0 510 175" role="img" aria-label="متوسط تقييم الأداء لآخر ستة شهور"><line x1="18" y1="130" x2="495" y2="130" stroke="#d5e2da"/>',
    ) +
    plot +
    ui(
      '</svg><p class="hint">نتائج التقييم المحفوظة، وفق أوزان كل تقييم وقت تسجيله.</p>',
    )
  );
}
function profilePage() {
  const e = data.employees.find((e) => e.id == profileId) || data.employees[0];
  if (!e) return empty(ui('لا يوجد موظفون'));
  profileId = e.id;
  const attendance = data.attendance.filter((a) => a.employee_id === e.id),
    reviews = data.reviews.filter((r) => r.employee_id === e.id),
    payroll = data.payroll.filter((p) => p.employee_id === e.id),
    tasks = data.tasks.filter((t) => t.employee_id === e.id);
  return (
    '<section class="panel"><div class="toolbar"><div class="person"><span class="avatar">' +
    esc(e.name.charAt(0)) +
    '</span><div><h3>' +
    esc(e.name) +
    '</h3><small>' +
    esc(e.title) +
    ' · ' +
    esc(e.department) +
    '</small></div></div>' +
    (data.user.role === 'manager'
      ? ui('<label>اختر موظفًا<select id="profile-select">') +
        data.employees
          .map(
            (a) =>
              '<option value="' +
              a.id +
              '" ' +
              (a.id === e.id ? 'selected' : '') +
              '>' +
              esc(a.name) +
              '</option>',
          )
          .join('') +
        '</select></label>'
      : '') +
    '</div><div class="stats three">' +
    stat(ui('المرتب الأساسي'), cash(e.salary_cents), ui('جنيه مصري')) +
    stat(
      ui('أيام الحضور'),
      attendance.filter((a) => a.status === 'present').length,
      ui('في الشهر المختار'),
    ) +
    stat(
      ui('المهام المكتملة'),
      tasks.filter((t) => t.status === 'done').length,
      ui('من أصل ') + tasks.length + ui(' مهمة'),
    ) +
    ui('</div><p class="subtle">الهاتف: ') +
    esc(e.phone || ui('غير مسجل')) +
    ui(' · تاريخ الإضافة: ') +
    esc(e.created_at.slice(0, 10)) +
    ui('</p></section><section class="panel"><h3>الحضور — ') +
    esc(month) +
    '</h3>' +
    attendanceTable(attendance, false) +
    ui('</section><section class="panel"><h3>التقييم الشهري</h3>') +
    table(
      [ui('الشهر'), ui('النتيجة'), ui('ملاحظات')],
      reviews.map((r) => [esc(r.month), r.score + '%', esc(r.note || '—')]),
    ) +
    ui('</section><section class="panel"><h3>كشوف المرتب</h3>') +
    table(
      [ui('الشهر'), ui('الصافي'), ui('الحالة'), ''],
      payroll.map((p) => [
        esc(p.month),
        cash(p.net_cents),
        tag(p.status === 'approved' ? ui('معتمد') : ui('مسودة')),
        button(ui('قسيمة المرتب'), 'payslip', p.id, 'secondary small'),
      ]),
    ) +
    '</section>'
  );
}
function payslip(id) {
  $('#modal').dataset.payslipId = String(id);
  const p = data.payroll.find((p) => p.id === id);
  if (!p) return;
  const e = data.employees.find((e) => e.id === p.employee_id);
  if (!e) return;
  $('#modal').innerHTML =
    '<article class="payslip"><header><div><span class="eyebrow dark">' +
    esc(data.settings.company_name) +
    ui('</span><h2>قسيمة مرتب</h2></div>') +
    languageButton() +
    ui(
      '<button class="icon" data-action="close" aria-label="إغلاق">×</button></header><h3>',
    ) +
    esc(e.name) +
    '</h3><p>' +
    esc(e.department) +
    ' · ' +
    esc(e.title) +
    ui('</p><p>الشهر: ') +
    esc(p.month) +
    ' · ' +
    (p.status === 'approved' ? ui('كشف معتمد') : ui('مسودة غير معتمدة')) +
    '</p>' +
    table(
      [ui('البيان'), ui('القيمة')],
      [
        [ui('الأساسي'), cash(p.base_cents)],
        [ui('المكافأة'), cash(p.bonus_cents)],
        [ui('أيام الجزاء'), p.penalty_quarters / 4],
        [ui('قيمة اليوم'), cash(Math.round(p.base_cents / p.divisor))],
        [ui('الخصم'), cash(p.deduction_cents)],
        [ui('صافي المستحق'), cash(p.net_cents)],
      ],
    ) +
    deductionDetails(p) +
    ui('<p class="hint">رقم الكشف #') +
    p.id +
    ui(' · ملخص كشف المرتب.</p><footer>') +
    button(ui('طباعة القسيمة'), 'payslip-print') +
    '</footer></article>';
  $('#modal').showModal();
}
function settingsPage() {
  const s = data.settings;
  return (
    ui(
      '<section class="panel"><h3>بيانات الشركة وسياسة العمل</h3><p class="subtle">الإعدادات الجديدة تطبق على السجلات الجديدة، ومسودات المرتبات. الكشوف المعتمدة والتقييمات السابقة تحتفظ بحساباتها.</p><form id="settings-form"><div class="form-grid">',
    ) +
    field(
      ui('اسم الشركة'),
      'company_name',
      s.company_name,
      'text',
      'required maxlength="80"',
    ) +
    field(ui('بداية العمل'), 'work_start', s.work_start, 'time', 'required') +
    field(ui('نهاية العمل'), 'work_end', s.work_end, 'time', 'required') +
    field(
      ui('سماح التأخير — دقيقة'),
      'grace_minutes',
      s.grace_minutes,
      'number',
      'required min="0" max="120"',
    ) +
    field(
      ui('بداية خصم نصف يوم — دقيقة'),
      'quarter_until',
      s.quarter_until,
      'number',
      'required min="1" max="180"',
    ) +
    field(
      ui('بداية خصم يوم — دقيقة'),
      'half_until',
      s.half_until,
      'number',
      'required min="2" max="240"',
    ) +
    field(
      ui('جزاء الغياب بدون إذن — أيام'),
      'absence_days',
      s.absence_days,
      'number',
      'required min="0" max="5"',
    ) +
    field(
      ui('عدد الأيام لحساب قيمة اليوم'),
      'payroll_divisor',
      s.payroll_divisor,
      'number',
      'required min="1" max="31"',
    ) +
    field(
      ui('وزن الجودة %'),
      'weight_quality',
      s.weight_quality,
      'number',
      'required min="0" max="100"',
    ) +
    field(
      ui('وزن الإنجاز %'),
      'weight_productivity',
      s.weight_productivity,
      'number',
      'required min="0" max="100"',
    ) +
    field(
      ui('وزن التعاون %'),
      'weight_teamwork',
      s.weight_teamwork,
      'number',
      'required min="0" max="100"',
    ) +
    ui(
      '<label class="wide">الأقسام — قسم في كل سطر<textarea dir="auto" name="departments" required>',
    ) +
    esc(s.departments.join('\n')) +
    ui(
      '</textarea></label></div><p class="hint">بعد السماح وأقل من حد نصف اليوم: ربع يوم. مجموع أوزان التقييم يجب أن يساوي 100%.</p><button class="primary" type="submit">حفظ الإعدادات</button></form></section><section class="panel"><div class="toolbar"><h3>حسابات الدخول</h3>',
    ) +
    button(ui('تغيير كلمة مروري'), 'password-open', '', 'secondary') +
    '</div>' +
    table(
      [
        ui('اسم المستخدم'),
        ui('الموظف'),
        ui('الدور'),
        ui('الدخول'),
        ui('الإجراءات'),
      ],
      data.accounts.map((a) => [
        esc(a.username),
        a.employee_id ? esc(employee(a.employee_id)) : '—',
        a.role === 'manager' ? ui('مدير') : ui('موظف'),
        tag(a.enabled ? ui('مفعّل') : ui('معطّل'), a.enabled ? 'green' : 'red'),
        a.role === 'employee'
          ? button(
              ui('إدارة'),
              'account-open',
              a.employee_id,
              'secondary small',
            )
          : ui('الحساب الحالي'),
      ]),
    ) +
    ui(
      '<p class="hint">إنشاء حساب جديد متاح من صفحة الموظفين.</p></section><section class="panel"><h3>النسخ الاحتياطي والاستعادة</h3><p class="subtle">النسخة تشمل بيانات النظام وحساباته وتجزئات كلمات المرور. الاستعادة تستبدل بيانات النسخة الأساسية وتنهي كل الجلسات. تحفظ نسخة تلقائية قبل الاستعادة.</p><div class="actions">',
    ) +
    button(ui('تنزيل نسخة احتياطية'), 'backup-export', '', 'secondary') +
    button(ui('استعادة نسخة'), 'backup-restore', '', 'secondary') +
    '</div></section>' +
    (data.demo_reset_allowed
      ? '<section class="panel demo-reset-card"><h3>' + ui('إعادة ضبط نسخة العرض') +
        '</h3><p class="subtle">' +
        ui('ترجع حسابات وبيانات الـDemo لنقطة البداية من غير ما تمس نسخة التشغيل العادية.') +
        '</p>' + button(ui('إعادة البداية'), 'demo-reset-open', '', 'secondary') +
        '</section>'
      : '')
  );
}
