/* Final review screens: daily attendance, correction evidence and payroll approval. */
let selectedReviewDay = '';
let salesStatusFilter = 'all';
let lastUpdatedAt = null;
let showAllAttendance = false;
function reviewDay() {
  if (!selectedReviewDay.startsWith(month)) {
    selectedReviewDay = data.demo_day?.startsWith(month)
      ? data.demo_day
      : data.today.startsWith(month)
        ? data.today
        : month + '-01';
  }
  return selectedReviewDay;
}
function dailyReviewRows() {
  const day = reviewDay();
  return data.employees
    .filter(
      (employee) =>
        employee.active ||
        data.attendance.some(
          (row) => row.employee_id === employee.id && row.day === day,
        ),
    )
    .map((employee) => {
      const entry = data.attendance.find(
        (row) => row.employee_id === employee.id && row.day === day,
      );
      const status = !entry
        ? day > data.today
          ? 'future'
          : 'missing'
        : entry.status === 'leave'
          ? 'leave'
          : entry.status === 'absent'
            ? 'absent'
            : entry.open_record
              ? 'open'
              : entry.early_minutes > 0
                ? 'early'
                : 'closed';
      return { employee, entry, status };
    });
}
function recordedDuration(minutes) {
  if (minutes === null || minutes === undefined) return ui('لم يكتمل السجل');
  return Math.floor(minutes / 60) + ui(' س ') + (minutes % 60) + ui(' د');
}
function reviewDayPanel() {
  const manager = data.user.role === 'manager';
  const rows = dailyReviewRows();
  const missing = rows.filter((row) => row.status === 'missing').length;
  const open = rows.filter((row) => row.status === 'open').length;
  const early = rows.filter((row) => row.status === 'early').length;
  const labels = {
    future: ui('اليوم لم يأتِ بعد'),
    missing: ui('لم يسجل بعد'),
    leave: ui('إجازة بإذن'),
    absent: ui('غياب مسجل'),
    open: ui('لم يسجل انصرافًا'),
    early: ui('خروج مبكر'),
    closed: ui('سجل مكتمل'),
  };
  return (
    ui(
      '<section class="panel"><div class="toolbar"><div><h3>مراجعة اليوم المختار</h3>',
    ) +
    ui(
      '<p class="subtle">قائمة الموظفين النشطين حاليًا للمراجعة؛ عدم التسجيل ليس غيابًا تلقائيًا.</p></div>',
    ) +
    field(
      ui('اليوم'),
      'review_day',
      reviewDay(),
      'date',
      'id="review-day" required',
    ) +
    '</div>' +
    '<div class="review-counts">' +
    tag(missing + ui(' لم يسجل'), missing ? 'amber' : '') +
    ' ' +
    tag(open + ui(' سجل مفتوح'), open ? 'amber' : '') +
    ' ' +
    tag(early + ui(' خروج مبكر'), early ? 'red' : '') +
    '</div>' +
    table(
      [
        ui('الموظف'),
        ui('الحالة'),
        ui('الحضور / الانصراف'),
        ui('المدة المسجلة'),
        ui('خروج مبكر'),
        ...(manager ? [ui('الإجراء')] : []),
      ],
      rows.map(({ employee, entry, status }) => [
        esc(employee.name),
        tag(
          labels[status],
          ['missing', 'open'].includes(status)
            ? 'amber'
            : status === 'early' || status === 'absent'
              ? 'red'
              : status === 'closed' || status === 'leave'
                ? 'green'
                : '',
        ),
        entry
          ? esc((entry.check_in || '—') + ' / ' + (entry.check_out || '—'))
          : '—',
        entry?.status === 'present'
          ? recordedDuration(entry.duration_minutes)
          : '—',
        entry?.early_minutes ? entry.early_minutes + ui(' دقيقة') : '—',
        ...(manager ? [dailyAttendanceControl(employee.id, entry)] : []),
      ]),
    ) +
    ui(
      '<p class="hint">مدة الحضور فرق وقتي التسجيل وليست قياسًا للإنتاجية. الخروج المبكر يظهر للمراجعة ولا يضيف جزاءً أو خصمًا تلقائيًا.</p></section>',
    )
  );
}
function correctionHistory() {
  if (!data.attendance_changes.length) return '';
  const snapshot = (item) => {
    const label = {
      present: ui('حضور'),
      absent: ui('غياب'),
      leave: ui('إجازة'),
    }[item.status];
    return (
      esc(
        label +
          ' · ' +
          (item.check_in || '—') +
          ' / ' +
          (item.check_out || '—'),
      ) +
      '<br>' +
      esc(ui('جزاء ') + item.penalty_quarters / 4 + ui(' يوم')) +
      (item.note
        ? '<small class="task-description">' + esc(item.note) + '</small>'
        : '')
    );
  };
  return (
    ui('<section class="panel"><h3>سجل تصحيحات الحضور — قبل وبعد</h3>') +
    table(
      [
        ui('الموظف / اليوم'),
        ui('قبل التعديل'),
        ui('بعد التعديل'),
        ui('سبب التعديل'),
        ui('بواسطة / التوقيت'),
      ],
      data.attendance_changes.map((change) => [
        esc(employee(change.employee_id)) + '<br>' + esc(change.day),
        snapshot(change.before),
        snapshot(change.after),
        '<span class="wrap-text">' + esc(change.reason) + '</span>',
        esc(change.changed_by) +
          '<br>' +
          esc(
            new Date(change.changed_at).toLocaleString(currentLocale(), {
              timeZone: 'Africa/Cairo',
            }),
          ),
      ]),
    ) +
    '</section>'
  );
}
function attendancePage() {
  const shownRows = showAllAttendance
    ? data.attendance
    : data.attendance.slice(0, 12);
  return (
    (data.user.role === 'employee' ? selfAttendance() : '') +
    reviewDayPanel() +
    ui(
      '<section class="panel"><div class="toolbar"><div><h3>سجل حضور الشهر</h3>',
    ) +
    ui(
      '<p class="subtle">المواعيد ومصدر التسجيل والجزاء المسجّل لكل يوم.</p></div>',
    ) +
    (data.user.role === 'manager'
      ? button(ui('+ تسجيل حضور'), 'attendance-new')
      : '') +
    '</div>' +
    attendanceTable(shownRows) +
    ui('<div class="toolbar"><small>المعروض ') +
    shownRows.length +
    ui(' من أصل ') +
    data.attendance.length +
    ui(' سجل</small>') +
    (data.attendance.length > 12
      ? button(
          showAllAttendance ? ui('عرض آخر 12 سجل') : ui('عرض كل سجلات الشهر'),
          'attendance-toggle',
          '',
          'secondary small',
        )
      : '') +
    '</div></section>' +
    ui(
      '<section class="policy"><strong>قواعد الحضور والانصراف</strong><p>حتى ',
    ) +
    data.settings.grace_minutes +
    ui(' دقيقة: دون جزاء، بعدها وأقل من ') +
    data.settings.quarter_until +
    ui(': ربع يوم، حتى أقل من ') +
    data.settings.half_until +
    ui(': نصف يوم، ثم يوم. غياب بدون إذن: ') +
    data.settings.absence_days +
    ui(' أيام. الأيام غير المسجلة لا تُحتسب غيابًا تلقائيًا.</p></section>') +
    correctionHistory()
  );
}
function openDayRecord(employeeId) {
  const entry = data.attendance.find(
    (row) => row.employee_id === employeeId && row.day === reviewDay(),
  );
  openAttendance(entry?.id || 0);
  if (!entry) {
    const form = $('#modal form');
    form.elements.employee_id.value = String(employeeId);
    form.elements.day.value = reviewDay();
  }
}
function openPayrollApproval(id) {
  const payroll = data.payroll.find((row) => row.id === id);
  const checks = data.payroll_checks[String(payroll.employee_id)];
  const expected = {};
  for (const key of [
    'base_cents',
    'bonus_cents',
    'deduction_cents',
    'net_cents',
  ])
    expected[key] = payroll[key];
  const issues = checks.blockers
    .map((message) => '<p class="issue">' + esc(systemText(message)) + '</p>')
    .join('');
  const warnings = checks.warnings
    .map((message) => '<p>' + esc(systemText(message)) + '</p>')
    .join('');
  formOpen(
    ui('مراجعة واعتماد مرتب ') + employee(payroll.employee_id),
    'payroll-approval',
    id,
    '<div class="wide">' +
      table(
        [ui('الشهر'), ui('الأساسي'), ui('المكافأة'), ui('الخصم'), ui('الصافي')],
        [
          [
            esc(payroll.month),
            cash(payroll.base_cents),
            cash(payroll.bonus_cents),
            cash(payroll.deduction_cents),
            '<strong>' + cash(payroll.net_cents) + '</strong>',
          ],
        ],
      ) +
      ui('<p class="hint">عدد سجلات الشهر: ') +
      checks.records +
      ui('. لا يُفترض أن الأيام غير المسجلة حضور أو غياب.</p>') +
      (checks.missing_count ? '<p class="issue">' +
        esc(currentLanguage === 'en' ? 'Missing workdays to review: ' : 'أيام محتاجة مراجعة: ') +
        checks.missing_count + ' · ' + esc(checks.missing_days.slice(0, 5).join('، ')) +
        '</p>' : '') +
      issues +
      (warnings ? '<div class="policy">' + warnings + '</div>' : '') +
      '</div>' +
      '<input type="hidden" name="expected_snapshot" value="' +
      esc(JSON.stringify(expected)) +
      '">' +
      '<label class="wide check-label"><input type="checkbox" name="confirm_review" required>' +
      ui(
        'راجعت الحضور والإجازات والأيام غير المسجلة ومبالغ الكشف. الاعتماد يثبت المرتب ويمنع تعديل حضور الشهر.</label>',
      ) +
      (checks.warnings.length
        ? '<label class="wide check-label"><input type="checkbox" name="ack_warnings" required>' +
          ui(
            'راجعت أيام الشهر والتنبيهات، وفاهم إن اليوم غير المسجل مش غياب تلقائي.</label>',
          )
        : ''),
  );
  const submit = $('#modal [type=submit]');
  submit.textContent = checks.can_approve
    ? ui('اعتماد نهائي')
    : ui('غير جاهز للاعتماد');
  submit.disabled = !checks.can_approve;
}
function actionCards() {
  if (data.user.role !== 'manager') return '';
  const date = new Date(reviewDay() + 'T12:00:00Z');
  const weekday = date.getUTCDay();
  // Default work week: Sunday–Thursday. Don't flag weekends as missed check-ins.
  const missing = weekday === 5 || weekday === 6 ? 0 :
    dailyReviewRows().filter((row) => row.status === 'missing').length;
  const pending = data.sales.filter((row) => row.status === 'pending').length;
  const drafts = data.payroll.filter((row) => row.status === 'draft').length;
  const shortDay = new Intl.DateTimeFormat(currentLocale(), {
    day: 'numeric', month: 'short', timeZone: 'UTC',
  }).format(new Date(reviewDay() + 'T12:00:00Z'));
  const card = (count, label, actionName, glyph, subtitle = '') =>
    '<button type="button" class="action-card ' + (count ? 'has-items' : 'is-clear') +
    '" data-action="' + actionName + '">' +
    '<span class="action-card-symbol">' + svgIcon(glyph) + '</span>' +
    '<span class="action-card-copy"><span class="action-card-title">' + label + '</span>' +
    (subtitle ? '<small class="action-card-date">' + esc(subtitle) + '</small>' : '') +
    '</span><strong class="action-card-count" dir="ltr">' +
    new Intl.NumberFormat('en-US').format(count) + '</strong>' +
    '<span class="action-card-arrow">' + svgIcon('arrow') + '</span></button>';
  return (
    '<div class="action-cards">' +
    card(pending, ui('مبيعات تحتاج مراجعة'), 'review-sales', 'receipt') +
    card(missing, ui('موظفون لم يسجلوا حضورًا'), 'review-attendance', 'clock', shortDay) +
    card(drafts, ui('مسودات المرتبات'), 'review-payroll', 'wallet') +
    '</div>'
  );
}
function targetProgress(value) {
  if (value === null || value === undefined)
    return ui('<span class="subtle">غير محدد</span>');
  const filled = Math.max(0, Math.min(100, value));
  const title = percent(value);
  return (
    '<div class="target-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" ' +
    'aria-valuenow="' +
    filled +
    '" aria-valuetext="' +
    title +
    '">' +
    '<div class="progress-track"><svg viewBox="0 0 100 8" preserveAspectRatio="none" aria-hidden="true">' +
    '<rect width="100" height="8" fill="#e5ede7"/><rect width="' +
    filled +
    '" height="8" fill="' +
    (value >= 100 ? '#2c7565' : '#c29a43') +
    '"/></svg></div>' +
    '<strong>' +
    title +
    '</strong></div>'
  );
}
function navigationMarkup() {
  const entries = navigationEntries();
  const unread = data.notifications.filter((n) => !n.read_at).length;
  const item = ([key, label]) =>
    '<button type="button" data-page="' +
    key +
    '" class="' +
    (page === key ? 'active' : '') +
    '"><span class="nav-icon">' + svgIcon(icons[key]) + '</span>' +
    esc(label) +
    (key === 'notifications' && unread
      ? '<span class="nav-unread" aria-label="' +
        esc(ui('تنبيهات غير مقروءة')) + '">' + (unread > 99 ? '99+' : unread) + '</span>'
      : '') +
    '</button>';
  return (
    entries.slice(0, 6).map(item).join('') +
    '<details class="support-menu" ' +
    (entries.slice(6).some(([key]) => key === page) ? 'open' : '') +
    '><summary>' + ui('أدوات إضافية') +
    (unread ? '<span class="nav-unread" aria-label="' +
      esc(ui('تنبيهات غير مقروءة')) + '">' +
      (unread > 99 ? '99+' : unread) + '</span>' : '') +
    '</summary><div class="support-links">' +
    entries.slice(6).map(item).join('') +
    '</div></details>'
  );
}
function readableAudit(entity) {
  try {
    const value = JSON.parse(entity);
    if (value.payroll_id)
      return (
        ui('كشف #') +
        value.payroll_id +
        ' · ' +
        value.month +
        ui(' · مراجعة واعتماد')
      );
    if (value.before && value.after)
      return (
        employee(value.employee_id) + ' · ' + value.day + ' · ' + value.reason
      );
  } catch (error) {
    /* Earlier audit entries contain ordinary text. */
  }
  return entity;
}
async function reviewAction(actionName, id) {
  if (actionName === 'attendance-toggle') {
    showAllAttendance = !showAllAttendance;
    render();
    return true;
  }
  if (actionName === 'review-person') {
    openDayRecord(id);
    return true;
  }
  if (actionName === 'payroll-approve') {
    openPayrollApproval(id);
    return true;
  }
  const pages = {
    'review-sales': 'sales',
    'review-attendance': 'attendance',
    'review-payroll': 'payroll',
  };
  if (pages[actionName]) {
    page = pages[actionName];
    if (page === 'sales') {
      salesRange = 'month';
      salesStatusFilter = 'pending';
    }
    try {
      await load();
      render();
    } catch (error) {
      toast(error.message, true);
    }
    return true;
  }
  return false;
}
async function reviewSubmit(form, values) {
  if (form.dataset.kind !== 'payroll-approval') return false;
  if (busy) return true;
  const button = form.querySelector('[type=submit]');
  button.disabled = true;
  await action('payroll/approve', {
    id: Number(form.dataset.id),
    confirm_review: values.confirm_review === 'on',
    ack_warnings: values.ack_warnings === 'on',
    expected: JSON.parse(values.expected_snapshot),
  });
  if (button.isConnected)
    button.disabled =
      !data.payroll_checks[
        String(
          data.payroll.find((row) => row.id === Number(form.dataset.id))
            .employee_id,
        )
      ].can_approve;
  return true;
}
document.addEventListener('change', (event) => {
  if (event.target.id === 'review-day') {
    if (!event.target.value.startsWith(month)) {
      toast(ui('اختر يومًا في الشهر المعروض'), true);
      event.target.value = reviewDay();
      return;
    }
    selectedReviewDay = event.target.value;
    render();
  }
  if (event.target.id === 'sales-status') {
    salesStatusFilter = event.target.value;
    render();
  }
});
function attendanceEditButton(row) {
  const locked = data.payroll.some(
    (p) => p.employee_id === row.employee_id && p.status === 'approved',
  );
  return locked
    ? tag(ui('شهر معتمد'), 'green')
    : button(ui('تعديل'), 'attendance-edit', row.id, 'secondary small');
}
function dailyAttendanceControl(employeeId, entry) {
  const locked = data.payroll.some(
    (p) => p.employee_id === employeeId && p.status === 'approved',
  );
  if (locked) return tag(ui('شهر معتمد'), 'green');
  if (reviewDay() > data.today) return ui('اليوم مستقبلي');
  return button(
    entry ? ui('مراجعة / تصحيح') : ui('تسجيل الحالة'),
    'review-person',
    employeeId,
    'secondary small',
  );
}
