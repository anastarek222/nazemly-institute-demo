'use strict';
const $ = (s) => document.querySelector(s);
const esc = (v) =>
  String(v ?? '').replace(
    /[&<>"']/g,
    (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[
        c
      ],
  );
const today = () =>
  new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Africa/Cairo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
let month = today().slice(0, 7),
  page = 'overview',
  data = null,
  search = '',
  busy = false;
const names = {
  overview: ui('نظرة عامة'),
  employees: ui('الموظفون'),
  attendance: ui('الحضور والانصراف'),
  payroll: ui('المرتبات'),
  reviews: ui('تقييم الأداء'),
  reports: ui('التقارير'),
};
const icons = {
  overview: 'dashboard',
  employees: 'users',
  attendance: 'clock',
  payroll: 'wallet',
  reviews: 'star',
  reports: 'chart',
};
const cash = (n) =>
  new Intl.NumberFormat(currentLocale(), {
    style: 'currency',
    currency: 'EGP',
    maximumFractionDigits: 2,
  }).format((n || 0) / 100);
const employee = (id) =>
  data.employees.find((e) => e.id === id)?.name || ui('موظف مؤرشف');
const tag = (label, type = '') =>
  '<span class="tag ' + type + '">' + esc(systemText(label)) + '</span>';
function toast(v, error = false) {
  const t = $('#toast');
  t.textContent = systemText(v);
  t.className = 'show ' + (error ? 'error' : '');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => (t.className = ''), 5000);
}
function setBusy(value) {
  busy = value;
  document.body.classList.toggle('working', value);
  $('#app').setAttribute('aria-busy', String(value));
}
async function api(path, body) {
  const r = await fetch('/api/' + path, {
    method: body ? 'POST' : 'GET',
    credentials: 'same-origin',
    headers: body ? { 'Content-Type': 'application/json' } : {},
    body: body ? JSON.stringify(body) : undefined,
  });
  const d = await r.json();
  if (!r.ok) {
    const e = Error(systemText(d.error || ui('تعذر الاتصال')));
    e.status = r.status;
    throw e;
  }
  return d;
}
async function load() {
  data = await api('state?month=' + encodeURIComponent(month));
  if (data.demo_mode && !load.started) {
    month = data.demo_month;
    data = await api('state?month=' + encodeURIComponent(month));
  }
  load.started = true;
  lastUpdatedAt = new Date();
}
async function action(path, body) {
  if (busy) return;
  setBusy(true);
  try {
    await api(path, body);
    await load();
    $('#modal').close();
    render();
    toast(ui('تم حفظ التغييرات بنجاح'));
  } catch (e) {
    toast(e.message, true);
  } finally {
    setBusy(false);
  }
}
const stat = (title, value, sub = '', glyph = '') =>
  '<article class="stat' + (glyph ? ' stat-clean' : '') + '">' +
  '<div class="stat-heading"><span>' + title + '</span>' +
  (glyph ? '<i class="stat-glyph">' + svgIcon(glyph) + '</i>' : '') +
  '</div><strong>' + value + '</strong>' +
  (sub ? '<small>' + sub + '</small>' : '') + '</article>';
const empty = (message = ui('لا توجد سجلات لهذا الشهر')) => {
  const help = {
    employees: ui('استخدم زر إضافة موظف عشان تبدأ تسجيل الفريق.'),
    tasks: ui('المهام هتظهر هنا أول ما المدير يسندها.'),
    payroll: ui('كشف المرتب هيظهر هنا بعد تجهيز مسودة الشهر.'),
    sales: ui('المبيعات هتظهر هنا بعد تسجيل أول عملية.'),
    reports: ui('التقارير هتظهر بمجرد وجود سجلات للفترة المحددة.'),
    leaves: ui('طلبات الإجازات هتظهر هنا بعد تقديمها.'),
  }[page] || ui('البيانات هتظهر هنا أول ما تتسجل.');
  return '<div class="empty">' + svgIcon('file') +
    '<h3>' + message + '</h3><p>' + help + '</p></div>';
};
function table(headers, rows) {
  return rows.length
    ? '<div class="table-wrap"><table><thead><tr>' +
        headers.map((h) => '<th>' + h + '</th>').join('') +
        '</tr></thead><tbody>' +
        rows
          .map(
            (r) =>
              '<tr>' +
              r.map((c) => '<td dir="auto">' + c + '</td>').join('') +
              '</tr>',
          )
          .join('') +
        '</tbody></table></div>'
    : empty();
}
function button(text, act, id = '', cls = 'primary') {
  return (
    '<button type="button" class="' +
    cls +
    '" data-action="' +
    act +
    '" data-id="' +
    id +
    '">' +
    text +
    '</button>'
  );
}
function employeeOptions(selected) {
  return data.employees
    .filter((e) => e.active)
    .map(
      (e) =>
        '<option value="' +
        e.id +
        '" ' +
        (e.id == selected ? 'selected' : '') +
        '>' +
        esc(e.name) +
        '</option>',
    )
    .join('');
}
function field(label, name, value = '', type = 'text', extra = '') {
  return (
    '<label>' +
    label +
    '<input dir="auto" name="' +
    name +
    '" type="' +
    type +
    '" value="' +
    esc(value) +
    '" ' +
    extra +
    '></label>'
  );
}
function selectField(label, name, options) {
  return (
    '<label>' +
    label +
    '<select name="' +
    name +
    '">' +
    options +
    '</select></label>'
  );
}
function formOpen(title, kind, id, content) {
  $('#modal').innerHTML =
    '<form data-kind="' +
    kind +
    '" data-id="' +
    (id || '') +
    ui('"><header><div><small>نظملي / إدارة الموارد البشرية</small><h2>') +
    esc(title) +
    '</h2></div>' +
    languageButton() +
    ui(
      '<button type="button" data-action="close" class="icon" aria-label="إغلاق">×</button></header><div class="form-grid">',
    ) +
    content +
    ui(
      '</div><footer><button type="button" class="secondary" data-action="close">إلغاء</button><button type="submit" class="primary">حفظ البيانات</button></footer></form>',
    );
  $('#modal').showModal();
}
// Pages defined in people.js; shared UI and event handlers live here.
function securityBanner() {
  if (!data.security_setup_required) return '';
  return '<section class="setup-banner" role="alert"><span class="setup-badge">' +
    svgIcon('alert') + '</span><div><strong>' + ui('أمّن حساب المدير') +
    '</strong><p>' + ui('غيّر كلمة المرور الأولية قبل إضافة أي بيانات. بعد الحفظ هتدخل بكلمتك الجديدة.') +
    '</p></div>' +
    button(ui('تغيير كلمة المرور'), 'password-open', '', 'primary') +
    '</section>';
}
function render() {
  document.body.classList.remove('mobile-menu-open');
  const manager = data.user.role === 'manager';
  $('#app').innerHTML =
    ui(
      '<aside class="sidebar" id="main-navigation" aria-label="القائمة الرئيسية"><div class="sidebar-head"><a class="brand" href="/"><span class="brand-mark">ن</span><div>',
    ) +
    esc(data.settings.company_name) +
    ui(
      '<small>إدارة الموظفين</small></div></a><button type="button" class="mobile-nav-close" data-action="menu-close" aria-label="إغلاق القائمة">×</button></div><div class="nav-label">مساحة العمل</div><nav>',
    ) +
    navigationMarkup() +
    '</nav></aside><button type="button" class="nav-backdrop" data-action="menu-close" aria-label="إغلاق القائمة" tabindex="-1"></button><div class="workspace">' +
    ui('<header class="topbar"><div class="topbar-heading"><button type="button" class="mobile-menu-btn" data-action="menu-toggle" aria-controls="main-navigation" aria-expanded="false" aria-label="فتح القائمة">☰</button><div class="heading-copy"><small>مساحة ') +
    (manager ? ui('المدير') : ui('الموظف')) +
    '</small><h1>' +
    names[page] +
    ui('</h1><small class="last-updated">آخر تحديث: ') +
    esc(
      lastUpdatedAt
        ? lastUpdatedAt.toLocaleTimeString(currentLocale(), {
            timeZone: 'Africa/Cairo',
          })
        : '—',
    ) +
    ui(
      '</small></div></div><label class="month-label"><span class="month-caption">الشهر</span><input id="month" type="month" value="',
    ) +
    month +
    ui('" aria-label="الشهر"></label><div class="top-actions"><div class="top-left-tools"><button class="refresh-icon" type="button" data-action="refresh" aria-label="تحديث" title="تحديث">↻</button>') +
    languageButton() +
    '<div class="header-divider" aria-hidden="true"></div></div><details class="account-menu"><summary aria-label="الحساب" title="الحساب"><span class="avatar">' +
    (manager ? ui('م') : ui('أ')) +
    '</span><span class="account-name">' + esc(data.user.username) +
    '</span><span aria-hidden="true">⌄</span></summary><div class="account-dropdown"><strong>' +
    esc(data.user.username) + '</strong><small>' +
    (manager ? ui('مدير النظام') : ui('حساب موظف')) +
    '</small><button type="button" data-action="password-open">' + ui('كلمة المرور') +
    '</button><button type="button" data-action="logout">' + ui('خروج') +
    '</button></div></details></div></header><main>' + securityBanner() +
    {
      overview,
      employees: employeesPage,
      attendance: attendancePage,
      payroll: payrollPage,
      reviews: reviewsPage,
      reports: reportsPage,
      profile: profilePage,
      leaves: leavesPage,
      tasks: tasksPage,
      notifications: notificationsPage,
      settings: settingsPage,
      sales: salesPage,
    }[page]() +
    '</main><datalist id="department-options">' +
    data.settings.departments
      .map((d) => '<option value="' + esc(d) + '"></option>')
      .join('') +
    ui(
      '</datalist><footer class="app-footer">نظملي <span>الحضور · المرتبات · الأداء</span></footer></div>',
    );
  showOnboarding();
  assistantSync(data);
}
function login() {
  load.started = false;
  const welcome = $('#welcome-dialog');
  if (welcome.open) welcome.close();
  data = null;
  assistantReset();
  $('#app').innerHTML =
    ui(
      '<main class="login"><section class="login-story"><span class="brand-mark">ن</span><span class="eyebrow">نظملي / إدارة الموظفين</span><h1>نظملي</h1><p>الحضور والمهام والمبيعات والمرتبات في مكان واحد.</p><div class="login-features"><span>بيانات الموظفين</span><span>الحضور والانصراف</span><span>التارجت والمرتبات</span></div></section><section class="login-side"><form id="login-form">',
    ) +
    '<div class="login-tools"><a class="login-back" href="/">' +
    ui('الرجوع للرئيسية') + '</a>' + languageButton() + '</div>' +
    ui(
      '<span class="eyebrow dark">حسابك في نظملي</span><h2>تسجيل الدخول</h2><p class="subtle">ادخل اسم المستخدم وكلمة المرور.</p>',
    ) +
    field(
      ui('اسم المستخدم'),
      'username',
      '',
      'text',
      'required autocomplete="username"',
    ) +
    field(
      ui('كلمة المرور'),
      'password',
      '',
      'password',
      'required autocomplete="current-password"',
    ) +
    ui(
      '<p id="login-error" role="alert"></p><button class="primary" type="submit">دخول مساحة العمل</button></form></section></main>',
    );
}
document.addEventListener('click', async (e) => {
  const n = e.target.closest('[data-page],[data-action]');
  if (!n) return;
  if (busy) return;
  if (n.dataset.action === 'menu-toggle') {
    const opening = !document.body.classList.contains('mobile-menu-open');
    document.body.classList.toggle('mobile-menu-open', opening);
    const toggle = $('.mobile-menu-btn');
    if (toggle) toggle.setAttribute('aria-expanded', String(opening));
    return;
  }
  if (n.dataset.action === 'menu-close') {
    document.body.classList.remove('mobile-menu-open');
    const toggle = $('.mobile-menu-btn');
    if (toggle) toggle.setAttribute('aria-expanded', 'false');
    return;
  }
  if (n.dataset.action === 'language') {
    await switchLanguage();
    return;
  }
  if (n.dataset.action === 'onboarding-ack') {
    const button = n;
    button.disabled = true;
    try {
      await api('onboarding/ack', {});
      data.onboarding_pending = false;
      $('#welcome-dialog').close();
    } catch (error) {
      toast(error.message, true);
      button.disabled = false;
    }
    return;
  }
  if (n.dataset.page) {
    page = n.dataset.page;
    search = '';
    setBusy(true);
    try {
      await load();
      render();
    } catch (error) {
      if (error.status === 401) login();
      else toast(error.message, true);
    } finally {
      setBusy(false);
    }
    return;
  }
  const id = Number(n.dataset.id),
    a = n.dataset.action;
  if (a === 'current-month' || a === 'go-tasks' || a === 'go-sales') {
    if (a === 'current-month') month = data.today.slice(0, 7);
    else page = a === 'go-tasks' ? 'tasks' : 'sales';
    setBusy(true);
    try {
      await load();
      render();
    } catch (error) {
      if (error.status === 401) login();
      else toast(error.message, true);
    } finally {
      setBusy(false);
    }
    return;
  }
  if (await reviewAction(a, id)) return;
  if (await salesAction(a, id)) return;
  if (await featureAction(a, id)) return;
  if (a === 'refresh') {
    try {
      await load();
      render();
    } catch (error) {
      if (error.status === 401) login();
      else toast(error.message, true);
    }
    return;
  }
  if (a === 'close') return $('#modal').close();
  if (a === 'logout') {
    await api('logout', {});
    return login();
  }
  if (a === 'employee-new' || a === 'employee-edit') return openEmployee(id);
  if (a === 'attendance-new' || a === 'attendance-edit')
    return openAttendance(id);
  if (a === 'review-new' || a === 'review-edit') return openReview(id);
  if (a === 'employee-archive') {
    if (confirm(ui('أرشفة الموظف مع الاحتفاظ بسجلاته السابقة؟')))
      await action('employees/archive', { id });
    return;
  }
  if (a === 'payroll-generate') return action('payroll/generate', { month });
  if (a === 'payroll-bonus') return openBonus(id);
  if (a === 'print') return window.print();
  if (a === 'export') {
    const headers = reportHeaders();
    const rows = reportRows().map((r) =>
      r.map((v) =>
        String(v)
          .replace(/&amp;/g, '&')
          .replace(/&lt;/g, '<')
          .replace(/&gt;/g, '>')
          .replace(/&#39;/g, "'")
          .replace(/&quot;/g, '"'),
      ),
    );
    const csv =
      '\ufeff' +
      [headers, ...rows]
        .map((r) =>
          r
            .map(
              (v) =>
                '"' +
                (/^[=+@\-\t\r]/.test(String(v)) ? "'" : '') +
                String(v).replace(/"/g, '""') +
                '"',
            )
            .join(','),
        )
        .join('\r\n');
    const url = URL.createObjectURL(
      new Blob([csv], { type: 'text/csv;charset=utf-8' }),
    );
    const link = document.createElement('a');
    link.href = url;
    link.download = 'HR-' + month + '.csv';
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && document.body.classList.contains('mobile-menu-open')) {
    document.body.classList.remove('mobile-menu-open');
    const toggle = $('.mobile-menu-btn');
    if (toggle) {
      toggle.setAttribute('aria-expanded', 'false');
      toggle.focus();
    }
  }
});
document.addEventListener('input', (e) => {
  if (e.target.id === 'search') {
    search = e.target.value;
    $('#employees-table').innerHTML = employeesTable(
      data.employees.filter((e) =>
        (e.name + ' ' + e.department + ' ' + e.title)
          .toLowerCase()
          .includes(search.toLowerCase()),
      ),
    );
  }
});
document.addEventListener('change', async (e) => {
  if (e.target.id === 'month') {
    const prev = month;
    const next = e.target.value;
    if (!next) {
      e.target.value = prev;
      return;
    }
    month = next;
    try {
      await load();
      render();
    } catch (err) {
      month = prev;
      e.target.value = prev;
      toast(err.message, true);
    }
  }
  if (e.target.name === 'status') attendanceFields();
});
document.addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = e.target,
    v = Object.fromEntries(new FormData(f));
  if (f.id === 'login-form') {
    const b = f.querySelector('button[type=submit]');
    b.disabled = true;
    try {
      await api('login', v);
      await load();
      page = 'overview';
      render();
    } catch (err) {
      $('#login-error').textContent = err.message;
    } finally {
      b.disabled = false;
    }
    return;
  }
  if (await reviewSubmit(f, v)) return;
  if (await salesSubmit(f, v)) return;
  if (await featureSubmit(f, v)) return;
  if (busy) return;
  const id = Number(f.dataset.id);
  for (const k of [
    'employee_id',
    'quality',
    'productivity',
    'teamwork',
    'expected_revision',
  ])
    if (k in v) v[k] = Number(v[k]);
  const path = {
    employee: 'employees',
    attendance: 'attendance',
    review: 'reviews',
    bonus: 'payroll/bonus',
  }[f.dataset.kind];
  if (f.dataset.kind === 'employee' && id) v.id = id;
  if (f.dataset.kind === 'bonus') v.id = id;
  f.querySelector('button[type=submit]').disabled = true;
  await action(path, v);
  if (f.isConnected) f.querySelector('button[type=submit]').disabled = false;
});
document.addEventListener('DOMContentLoaded', async () => {
  try {
    await load();
    render();
  } catch (e) {
    if (e.status === 401) login();
    else {
      $('#app').innerHTML = ui(
        '<div class="empty"><h2>تعذر تحميل النظام</h2><p>راجع تشغيل الخادم ثم أعد تحميل الصفحة.</p></div>',
      );
    }
  }
});
function openBonus(id) {
  const p = data.payroll.find((p) => p.id === id);
  return formOpen(
    ui('مكافأة ') + employee(p.employee_id),
    'bonus',
    id,
    field(
      ui('قيمة المكافأة — جنيه'),
      'bonus',
      p.bonus_cents / 100,
      'number',
      'required min="0" max="10000000" step=".01"',
    ),
  );
}
