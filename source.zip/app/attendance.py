"""Attendance records, corrections and payroll review checks."""
import json
import datetime as dt
from common import (
    audit, active_employee, cairo_today, clock, day_value, editable_month,
    integer, text,
)

MONEY_FIELDS = ('base_cents', 'bonus_cents', 'deduction_cents', 'net_cents')
INPUT_FIELDS = (
    'status', 'scheduled', 'scheduled_end', 'check_in', 'check_out', 'note',
)
SNAPSHOT_FIELDS = INPUT_FIELDS + (
    'late_minutes', 'penalty_quarters', 'source', 'revision',
    'started_at_utc', 'ended_at_utc',
)


def migrate(connection, settings):
    columns = {row[1] for row in connection.execute('PRAGMA table_info(attendance)')}
    if 'scheduled_end' not in columns:
        connection.execute('ALTER TABLE attendance ADD COLUMN scheduled_end TEXT')
    if 'revision' not in columns:
        connection.execute(
            'ALTER TABLE attendance ADD COLUMN revision INTEGER NOT NULL DEFAULT 0'
        )
    connection.execute(
        'UPDATE attendance SET scheduled_end=? WHERE scheduled_end IS NULL',
        (settings['work_end'],),
    )


def timing(row):
    """Recorded duration, not a measure of productive work."""
    result = dict(row)
    result['duration_minutes'] = None
    result['early_minutes'] = 0
    result['open_record'] = False
    if row['status'] == 'present':
        result['open_record'] = not row['check_out']
        if row['check_in'] and row['check_out']:
            result['duration_minutes'] = max(
                0, clock(row['check_out']) - clock(row['check_in'])
            )
            if row['scheduled_end']:
                result['early_minutes'] = max(
                    0, clock(row['scheduled_end']) - clock(row['check_out'])
                )
    return result


def manual_record(connection, user, body, settings, policy):
    employee_id = integer(body.get('employee_id'), 1, 1000000)
    active_employee(connection, employee_id)
    day = day_value(body.get('day'))
    editable_month(connection, employee_id, day[:7])
    if day > cairo_today().isoformat():
        raise ValueError('لا يمكن تسجيل حضور أو غياب بتاريخ مستقبلي')

    previous = connection.execute(
        'SELECT * FROM attendance WHERE employee_id=? AND day=?',
        (employee_id, day),
    ).fetchone()
    status = body.get('status')
    if status not in ('present', 'absent', 'leave'):
        raise ValueError('الحالة غير صحيحة')
    approved_leave = connection.execute(
        "SELECT 1 FROM leave_requests WHERE employee_id=? AND status='approved' "
        'AND start_day<=? AND end_day>=?',
        (employee_id, day, day),
    ).fetchone()
    if approved_leave and status != 'leave':
        raise ValueError('التاريخ ضمن إجازة معتمدة')

    scheduled = text(body.get('scheduled', settings['work_start']))
    scheduled_end = text(body.get('scheduled_end') or (
        (previous['scheduled_end'] or settings['work_end']) if previous else settings['work_end']
    ))
    if clock(scheduled_end) <= clock(scheduled):
        raise ValueError('نهاية الدوام يجب أن تكون بعد بدايته في نفس اليوم')

    check_in = body.get('check_in') if status == 'present' else None
    check_out = (body.get('check_out') or None) if status == 'present' else None
    late = max(0, clock(check_in) - clock(scheduled)) if status == 'present' else 0
    if check_out and clock(check_out) < clock(check_in):
        raise ValueError('الانصراف يجب أن يكون بعد الحضور في نفس اليوم')
    quarters = policy(connection, late) if status == 'present' else (
        4 * settings['absence_days'] if status == 'absent' else 0
    )
    new = {
        'status': status, 'scheduled': scheduled, 'scheduled_end': scheduled_end,
        'check_in': check_in, 'check_out': check_out,
        'note': text(body.get('note', ''), 500, False),
        'late_minutes': late, 'penalty_quarters': quarters, 'source': 'manual',
    }
    if previous:
        if all(new[key] == previous[key] for key in INPUT_FIELDS):
            return  # An identical resubmission does not modify history or its source.
        reason = text(body.get('change_reason', ''), 500)
        expected_revision = integer(body.get('expected_revision'), 0, 1000000)
        if expected_revision != previous['revision']:
            raise ValueError('السجل اتعدل بالفعل؛ حدّث الصفحة قبل الحفظ')
        changed = connection.execute(
            'UPDATE attendance SET status=?,scheduled=?,scheduled_end=?,check_in=?,'
            'check_out=?,note=?,late_minutes=?,penalty_quarters=?,source=?,'
            'revision=revision+1 WHERE id=? AND revision=?',
            tuple(new[key] for key in (
                'status', 'scheduled', 'scheduled_end', 'check_in', 'check_out',
                'note', 'late_minutes', 'penalty_quarters', 'source',
            )) + (previous['id'], expected_revision),
        ).rowcount
        if changed != 1:
            raise ValueError('السجل اتعدل بالفعل؛ حدّث الصفحة قبل الحفظ')
        current = connection.execute(
            'SELECT * FROM attendance WHERE id=?', (previous['id'],)
        ).fetchone()
        evidence = {
            'employee_id': employee_id, 'day': day, 'reason': reason,
            'before': {key: previous[key] for key in SNAPSHOT_FIELDS},
            'after': {key: current[key] for key in SNAPSHOT_FIELDS},
        }
        audit(connection, user, 'تعديل حضور', json.dumps(evidence, ensure_ascii=False))
    else:
        connection.execute(
            'INSERT INTO attendance(employee_id,day,status,scheduled,scheduled_end,'
            'check_in,check_out,note,late_minutes,penalty_quarters,source) '
            "VALUES(?,?,?,?,?,?,?,?,?,?,'manual')",
            (employee_id, day) + tuple(new[key] for key in (
                'status', 'scheduled', 'scheduled_end', 'check_in', 'check_out',
                'note', 'late_minutes', 'penalty_quarters',
            )),
        )
        audit(connection, user, 'حفظ حضور', f'{employee_id} / {day}')


def month_checks(connection, employee_id, month):
    rows = connection.execute(
        'SELECT * FROM attendance WHERE employee_id=? AND substr(day,1,7)=?',
        (employee_id, month),
    ).fetchall()
    records = [timing(row) for row in rows]
    open_count = sum(row['open_record'] for row in records)
    early_count = sum(row['early_minutes'] > 0 for row in records)
    # Sun–Thu is the current default company schedule. Unrecorded days are
    # review items, NEVER automatic absences or automatic salary deductions.
    first = dt.date.fromisoformat(month + '-01')
    end = (first.replace(day=28) + dt.timedelta(days=4)).replace(day=1)
    recorded = {r['day'] for r in rows}
    missing_days = []
    current_day = first
    while current_day < end and current_day <= cairo_today():
        if current_day.weekday() not in (4, 5) and current_day.isoformat() not in recorded:
            missing_days.append(current_day.isoformat())
        current_day += dt.timedelta(days=1)
    pending_leaves = connection.execute(
        "SELECT COUNT(*) FROM leave_requests WHERE employee_id=? AND status='pending' "
        'AND substr(start_day,1,7)<=? AND substr(end_day,1,7)>=?',
        (employee_id, month, month),
    ).fetchone()[0]
    blockers = []
    warnings = []
    if month >= cairo_today().strftime('%Y-%m'):
        blockers.append('الشهر لم ينتهِ بعد؛ المتاح الآن مسودة فقط')
    if not rows:
        blockers.append('لا توجد سجلات حضور أو غياب أو إجازة للشهر')
    if open_count:
        blockers.append(f'يوجد {open_count} سجل حضور دون انصراف')
    if pending_leaves:
        blockers.append(f'يوجد {pending_leaves} طلب إجازة معلق يخص الشهر')
    if missing_days and rows:
        sample = '، '.join(missing_days[:4])
        warnings.append(f'فيه {len(missing_days)} يوم عمل (الأحد للخميس) من غير تسجيل؛ راجعهم قبل الاعتماد: {sample}. الأيام دي مش غياب تلقائي.')
    if early_count:
        warnings.append(
            f'يوجد {early_count} سجل خروج مبكر للمراجعة؛ لا يضيف خصمًا تلقائيًا'
        )
    return {
        'records': len(rows), 'open_records': open_count, 'early_records': early_count,
        'missing_days': missing_days, 'missing_count': len(missing_days),
        'blockers': blockers, 'warnings': warnings, 'can_approve': not blockers,
    }


def approval_check(connection, payroll, body):
    checks = month_checks(connection, payroll['employee_id'], payroll['month'])
    if checks['blockers']:
        raise ValueError(' — '.join(checks['blockers']))
    if body.get('confirm_review') is not True:
        raise ValueError('أكّد مراجعة سجلات الشهر قبل اعتماد المرتب')
    if checks['warnings'] and body.get('ack_warnings') is not True:
        raise ValueError('راجع تنبيهات الشهر وأكّد الاطلاع عليها')
    expected = {key: payroll[key] for key in MONEY_FIELDS}
    if body.get('expected') != expected:
        raise ValueError('مبالغ الكشف تغيرت؛ حدّث الصفحة وراجعها من جديد')
    return checks


def extra_state(connection, user, month):
    manager = user['role'] == 'manager'
    employee_id = user['employee_id']
    people = connection.execute(
        'SELECT id FROM employees' + ('' if manager else ' WHERE id=?'),
        () if manager else (employee_id,),
    ).fetchall()
    checks = {
        str(row['id']): month_checks(connection, row['id'], month)
        for row in people
    }
    changes = []
    for row in connection.execute(
        "SELECT a.entity,a.created_at,u.username FROM audit a "
        "JOIN users u ON u.id=a.user_id WHERE a.action='تعديل حضور' "
        'ORDER BY a.id DESC'
    ):
        item = json.loads(row['entity'])
        if item['day'][:7] != month:
            continue
        if not manager and item['employee_id'] != employee_id:
            continue
        item['changed_at'] = row['created_at']
        item['changed_by'] = row['username']
        changes.append(item)
        if len(changes) == 100:
            break
    return {'payroll_checks': checks, 'attendance_changes': changes}
