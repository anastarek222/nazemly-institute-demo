"""Local demo reset, intentionally disabled for normal and shared installations."""
import json
import os

import hr_features
from storage import DB_PATH
from common import text, password_ok


def allowed():
    return (
        os.environ.get("HR_DEMO_MODE") == "1"
        and os.environ.get("HR_SHARE_MODE") != "1"
        and DB_PATH.name == "demo.sqlite3"
    )


def reset(connection, user, body):
    if not allowed() or user["role"] != "manager":
        return {"error": "إعادة ضبط العرض متاحة لمدير نسخة Demo المحلية فقط"}, 403
    if body.get("confirm") != "RESET":
        raise ValueError("لازم تأكد إعادة ضبط نسخة العرض")
    password = text(body.get("password"), 200)
    if not password_ok(password, user["password_hash"]):
        raise ValueError("كلمة مرور المدير غير صحيحة")
    snapshot = DB_PATH.parent / "demo-initial.json"
    if not snapshot.is_file():
        raise ValueError("نسخة البداية غير موجودة؛ راجع ملفات Demo")
    backup = json.loads(snapshot.read_text(encoding="utf-8"))
    # If the local manager changed credentials, preserve those credentials.
    for account in backup["tables"]["users"]:
        if account["role"] == "manager" and account["username"] == user["username"]:
            account["password_hash"] = user["password_hash"]
    # Reuse the existing validated, transactional restore path and backup protection.
    return hr_features.route(connection, user, "/api/backup/restore", {
        "password": password, "backup": backup,
    })
