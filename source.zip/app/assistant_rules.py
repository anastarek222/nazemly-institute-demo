"""Read-only employee and manager assistant replies."""
import datetime as dt
import re
import hr_features
from assistant_utils import (normalized, includes, money, period_for_question,
                             salary_penalty_cents, colleague_pay_request)

def answer(connection, user, state, body):
    question = body.get("question", "")
    if not isinstance(question, str) or not 1 <= len(question.strip()) <= 180:
        raise ValueError("اكتب سؤالًا مختصرًا من 1 إلى 180 حرفًا")
    q = normalized(question)
    english = body.get("language") == "en"
    manager = user["role"] == "manager"
    month = state["month"]
    _, day = period_for_question(question, month)
    settings = state["settings"]
    emp = state["employees"][0] if not manager and state["employees"] else None

    def respond(ar, en, page="overview", intent="help"):
        result = {
            "answer": en if english else ar,
            "page": page, "intent": intent, "month": month,
        }
        if day:
            result["day"] = day
        return result

    # Only imperatives (not questions about approvals) are treated as write requests.
    imperative = re.match(
        r"^(?:اعتمد|احذف|امسح|وافق|عدل|سجل|زود|غير|approve|delete|update|change|create)\b",
        q,
    )
    if imperative:
        return respond(
            "المساعد للقراءة والإرشاد بس. أي تعديل أو اعتماد بيتم من الصفحة المخصصة وبصلاحياتها.",
            "This assistant is read-only. Use the appropriate page and permissions to make changes.",
            intent="read_only",
        )

    salary_words = includes(q, "مرتب", "مرتبات", "راتب", "راتبي", "القبض", "قبض", "قبضي",
                            "salary", "payroll", "payslip", "خصم", "خصومات",
                            "خصمي", "deduction", "net pay")
    if not manager and colleague_pay_request(connection, user, q, emp):
        return respond(
            "بيانات المرتبات خاصة بكل موظف. أقدر أساعدك في مرتبك وخصوماتك أنت بس."
            if salary_words else
            "بيانات زمايلك خاصة بيهم. أقدر أساعدك في بياناتك أنت بس.",
            "Payroll details are private. I can show only your own pay and deductions."
            if salary_words else
            "Colleagues' records are private. I can show only your own information.",
            "payroll" if salary_words else "overview", "privacy",
        )

    if includes(q, "ازاي اشتغل", "استخدم النظام", "what can", "مساعد", "تقدر تعمل",
                "help", "ممكن اسال", "hello", "اهلا", "هاي", "مرحبا"):
        return respond(
            ("أقدر أساعدك بالمبيعات اللي مستنية مراجعة، ومسودات المرتبات، "
             "ومهام الفريق والحضور وقواعد التأخير.") if manager else
            "اسألني عن مهامك والتارجت والحضور، أو مرتبك وخصوماتك والإجازات.",
            ("Ask about pending sales, payroll drafts, team tasks and attendance.") if manager else
            "Ask about your tasks, targets, attendance, salary, deductions and leave.",
        )

    minute_match = re.search(r"(?<!\d)(\d{1,3})\s*(?:دقيقه|دقايق|minutes?|mins?)", q)
    late_words = includes(q, "تاخير", "اتاخرت", "تاخرت", "متاخر", "late")
    policy_words = includes(
        q, "قواعد التاخير", "سياسه التاخير", "وقت السماح", "grace period",
        "late policy", "مواعيد العمل", "مواعيد الشغل", "مواعيد الدوام",
        "وقت الدوام", "ساعات العمل", "دوام", "work hours",
        "working hours", "الغياب بدون اذن", "غياب من غير اذن", "غياب بدون اذن",
        "لو اتاخرت", "لو تاخرت", "شغالين من كام",
    )
    if (late_words and minute_match) or policy_words:
        grace = settings["grace_minutes"]
        quarter = settings["quarter_until"]
        half = settings["half_until"]
        if minute_match and late_words:
            minutes = int(minute_match.group(1))
            quarters = hr_features.policy(connection, minutes)
            penalty_ar = {0: "مفيش خصم", 1: "الجزاء ربع يوم",
                          2: "الجزاء نصف يوم", 4: "الجزاء يوم كامل"}[quarters]
            penalty_en = {0: "no deduction", 1: "a quarter-day deduction",
                          2: "a half-day deduction", 4: "a full-day deduction"}[quarters]
            estimate_ar = estimate_en = ""
            if emp and quarters:
                cents = salary_penalty_cents(
                    emp["salary_cents"], quarters, settings["payroll_divisor"]
                )
                estimate_ar = f" على مرتبك الحالي، ده يعادل حوالي {money(cents, False)}."
                estimate_en = f" On your current base salary, that's around {money(cents, True)}."
            return respond(
                f"لو اتأخرت {minutes} دقيقة: {penalty_ar}.{estimate_ar} "
                "ده مثال توضيحي؛ الخصم الفعلي بيتحسب من سجل الحضور.",
                f"For {minutes} minutes late: {penalty_en}.{estimate_en} "
                "This is an estimate; actual deductions use attendance records.",
                "attendance", "policy",
            )
        return respond(
            f"الشغل من {settings['work_start']} لـ {settings['work_end']}. "
            f"السماح لحد {grace} دقيقة، وبعدها لأقل من {quarter} ربع يوم، "
            f"من {quarter} لأقل من {half} نصف يوم، ومن {half} فأكتر يوم كامل. "
            f"الغياب بدون إذن جزاؤه {settings['absence_days']} أيام.",
            f"Work hours: {settings['work_start']}–{settings['work_end']}; "
            f"{grace} minutes grace, then quarter-day below {quarter}, "
            f"half-day below {half}, and full-day from {half}. "
            f"Unexcused absence: {settings['absence_days']} penalty days.",
            "attendance", "policy",
        )

    if includes(q, "مهام", "مهم", "tasks", "task", "to do", "شغلي", "اللي عليا"):
        rows = state["tasks"]
        active = [t for t in rows if t["status"] != "done"]
        if day:
            active = [t for t in active if t["due_day"] == day]
            scope_ar = f"يوم {day}"
            scope_en = f"on {day}"
        else:
            scope_ar = "حاليًا"
            scope_en = "right now"
        if not active:
            return respond(
                f"مفيش مهام مفتوحة {'للفريق' if manager else 'عندك'} {scope_ar}.",
                f"There are no open {'team' if manager else 'personal'} tasks {scope_en}.",
                "tasks", "tasks",
            )
        if manager:
            return respond(
                f"فيه {len(active)} مهمة مش مكتملة للفريق {scope_ar}. افتح المهام لمتابعة الموظفين.",
                f"The team has {len(active)} unfinished tasks {scope_en}. Open Tasks for details.",
                "tasks", "tasks",
            )
        listing_ar = "، ".join(f"{t['title']} ({t['due_day']})" for t in active[:3])
        listing_en = " • ".join(f"{t['title']} ({t['due_day']})" for t in active[:3])
        more_ar = f" وفيه {len(active)-3} كمان." if len(active) > 3 else ""
        more_en = f" Plus {len(active)-3} more." if len(active) > 3 else ""
        return respond(
            f"عندك {len(active)} مهمة مش مكتملة {scope_ar}: {listing_ar}.{more_ar}",
            f"You have {len(active)} unfinished tasks {scope_en}: {listing_en}.{more_en}",
            "tasks", "tasks",
        )

    sales_words = includes(q, "تارجت", "هدف", "اهداف", "sales", "target", "achiev",
                           "انجاز", "مبيعات", "بيع")
    if sales_words:
        sales = state["sales"]
        if day:
            sales = [s for s in sales if s["day"] == day]
        if includes(q, "مراجعه", "معلقه", "انتظار", "pending", "review"):
            pending = sum(s["status"] == "pending" for s in sales)
            return respond(
                f"فيه {pending} عملية بيع مستنية مراجعة {'يوم '+day if day else 'في '+month}.",
                f"{pending} sales await review {'on '+day if day else 'in '+month}.",
                "sales", "sales",
            )
        if day:
            targets = [t for t in state["targets"] if t["day"] == day]
            target = sum(t["amount_cents"] for t in targets)
            approved = sum(
                s["amount_cents"] for s in sales if s["status"] == "approved"
            )
            target_people = {t["employee_id"] for t in targets}
            matched = sum(s["amount_cents"] for s in sales
                          if s["status"] == "approved" and s["employee_id"] in target_people)
            scope_ar, scope_en = f"يوم {day}", f"on {day}"
        else:
            rows = state["sales_summary"]
            target = sum(t["target_cents"] for t in rows)
            matched = sum(t["matched_cents"] for t in rows)
            scope_ar, scope_en = f"شهر {month}", f"for {month}"
        if target <= 0:
            return respond(
                f"مفيش تارجت متسجل {'للفريق' if manager else 'ليك'} {scope_ar}.",
                f"No {'team' if manager else 'personal'} target is set {scope_en}.",
                "sales", "target",
            )
        remain = max(0, target-matched)
        pct = round(100 * matched/target, 1)
        return respond(
            f"تارجت {'الفريق' if manager else 'بتاعك'} {scope_ar} هو {money(target, False)}. "
            f"المبيعات المعتمدة المحسوبة {money(matched, False)}، والإنجاز {pct}%. "
            + (f"فاضل {money(remain, False)}." if remain else "التارجت متحقق!"),
            f"{'Team' if manager else 'Your'} target {scope_en} is {money(target, True)}. "
            f"Counted approved sales: {money(matched, True)}, achievement {pct}%. "
            + (f"Remaining: {money(remain, True)}." if remain else "Target reached!"),
            "sales", "target",
        )

    if salary_words:
        payroll = state["payroll"]
        if manager:
            drafts = sum(p["status"] == "draft" for p in payroll)
            approved = sum(p["status"] == "approved" for p in payroll)
            return respond(
                f"في {month} عندك {drafts} كشف مرتب مسودة و{approved} كشف معتمد. "
                "افتح المرتبات للتفاصيل.",
                f"For {month}, there are {drafts} draft and {approved} approved payslips. "
                "Open Payroll for details.",
                "payroll", "payroll",
            )
        if not payroll:
            return respond(
                f"لسه مفيش كشف مرتب متجهز ليك لشهر {month}. "
                "افتح المرتبات عشان تتابع حالة كشفك.",
                f"No payslip is prepared for {month} yet. Open Payroll to check its status.",
                "payroll", "payroll",
            )
        p = payroll[0]
        approved = p["status"] == "approved"
        if includes(q, "اعتمدوا", "اتعمد", "معتمد", "اتوافق", "اتصرف",
                    "وافقوا", "حاله", "لسه", "approved", "status", "ready"):
            return respond(
                f"كشف مرتبك لشهر {month} {'معتمد' if approved else 'لسه مسودة ومش معتمد'}."
                + (f" الصافي {money(p['net_cents'], False)}." if approved else
                   " ده مش معناه إنه اتصرف فعليًا."),
                f"Your {month} payslip is {'approved' if approved else 'still a draft and not approved'}."
                + (f" Net: {money(p['net_cents'], True)}." if approved else
                   " This does not mean that money was paid."),
                "payroll", "payroll",
            )
        if includes(q, "خصم", "خصومات", "deduction"):
            return respond(
                f"خصومات مرتبك المسجلة لشهر {month}: {money(p['deduction_cents'], False)}."
                + (" الكشف لسه مسودة." if not approved else " الكشف معتمد."),
                f"Payroll deductions for {month}: {money(p['deduction_cents'], True)}."
                + (" This is a draft." if not approved else " The payslip is approved."),
                "payroll", "payroll",
            )
        return respond(
            f"مرتبك لشهر {month} ({'معتمد' if approved else 'مسودة مش معتمدة'}): "
            f"الأساسي {money(p['base_cents'], False)}، "
            f"الخصومات {money(p['deduction_cents'], False)}، "
            f"المكافآت {money(p['bonus_cents'], False)}، "
            f"والصافي {money(p['net_cents'], False)}.",
            f"Your {month} payslip is {'approved' if approved else 'a draft, not approved'}: "
            f"base {money(p['base_cents'], True)}, "
            f"deductions {money(p['deduction_cents'], True)}, "
            f"bonus {money(p['bonus_cents'], True)}, "
            f"net {money(p['net_cents'], True)}.",
            "payroll", "payroll",
        )

    if includes(q, "حضور", "انصراف", "تاخيري", "تاخر", "غياب", "غيابي",
                "attendance", "clock in", "clock out", "absen", "check in",
                "check out", "دوامي", "present"):
        rows = state["attendance"]
        if day:
            rows = [r for r in rows if r["day"] == day]
        present = sum(r["status"] == "present" for r in rows)
        absent = sum(r["status"] == "absent" for r in rows)
        late = sum(r.get("late_minutes", 0) > 0 for r in rows)
        if manager:
            scope_ar = f"يوم {day}" if day else f"شهر {month}"
            scope_en = f"on {day}" if day else f"for {month}"
            return respond(
                f"{scope_ar}: {present} حضور مسجل و{absent} غياب صريح و{late} سجل تأخير. "
                "أي يوم من غير تسجيل بيتراجع ومش بيتحسب غياب تلقائي.",
                f"{scope_en}: {present} present, {absent} explicitly absent and "
                f"{late} late attendance records. Missing days are not automatic absences.",
                "attendance", "attendance",
            )
        if day:
            row = rows[0] if rows else None
            if not row:
                return respond(
                    f"مفيش تسجيل حضور ليك يوم {day}. ده مش معناه غياب تلقائي.",
                    f"No attendance record for {day}. That doesn't mean an automatic absence.",
                    "attendance", "attendance",
                )
            if row["status"] != "present":
                return respond(
                    f"حالتك يوم {day}: {'غياب مسجل' if row['status']=='absent' else 'إجازة مسجلة'}.",
                    f"Status on {day}: {'recorded absence' if row['status']=='absent' else 'recorded leave'}.",
                    "attendance", "attendance",
                )
            return respond(
                f"حضورك يوم {day}: الدخول {row.get('check_in') or '—'}، "
                f"الانصراف {row.get('check_out') or 'لسه ما اتسجلش'}.",
                f"Attendance on {day}: check-in {row.get('check_in') or '—'}, "
                f"check-out {row.get('check_out') or 'not recorded yet'}.",
                "attendance", "attendance",
            )
        return respond(
            f"في {month} عندك {present} يوم حضور مسجل و{absent} يوم غياب مسجل، "
            f"ومنهم {late} يوم فيه تأخير. الأيام غير المسجلة مش غياب تلقائي.",
            f"For {month}: {present} present days, {absent} recorded absences, "
            f"and {late} late check-ins. Unrecorded days are not automatic absences.",
            "attendance", "attendance",
        )

    if includes(q, "اجازه", "اجازة", "اجازات", "اجازاتي", "اجازتي", "إجازة", "leave", "vacation", "holiday"):
        requests = state["leaves"]
        if day:
            requests = [r for r in requests if r["start_day"] <= day <= r["end_day"]]
            scope_ar, scope_en = f"يوم {day}", f"on {day}"
        else:
            start = month + "-01"
            end = (dt.date.fromisoformat(start).replace(day=28) +
                   dt.timedelta(days=4)).replace(day=1) - dt.timedelta(days=1)
            requests = [
                r for r in requests if r["start_day"] <= end.isoformat()
                and r["end_day"] >= start
            ]
            scope_ar, scope_en = f"شهر {month}", f"in {month}"
        pending = sum(r["status"] == "pending" for r in requests)
        approved = sum(r["status"] == "approved" for r in requests)
        return respond(
            f"{'للفريق' if manager else 'عندك'} {pending} طلب إجازة تحت المراجعة "
            f"و{approved} طلب معتمد {scope_ar}.",
            f"{'The team has' if manager else 'You have'} {pending} pending "
            f"and {approved} approved leave requests {scope_en}.",
            "leaves", "leaves",
        )

    if includes(q, "تقييم", "ادائي", "اداء", "performance", "evaluation", "review score"):
        reviews = state["reviews"]
        if not reviews:
            return respond(
                f"مفيش تقييم مسجل {'للفريق' if manager else 'ليك'} لشهر {month}.",
                f"No {'team' if manager else 'personal'} performance review for {month}.",
                "reviews", "reviews",
            )
        if manager:
            return respond(
                f"فيه {len(reviews)} تقييم موظف مسجل في {month}. افتح تقييم الأداء للتفاصيل.",
                f"{len(reviews)} employee performance reviews for {month}. Open Reviews.",
                "reviews", "reviews",
            )
        score = reviews[0]["score"]
        return respond(
            f"تقييمك لشهر {month} هو {score} من 100. شوف تفاصيله في تقييم الأداء.",
            f"Your performance score for {month} is {score} out of 100. Open Reviews.",
            "reviews", "reviews",
        )

    if manager:
        return respond(
            "مش متأكد من السؤال ده. جرّب «المبيعات المعلقة»، «مسودات المرتبات»، "
            "«مهام الفريق»، أو «الحضور».",
            "I don't have a reliable answer. Try 'Pending sales', 'Draft payroll', "
            "'Team tasks', or 'Attendance'.",
            intent="fallback",
        )
    return respond(
        "مش متأكد من السؤال ده. جرّب «مهامي إيه؟»، «فاضلي كام على التارجت؟»، "
        "«مرتبي كام؟» أو «قواعد التأخير».",
        "I don't have a reliable answer. Try 'My tasks', 'Remaining target', "
        "'My salary', or 'Late policy'.",
        intent="fallback",
    )
