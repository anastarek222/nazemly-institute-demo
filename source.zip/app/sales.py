from common import (
    text, integer, active_employee, audit, now, day_value, salary_value, cairo_today
)
'Daily targets and sales. Only manager-approved sales count toward achievement.'
import datetime as dt
SCHEMA = """
CREATE TABLE IF NOT EXISTS daily_targets (
    id INTEGER PRIMARY KEY,
    
    employee_id INTEGER NOT NULL REFERENCES employees(id),
    
    day TEXT NOT NULL,
    
    amount_cents INTEGER NOT NULL CHECK(amount_cents > 0),
    
    note TEXT NOT NULL DEFAULT '',
    
    assigned_by INTEGER NOT NULL REFERENCES users(id),
    
    updated_at TEXT NOT NULL,
    
    UNIQUE(employee_id,
     day)
);

CREATE TABLE IF NOT EXISTS sales (
    id INTEGER PRIMARY KEY,
    
    employee_id INTEGER NOT NULL REFERENCES employees(id),
    
    day TEXT NOT NULL,
    
    reference TEXT NOT NULL COLLATE NOCASE UNIQUE,
    
    customer TEXT NOT NULL,
    
    amount_cents INTEGER NOT NULL CHECK(amount_cents > 0),
    
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK(status IN ('pending',
     'approved',
     'rejected',
     'cancelled')),
    
    note TEXT NOT NULL DEFAULT '',
    
    submitted_by INTEGER NOT NULL REFERENCES users(id),
    
    created_at TEXT NOT NULL,
    
    decided_by INTEGER REFERENCES users(id),
    
    decided_at TEXT,
    
    decision_note TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS sales_day ON sales(day,
     employee_id);
"""

def init(connection):
    connection.executescript(SCHEMA)

def summary(connection, employee_id, month):
    """A target can only be achieved using approved sales on its own day."""
    targets = connection.execute('SELECT day, amount_cents FROM daily_targets WHERE employee_id = ? AND substr(day, 1, 7) = ?', (employee_id, month)).fetchall()
    approved = connection.execute("SELECT day, SUM(amount_cents) AS amount FROM sales WHERE employee_id = ? AND substr(day, 1, 7) = ? AND status = 'approved' GROUP BY day", (employee_id, month)).fetchall()
    amounts_by_day = {row['day']: row['amount'] for row in approved}
    target_total = sum((row['amount_cents'] for row in targets))
    matched_sales = sum((amounts_by_day.get(row['day'], 0) for row in targets))
    all_sales = sum(amounts_by_day.values())
    attendance = connection.execute('SELECT status, late_minutes FROM attendance WHERE employee_id = ? AND substr(day, 1, 7) = ?', (employee_id, month)).fetchall()
    present = sum((row['status'] == 'present' for row in attendance))
    absent = sum((row['status'] == 'absent' for row in attendance))
    on_time = sum((row['status'] == 'present' and row['late_minutes'] == 0 for row in attendance))
    return {
        'employee_id': employee_id,
        'target_cents': target_total,
        'approved_cents': all_sales,
        'matched_cents': matched_sales,
        'without_target_cents': all_sales - matched_sales,
        'achievement': round(matched_sales * 100 / target_total, 1) if target_total else None,
        'present': present,
        'absent': absent,
        'attendance_rate': round(present * 100 / (present + absent), 1) if present + absent else None,
        'on_time_rate': round(on_time * 100 / present, 1) if present else None,
    }

def extra_state(connection, user, month):
    is_manager = user['role'] == 'manager'
    scope = '' if is_manager else ' AND employee_id = ?'
    arguments = (month,) if is_manager else (month, user['employee_id'])
    targets = [dict(row) for row in connection.execute('SELECT * FROM daily_targets WHERE substr(day, 1, 7) = ?' + scope + ' ORDER BY day DESC, employee_id', arguments)]
    transactions = [dict(row) for row in connection.execute('SELECT s.*, u.username AS reviewer FROM sales s LEFT JOIN users u ON u.id = s.decided_by WHERE substr(s.day, 1, 7) = ?' + ('' if is_manager else ' AND s.employee_id = ?') + ' ORDER BY s.created_at DESC, s.id DESC', arguments)]
    employees = connection.execute('SELECT id FROM employees' + ('' if is_manager else ' WHERE id = ?'), () if is_manager else (user['employee_id'],)).fetchall()
    indicators = [summary(connection, row['id'], month) for row in employees]
    history = []
    cursor = dt.date.fromisoformat(month + '-01')
    for _ in range(6):
        work_month = cursor.strftime('%Y-%m')
        values = [summary(connection, row['id'], work_month) for row in employees]
        target = sum((value['target_cents'] for value in values))
        matched = sum((value['matched_cents'] for value in values))
        history.append({'month': work_month, 'target_cents': target, 'approved_cents': sum((value['approved_cents'] for value in values)), 'achievement': round(matched * 100 / target, 1) if target else None})
        cursor = (cursor - dt.timedelta(days=1)).replace(day=1)
    return {'targets': targets, 'sales': transactions, 'sales_summary': indicators, 'sales_history': list(reversed(history))}

def route(connection, user, path, body):
    """Return None for unrelated routes. All updates share the request transaction."""
    routes = {'/api/targets/save', '/api/sales/submit', '/api/sales/decide', '/api/sales/cancel', '/api/demo/sales'}
    if path not in routes:
        return None
    is_manager = user['role'] == 'manager'
    if path in {'/api/targets/save', '/api/sales/decide', '/api/demo/sales'}:
        if not is_manager:
            return ({'error': 'هذه العملية للمدير فقط'}, 403)
    stamp = now()
    today = cairo_today().isoformat()
    if path == '/api/targets/save':
        employee_id = integer(body.get('employee_id'), 1, 1000000)
        active_employee(connection, employee_id)
        day = day_value(body.get('day'))
        amount = salary_value(body.get('amount'))
        if amount <= 0:
            raise ValueError('التارجت يجب أن يكون أكبر من صفر')
        note = text(body.get('note', ''), 500, False)
        previous = connection.execute('SELECT amount_cents FROM daily_targets WHERE employee_id = ? AND day = ?', (employee_id, day)).fetchone()
        if previous and (not note):
            raise ValueError('اكتب سبب تعديل التارجت')
        connection.execute('INSERT INTO daily_targets(employee_id, day, amount_cents, note, assigned_by, updated_at) VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(employee_id, day) DO UPDATE SET amount_cents = excluded.amount_cents, note = excluded.note, assigned_by = excluded.assigned_by, updated_at = excluded.updated_at', (employee_id, day, amount, note, user['id'], stamp))
        before = previous['amount_cents'] if previous else None
        audit(connection, user, 'تحديد تارجت', f'{employee_id} / {day} / {before} -> {amount} / {note}')
    elif path == '/api/sales/submit':
        employee_id = integer(body.get('employee_id'), 1, 1000000) if is_manager else user['employee_id']
        active_employee(connection, employee_id)
        day = day_value(body.get('day'))
        if day > today:
            raise ValueError('لا يمكن تسجيل بيع بتاريخ مستقبلي')
        if not is_manager:
            if day != today:
                raise ValueError('الموظف يسجل مبيعات اليوم الحالي فقط')
            attendance = connection.execute('SELECT status FROM attendance WHERE employee_id=? AND day=?', (employee_id, day)).fetchone()
            if not attendance or attendance['status'] != 'present':
                raise ValueError('ابدأ العمل وسجّل حضورك قبل تسجيل المبيعات')
        amount = salary_value(body.get('amount'))
        if amount <= 0:
            raise ValueError('قيمة البيع يجب أن تكون أكبر من صفر')
        reference = text(body.get('reference'), 80).upper()
        customer = text(body.get('customer'), 100)
        note = text(body.get('note', ''), 500, False)
        if connection.execute('SELECT 1 FROM sales WHERE reference = ?', (reference,)).fetchone():
            raise ValueError('مرجع العملية مسجّل بالفعل؛ لا يمكن تكراره')
        sale_id = connection.execute('INSERT INTO sales(employee_id, day, reference, customer, amount_cents, note, submitted_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', (employee_id, day, reference, customer, amount, note, user['id'], stamp)).lastrowid
        audit(connection, user, 'تسجيل عملية بيع', sale_id)
        connection.execute('INSERT INTO notifications(employee_id,message,created_at) VALUES(NULL,?,?)', ('عملية بيع جديدة للمراجعة: '+reference,stamp))
    elif path == '/api/sales/decide':
        sale_id = integer(body.get('id'), 1, 1000000)
        status = body.get('status')
        if status not in {'approved', 'rejected'}:
            raise ValueError('قرار غير صحيح')
        note = text(body.get('decision_note', ''), 500, False)
        if status == 'rejected' and (not note):
            raise ValueError('اكتب سبب رفض العملية')
        changed = connection.execute("UPDATE sales SET status = ?, decided_by = ?, decided_at = ?, decision_note = ? WHERE id = ? AND status = 'pending'", (status, user['id'], stamp, note, sale_id)).rowcount
        if changed != 1:
            raise ValueError('العملية غير موجودة أو تمت مراجعتها بالفعل')
        audit(connection, user, 'اعتماد بيع' if status == 'approved' else 'رفض بيع', sale_id)
        reviewed = connection.execute('SELECT employee_id,reference FROM sales WHERE id=?',(sale_id,)).fetchone()
        message = ('تم اعتماد ' if status == 'approved' else 'تم رفض ') + reviewed['reference']
        connection.execute('INSERT INTO notifications(employee_id,message,created_at) VALUES(?,?,?)',(reviewed['employee_id'],message,stamp))
    elif path == '/api/sales/cancel':
        sale_id = integer(body.get('id'), 1, 1000000)
        row = connection.execute('SELECT * FROM sales WHERE id = ?', (sale_id,)).fetchone()
        if not row or (not is_manager and row['employee_id'] != user['employee_id']):
            return ({'error': 'العملية غير موجودة'}, 404)
        if row['status'] != 'pending':
            raise ValueError('يمكن إلغاء العمليات المعلقة فقط')
        connection.execute("UPDATE sales SET status = 'cancelled', decision_note = ?, decided_at = ? WHERE id = ?", ('إلغاء بواسطة صاحب العملية' if not is_manager else 'إلغاء بواسطة المدير', stamp, sale_id))
        audit(connection, user, 'إلغاء عملية بيع', sale_id)
    elif path == '/api/demo/sales':
        employee_id = integer(body.get('employee_id'), 1, 1000000)
        active_employee(connection, employee_id)
        day = day_value(body.get('day'))
        if day > today:
            raise ValueError('اختر تاريخ اليوم أو قبله للمثال')
        if connection.execute('SELECT 1 FROM daily_targets WHERE employee_id = ? AND day = ? UNION SELECT 1 FROM sales WHERE employee_id = ? AND day = ?', (employee_id, day, employee_id, day)).fetchone():
            raise ValueError('اختر يومًا دون تارجت أو مبيعات لإضافة المثال بدون استبدال بيانات')
        prefix = f'DEMO-{employee_id}-{day}-'
        connection.execute("INSERT INTO daily_targets(employee_id, day, amount_cents, note, assigned_by, updated_at) VALUES (?, ?, 500000, 'نموذج مبيعات', ?, ?)", (employee_id, day, user['id'], stamp))
        for (index, amount) in enumerate([200000, 150000, 250000], 1):
            status = 'approved' if index < 3 else 'pending'
            connection.execute('INSERT INTO sales(employee_id, day, reference, customer, amount_cents, status, note, submitted_by, created_at, decided_by, decided_at, decision_note) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', (employee_id, day, prefix + str(index), f'عميل تجريبي {index}', amount, status, 'نموذج مبيعات', user['id'], stamp, user['id'] if index < 3 else None, stamp if index < 3 else None, 'اعتماد نموذج مبيعات' if index < 3 else ''))
        audit(connection, user, 'إنشاء نموذج مبيعات', f'{employee_id} / {day}')
    return ({'ok': True}, 200)
