"""SQLite connection and base tables. SQLite connection and base tables."""
import os
import sqlite3
from pathlib import Path
from contextlib import contextmanager
ROOT = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get('HR_DB_PATH', str(ROOT / 'data' / 'hr.sqlite3')))
PUBLIC = ROOT / 'public'

@contextmanager
def db():
    connection = sqlite3.connect(str(DB_PATH), timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute('PRAGMA foreign_keys=ON')
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()
SCHEMA = """
CREATE TABLE IF NOT EXISTS employees(id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    department TEXT NOT NULL,
    title TEXT NOT NULL,
    phone TEXT NOT NULL DEFAULT '',
    salary_cents INTEGER NOT NULL CHECK(salary_cents>=0),
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('manager',
    'employee')),
    employee_id INTEGER REFERENCES employees(id));

CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    expires_at REAL NOT NULL);

CREATE TABLE IF NOT EXISTS attendance(id INTEGER PRIMARY KEY,
    employee_id INTEGER NOT NULL REFERENCES employees(id),
    day TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('present',
    'absent',
    'leave')),
    scheduled TEXT,
    check_in TEXT,
    check_out TEXT,
    late_minutes INTEGER NOT NULL DEFAULT 0,
    penalty_quarters INTEGER NOT NULL DEFAULT 0,
    note TEXT NOT NULL DEFAULT '',
    UNIQUE(employee_id,
    day));

CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY,
    employee_id INTEGER NOT NULL REFERENCES employees(id),
    month TEXT NOT NULL,
    quality INTEGER NOT NULL CHECK(quality BETWEEN 0 AND 100),
    productivity INTEGER NOT NULL CHECK(productivity BETWEEN 0 AND 100),
    teamwork INTEGER NOT NULL CHECK(teamwork BETWEEN 0 AND 100),
    note TEXT NOT NULL DEFAULT '',
    UNIQUE(employee_id,
    month));

CREATE TABLE IF NOT EXISTS payroll(id INTEGER PRIMARY KEY,
    employee_id INTEGER NOT NULL REFERENCES employees(id),
    month TEXT NOT NULL,
    base_cents INTEGER NOT NULL,
    bonus_cents INTEGER NOT NULL,
    deduction_cents INTEGER NOT NULL,
    net_cents INTEGER NOT NULL,
    penalty_quarters INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft',
    'approved')),
    created_at TEXT NOT NULL,
    UNIQUE(employee_id,
    month));

CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    action TEXT NOT NULL,
    entity TEXT NOT NULL,
    created_at TEXT NOT NULL);

CREATE INDEX IF NOT EXISTS attendance_day ON attendance(day);

CREATE INDEX IF NOT EXISTS reviews_month ON reviews(month);
"""
