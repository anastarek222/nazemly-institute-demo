#!/bin/zsh
cd "$(dirname "$0")" || exit 1
python3 share_demo.py
code=$?
if [ "$code" -ne 0 ]; then
  echo "\nفيه مشكلة في فتح المشاركة. اقرا الرسالة اللي فوق."
  read "?اضغط Enter لإغلاق النافذة..."
fi
exit "$code"
