#!/usr/bin/env python3
"""Start the application with its own local or demo database. Standard library only."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import urllib.error
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parent


def requirements():
    if sys.version_info < (3, 9):
        raise RuntimeError('Python 3.9 أو أحدث مطلوب')
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
    try:
        ZoneInfo('Africa/Cairo')
    except ZoneInfoNotFoundError:
        raise RuntimeError(
            'بيانات توقيت القاهرة غير موجودة. نفّذ: python -m pip install tzdata'
        )
    print('Python:', sys.version.split()[0], '| Africa/Cairo: OK', flush=True)


def main():
    parser = argparse.ArgumentParser(description='نظملي — تشغيل محلي')
    parser.add_argument('--demo', action='store_true', help='قاعدة عرض منفصلة')
    parser.add_argument('--check', action='store_true', help='فحص المتطلبات دون التشغيل')
    parser.add_argument('--no-browser', action='store_true')
    options = parser.parse_args()
    requirements()
    if options.check:
        print('فحص المتطلبات نجح')
        return

    port = 4179 if options.demo else 4178
    filename = 'demo.sqlite3' if options.demo else 'hr.sqlite3'
    database = (ROOT / 'academic' / 'data' / filename if (ROOT / 'academic' / 'data' / filename).exists() else ROOT / 'app' / 'data' / filename)
    database_id = hashlib.sha256(str(database).encode()).hexdigest()[:12]
    address = f'http://127.0.0.1:{port}'

    def health():
        with urllib.request.urlopen(address + '/api/health', timeout=1) as response:
            return json.load(response)

    try:
        existing = health()
    except (OSError, ValueError, urllib.error.URLError):
        existing = None
    if existing:
        if existing.get('app') != 'nazemly' or existing.get('database_id') != database_id:
            raise RuntimeError('المنفذ مستخدم بتطبيق أو قاعدة أخرى؛ لا يتم إيقافه تلقائيًا')
        if not options.no_browser:
            webbrowser.open(address)
        print('نظملي يعمل بالفعل:', address)
        return

    env = dict(os.environ, HR_DB_PATH=str(database), HR_DEMO_MODE='1' if options.demo else '0')
    process = subprocess.Popen(
        [sys.executable, str(ROOT / 'app' / 'server.py'), '--port', str(port)],
        cwd=str(ROOT), env=env,
    )
    try:
        for attempt in range(80):
            if process.poll() is not None:
                raise RuntimeError('تعذر تشغيل الخادم؛ راجع الرسالة أعلاه')
            try:
                result = health()
                if result.get('database_id') == database_id:
                    break
            except (OSError, ValueError, urllib.error.URLError):
                pass
            time.sleep(0.1)
        else:
            raise RuntimeError('لم يجهز الخادم خلال وقت الانتظار')
        print('نسخة عرض مستقلة' if options.demo else 'النسخة الأساسية', address, flush=True)
        if not options.no_browser:
            webbrowser.open(address)
        process.wait()
    except KeyboardInterrupt:
        print('\nتم إيقاف التشغيل')
    finally:
        if process.poll() is None:
            process.terminate()
            process.wait(timeout=5)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('تعذر التشغيل:', str(error), file=sys.stderr)
        sys.exit(1)
