@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
if errorlevel 1 goto :folder_error
if not exist "launch.py" goto :folder_error

set "PYEXE="
set "PYARGS="

rem Use an installed Python 3.9+ interpreter. Avoid relying on a Store alias.
where py >nul 2>nul
if not errorlevel 1 call :probe "py" "-3"
if not defined PYEXE (
    where python >nul 2>nul
    if not errorlevel 1 call :probe "python" ""
)
if not defined PYEXE (
    for %%V in (315 314 313 312 311 310 39) do (
        if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python%%V-32\python.exe" call :probe "%LOCALAPPDATA%\Programs\Python\Python%%V-32\python.exe" ""
        if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe" call :probe "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe" ""
    )
)
if not defined PYEXE goto :python_missing

echo.
echo Nazemly - Windows startup
"%PYEXE%" %PYARGS% --version

rem Check Python and the Africa/Cairo time zone before running the server.
"%PYEXE%" %PYARGS% launch.py --check >nul 2>nul
if not errorlevel 1 goto :run

rem Windows Python may need the official tzdata package for Cairo time.
"%PYEXE%" %PYARGS% -c "from zoneinfo import ZoneInfo; ZoneInfo('Africa/Cairo')" >nul 2>nul
if not errorlevel 1 goto :requirements_failed
echo.
echo The Cairo time zone data is missing from Python.
echo Nazemly needs the free Python package: tzdata
echo An internet connection is required only for this installation.
choice /C YN /M "Install tzdata now"
if errorlevel 2 goto :requirements_failed
if not errorlevel 1 goto :requirements_failed
"%PYEXE%" %PYARGS% -m pip install tzdata
if errorlevel 1 goto :requirements_failed
"%PYEXE%" %PYARGS% launch.py --check
if errorlevel 1 goto :requirements_failed

:run
echo.
echo Opening Nazemly...
"%PYEXE%" %PYARGS% launch.py %*
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" (
    echo.
    echo Nazemly could not start. Read the error above.
    echo If Cairo time zone data is missing, run: python -m pip install tzdata
    pause
)
exit /b %RESULT%

:folder_error
echo.
echo launch.py was not found in the same folder as the Windows start files.
echo Extract Nazemly.zip completely before opening Start.bat or Demo.bat.
pause
exit /b 1

:python_missing
echo.
echo Python 3.9 or newer was not found.
echo Install Python for Windows and enable "Add python.exe to PATH".
echo For 32-bit Windows choose a compatible 32-bit Python installation.
echo Download: https://www.python.org/downloads/windows/
echo Close and reopen this file after installing Python.
pause
exit /b 1

:requirements_failed
echo.
echo Python is installed, but a requirement check failed.
"%PYEXE%" %PYARGS% launch.py --check
echo.
echo For missing time zone data, try:
echo    "%PYEXE%" %PYARGS% -m pip install tzdata
echo Then open Start.bat or Demo.bat again.
pause
exit /b 1

:probe
if defined PYEXE exit /b 0
"%~1" %~2 -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>nul
if errorlevel 1 exit /b 0
set "PYEXE=%~1"
set "PYARGS=%~2"
exit /b 0
