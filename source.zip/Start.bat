@echo off
call "%~dp0_win_start.bat" %*
exit /b %errorlevel%
