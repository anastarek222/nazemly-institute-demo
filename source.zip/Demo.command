#!/bin/bash
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null; then
  echo "Python 3.9 or newer is required."
  read -r -p "Press Enter to close"
  exit 1
fi
python3 launch.py --demo
if [ $? -ne 0 ]; then read -r -p "Press Enter to close"; fi
