@echo off
call "%~dp0_win_start.bat" --demo %*
exit /b %errorlevel%
